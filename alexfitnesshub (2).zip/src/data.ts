import { Testimonial, Exercise, BlogPost } from './types';

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Tochukwu Okafor',
    role: 'Tech Lead / Busy Professional',
    resultType: 'fat-loss',
    result: 'Lost 22kg of stubborn visceral fat',
    story: 'Being sat at a desk command station for 10 hours a day left me overweight and sluggish. ALEXFITNESSHUB calculated my exact calorie deficit, suggested traditional high-protein Nigerian meals like Grilled Fish and Moi Moi, and gave me a 45-minute home workout program. Within 6 months, my life completely transformed!',
    beforeWeight: '104 kg',
    afterWeight: '82 kg',
    image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=600&auto=format&fit=crop&q=80',
    rating: 5
  },
  {
    id: '2',
    name: 'Sarah Adebayo',
    role: 'Corporate Analyst',
    resultType: 'muscle-gain',
    result: 'Gained 6kg of lean muscle mass',
    story: 'I wanted to build an athletic, toned beach body without looking bulky. The Hollywood Lean Model program was perfect. Tracking my macros and doing custom glute/shoulder hypertrophy work completely reshaped my physique and doubled my strength!',
    beforeWeight: '52 kg',
    afterWeight: '58 kg',
    image: 'https://images.unsplash.com/photo-1548690312-e3b507d8c110?w=600&auto=format&fit=crop&q=80',
    rating: 5
  },
  {
    id: '3',
    name: 'Command Sergeant Wale',
    role: 'Military Recruit Candidate',
    resultType: 'military',
    result: 'Passed Special Force Conditioning in top 1%',
    story: 'The running and calisthenics programs are brutal but elite. I went from struggling on 20 pushups to mastering 100 consecutive pushups, 25 dead-hang pullups, and destroying the 5K run. Highly recommend the military conditioning track!',
    beforeWeight: '78 kg',
    afterWeight: '75 kg',
    image: 'https://images.unsplash.com/photo-1598971861713-54ad16a7e72e?w=600&auto=format&fit=crop&q=80',
    rating: 5
  },
  {
    id: '4',
    name: 'Chidimma Nwachukwu',
    role: 'Mother of Two',
    resultType: 'health-reversal',
    result: 'Reversed Pre-Diabetes & Restored Knee Mobility',
    story: 'After childbirth, joint pain and low energy made gym impossible. The platform generated low-impact bodyweight work and custom meal plans featuring healthy carbs like sweet potatoes and vegetables. My blood sugar is completely normal, and my knees feel young again!',
    beforeWeight: '88 kg',
    afterWeight: '71 kg',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&auto=format&fit=crop&q=80',
    rating: 5
  },
  {
    id: '5',
    name: 'Alexandre Dubois',
    role: 'Creative Director',
    resultType: 'fat-loss',
    result: 'Dropped 14kg with Gym & Cardio Guide',
    story: 'The Treadmill 12-3-30 protocol is magic. Combined with a robust compound lifting split, I dropped fat incredibly fast while keeping all my strength. This app provides the exact science-backed coaching I always needed.',
    beforeWeight: '93 kg',
    afterWeight: '79 kg',
    image: 'https://images.unsplash.com/photo-1483721310020-03333e577076?w=600&auto=format&fit=crop&q=80',
    rating: 5
  },
  {
    id: '6',
    name: 'Oluwaseun Babatunde',
    role: 'Amateur Athlete',
    resultType: 'muscle-gain',
    result: 'Gained 10kg of solid powerlifter muscle',
    story: 'No pseudo-science here. The squat, bench, and pull progression templates helped me break my personal records. My bench press jumped from 90kg to 140kg, and my recovery has been optimal due to proper protein recommendations.',
    beforeWeight: '74 kg',
    afterWeight: '84 kg',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=80',
    rating: 5
  },
  {
    id: '7',
    name: 'Amara Egwu',
    role: 'Fitness Enthusiast',
    resultType: 'military',
    result: 'Extreme Endurance & Lower Body Strength',
    story: 'The combined cardio swimming, running, and kettlebell regimes are life-altering. My lung capacity has improved immensely, and I have boundless energy throughout the day. It is a genuine, world-class training blueprint.',
    beforeWeight: '69 kg',
    afterWeight: '62 kg',
    image: 'https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=600&auto=format&fit=crop&q=80',
    rating: 5
  }
];

export const EXERCISES: Exercise[] = [
  // Gym - Chest
  { id: '1', name: 'Bench Press', category: 'chest', instructions: 'Lie back on a flat bench. Grip the barbell with hands slightly wider than shoulder-width. Lower the bar slowly to your chest, then press back up explosively.' },
  { id: '2', name: 'Incline Bench Press', category: 'chest', instructions: 'Perform on an incline bench angles 30-45 degrees. Targets the clavicular head of the pectoralis major (upper chest).' },
  { id: '3', name: 'Decline Bench Press', category: 'chest', instructions: 'Perform on a decline bench. Focuses on the lower chest fibers for optimal development.' },
  { id: '4', name: 'Cable Fly', category: 'chest', instructions: 'Hold cables with a slight bend in your elbows. Squeeze your pecs together as you bring your hands to cross at the midline.' },
  { id: '5', name: 'Machine Press', category: 'chest', instructions: 'Sit comfortably, push handles away from your body with controlled speed. Great for high intensity failure sets.' },
  { id: '6', name: 'Dumbbell Bench Press', category: 'chest', instructions: 'Provides independent stabilizer recruitment. Press dumbbells upward, squeezing pecs at the top.' },

  // Gym - Back
  { id: '7', name: 'Pull Ups', category: 'back', instructions: 'Hang from a bar. Pull your body upward until your chin clears the bar. Lower down with full control.' },
  { id: '8', name: 'Lat Pulldown', category: 'back', instructions: 'Sit at pulldown station. Pull bar down to your upper chest, leading with your elbows.' },
  { id: '9', name: 'Deadlift', category: 'back', instructions: 'Hinge at the hips, grip the bar, and pull back with strong glutes, hamstrings, and lower back engagement.' },
  { id: '10', name: 'Barbell Rows', category: 'back', instructions: 'Bend at 45 degrees, pull barbell into your lower abdomen to target your lats and mid-back.' },
  { id: '11', name: 'Cable Rows', category: 'back', instructions: 'Seated row. Squeeze your scapula together at the peak contraction point.' },

  // Gym - Legs
  { id: '12', name: 'Barbell Back Squats', category: 'legs', instructions: 'Bar on upper traps, drop hips low ensuring thighs go parallel or deeper, press up through midfoot.' },
  { id: '13', name: 'Leg Press', category: 'legs', instructions: 'Place feet shoulder-width on platform, release safety locks, lower slowly, and press up without locking knees.' },
  { id: '14', name: 'Walking Lunges', category: 'legs', instructions: 'Step forward, dropping trailing knee to centimeters above floor. Push off back leg.' },
  { id: '15', name: 'Romanian Deadlift (RDL)', category: 'legs', instructions: 'Keep a flat back, push hips back to load hamstrings, lower dumbbell/barbell along your shins.' },
  { id: '16', name: 'Calf Raises', category: 'legs', instructions: 'Extend through toes, hold contract peak for 2 seconds, slow release.' },

  // Gym - Shoulders
  { id: '17', name: 'Military Press (Barbell Press)', category: 'shoulders', instructions: 'Stand tall with core zipped, press barbell overhead, locking out at the peak.' },
  { id: '18', name: 'Lateral Raises', category: 'shoulders', instructions: 'Slightly lean forward, raise dumbbells to side up to shoulder-level. Targets lateral deltoids for width.' },
  { id: '19', name: 'Front Raises', category: 'shoulders', instructions: 'Raise dumbbells or plate forward to eye level. Targets front deltoids.' },
  { id: '20', name: 'Rear Delt Fly', category: 'shoulders', instructions: 'Dumbbells or reverse deck-deck. Squeeze back shoulder blades outward.' },

  // Gym - Arms
  { id: '21', name: 'Barbell Bicep Curls', category: 'arms', instructions: 'Curl bar up keeping elbows pinned to ribs. Squeeze biceps.' },
  { id: '22', name: 'Tricep Rope Overhead Press', category: 'arms', instructions: 'Extend arms overhead pulling ropes outward. Intense tricep stretch.' },
  { id: '23', name: 'Dumbbell Hammer Curls', category: 'arms', instructions: 'Neutral grip curls targeting brachioradialis and forearms.' },
  { id: '24', name: 'Tricep Pushdowns', category: 'arms', instructions: 'Push cable downward keeping upper arm immobile.' },

  // Gym - Core
  { id: '25', name: 'Decline Bench Sit-Ups', category: 'core', instructions: 'Decline setup, curl spine upwards focused entirely on abdominal squeeze.' },
  { id: '26', name: 'Hanging Leg Raises', category: 'core', instructions: 'Hang from rack, lift legs straight up to bar level for lower abs.' },
  { id: '27', name: 'Russian Twist', category: 'core', instructions: 'Seated, torso leaned back, twist side to side targeting obliques.' }
];

export const NIGERIAN_FOODS = [
  { name: 'Rice (Jollof or White)', calories: 350, protein: 7, carbs: 75, fat: 2 },
  { name: 'Beans (Brown or Oloyin)', calories: 340, protein: 22, carbs: 60, fat: 1 },
  { name: 'Yam (Boiled)', calories: 120, protein: 1.5, carbs: 28, fat: 0.1 },
  { name: 'Sweet Potato', calories: 90, protein: 1.6, carbs: 20, fat: 0.1 },
  { name: 'Plantain (Boiled/Roast)', calories: 150, protein: 1.3, carbs: 32, fat: 0.4 },
  { name: 'Garri (Ebba / Cassava flour)', calories: 360, protein: 1.5, carbs: 85, fat: 0.5 },
  { name: 'Moi Moi (Steamed beans pudding)', calories: 160, protein: 12, carbs: 24, fat: 3 },
  { name: 'Akara (Fried bean cakes)', calories: 220, protein: 10, carbs: 20, fat: 12 },
  { name: 'Croaker Fish (Grilled)', calories: 180, protein: 24, carbs: 0, fat: 9 },
  { name: 'Chicken Breast (Stewed/Grilled)', calories: 165, protein: 31, carbs: 0, fat: 3.6 },
  { name: 'Turkey Breast (Grilled)', calories: 150, protein: 29, carbs: 0, fat: 3 },
  { name: 'Hard Boiled Egg', calories: 155, protein: 13, carbs: 1.1, fat: 11 }
];

export const GLOBAL_FOODS = [
  { name: 'Rolled Oats', calories: 389, protein: 16.9, carbs: 66, fat: 6.9 },
  { name: 'Wild Salmon fillet', calories: 208, protein: 22, carbs: 0, fat: 13 },
  { name: 'Lean Beef steak', calories: 250, protein: 26, carbs: 0, fat: 15 },
  { name: 'Unsweetened Greek Yogurt', calories: 59, protein: 10, carbs: 3.6, fat: 0.4 },
  { name: 'Avocado', calories: 160, protein: 2, carbs: 8.5, fat: 15 },
  { name: 'Quinoa', calories: 120, protein: 4.4, carbs: 21, fat: 1.9 },
  { name: 'Brown Rice', calories: 111, protein: 2.6, carbs: 23, fat: 0.9 },
  { name: 'Almonds', calories: 579, protein: 21, carbs: 22, fat: 49 },
  { name: 'Bananas', calories: 89, protein: 1.1, carbs: 23, fat: 0.3 },
  { name: 'Apples', calories: 52, protein: 0.3, carbs: 14, fat: 0.2 },
  { name: 'Oranges', calories: 47, protein: 0.9, carbs: 12, fat: 0.1 }
];

export const CELEBRITY_PROGRAMS = [
  {
    name: 'Athletic Physique',
    description: 'Inspired by speed, high tendon loading, low body fat, and agility.',
    focus: 'Dynamic strength, power cleans, HIIT plyometrics, and calisthenics.',
    duration: '8 Weeks',
    difficulty: 'Intermediate'
  },
  {
    name: 'Lean Model Physique',
    description: 'Minimalist muscle bulk with ultra-definition, focused heavily on absolute symmetry.',
    focus: 'V-taper vertical pulling, lateral raises, incline press, and daily low-intensity steady-state (LISS) cardio.',
    duration: '12 Weeks',
    difficulty: 'Beginner to Advanced'
  },
  {
    name: 'Hollywood Action Hero Physique',
    description: 'Dense mass and armor-plated chest look, ready for action roles.',
    focus: 'Heavy military press, weighted chin ups, incline dumbbells, and high calorie protein-surplus diet.',
    duration: '10 Weeks',
    difficulty: 'Advanced'
  },
  {
    name: 'Muscular Physique',
    description: 'Maximum mechanical tension targeting absolute muscle diameter and high power.',
    focus: 'Hypertrophy volume (8-12 reps to failure), powerlifting baseline squats, deadlifts, and bench.',
    duration: '12 Weeks',
    difficulty: 'Intermediate to Advanced'
  },
  {
    name: 'Beach Body Physique',
    description: 'Tight waistline, dominant serratus muscles, cap-stone delts, and aesthetic abs.',
    focus: 'Carbohydrate cycling, deep ab rollouts, direct arm pumping, and high performance conditioning circuits.',
    duration: '6 Weeks',
    difficulty: 'Beginner'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-1',
    title: 'The Truth About Localized Fat Loss (and How To Melt Visceral Fat)',
    excerpt: 'Can you spot-reduce stomach fat? Discover the science of thermogenesis, energy-restricted regimes, and why core compression vests are a waste of money.',
    content: 'The holy grail of fitness is reducing belly fat. Over many decades, fitness promoters claimed custom crunch circuits melt belly fat. However, human biology does not work that way. Lipolysis (fat breakdown) is global and regulated by hormone signaling throughout the bloodstream.\n\nTo lose belly fat, you must establish an energy deficit. Daily caloric expend exceeds intake. ALEXFITNESSHUB automates this calculation in your profile. Combine this structural deficit with high dietary protein to direct fat reduction while preserving lean mass structures.',
    category: 'nutrition',
    author: 'Coach Alex',
    date: '2026-05-18',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'post-2',
    title: 'Unlocking the Power of Military Calisthenics: Push, Pull, Carry',
    excerpt: 'The elite training secret of special tactical teams worldwide. Why simple bodyweight movements yield bulletproof joints and extreme mechanical power.',
    content: 'Tactical calisthenics is different from standard casual home workouts. It prioritizes extreme muscle endurance, tendon resilience, and steady cardiovascular state.\n\nOur Military Programs focus on progression thresholds: pushups to build relative torso power, dead-hang pullups to fortify shoulder girdle stabilizers, and tactical running to expand oxygenation kinetics. No specialized machinery required—it relies on pure gravitational resistant geometry.',
    category: 'military',
    author: 'Captain Babatunde',
    date: '2026-05-25',
    image: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=600&auto=format&fit=crop&q=80'
  }
];
