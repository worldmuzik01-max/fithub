import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, Dumbbell, User, LogOut, Shield, Sun, Moon, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user: currentUser, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('alexfit_theme') as 'light' | 'dark') || 'dark';
  });

  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, [theme]);

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    localStorage.setItem('alexfit_theme', nextTheme);
  };

  const handleLogout = () => {
    navigate('/auth/logout');
    setIsOpen(false);
  };

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Workouts', path: '/workouts' },
    { label: 'Nutrition', path: '/nutrition' },
    { label: 'AI Coach', path: '/ai-coach' },
    { label: 'Meal Planner', path: '/meal-plans' },
    { label: 'Progress Tracker', path: '/dashboard' },
    { label: 'Community', path: '/transformations' },
    { label: 'Pricing', path: '/pricing' },
    { label: 'Dashboard', path: '/dashboard' }
  ];

  const currentPath = location.pathname;

  return (
    <>
      <header 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled 
            ? 'bg-black/95 [.light_&]:bg-white/95 backdrop-blur-md py-2.5 shadow-xl border-b border-white/10 [.light_&]:border-black/5' 
            : 'bg-black/70 [.light_&]:bg-neutral-100/70 backdrop-blur-sm py-4 border-b border-white/5 [.light_&]:border-black/5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            
            {/* Logo & Premium Branding */}
            <Link to="/" className="flex items-center space-x-2 group shrink-0">
              <div className="w-8 h-8 bg-amber-500 rounded flex items-center justify-center transition-transform duration-300 group-hover:rotate-12 shadow-md shadow-amber-500/10">
                <Dumbbell className="h-4.5 w-4.5 text-black transform -rotate-12" />
              </div>
              <span className="font-display text-base sm:text-lg font-black tracking-tight uppercase text-white [.light_&]:text-neutral-900 transition-colors">
                ALEX<span className="text-amber-500">FITNESS</span><span className="text-[9px] tracking-widest font-mono font-light ml-1 text-neutral-400">HUB</span>
              </span>
            </Link>

            {/* Desktop Full Navigation Links (Visible on all desktops to meet user requirements) */}
            <nav className="hidden lg:flex items-center space-x-1 bg-neutral-900/50 border border-white/10 [.light_&]:border-black/5 rounded-full px-1.5 py-0.5">
              {navLinks.map((link) => {
                const isActive = currentPath === link.path || (link.path !== '/' && currentPath.startsWith(link.path));
                return (
                  <Link
                    key={link.label + '-' + link.path}
                    to={link.path}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all duration-300 hover:scale-105 ${
                      isActive 
                        ? 'bg-amber-500 text-black shadow-md shadow-amber-500/10' 
                        : 'text-neutral-300 hover:text-amber-400 [.light_&]:text-neutral-600 [.light_&]:hover:text-amber-500 hover:bg-white/5'
                    }`}
                  >
                    {link.label}
                  </Link>
                );
              })}
              {!currentUser && (
                <Link
                  to="/auth/login"
                  className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all duration-300 hover:scale-105 ${
                    currentPath === '/auth/login'
                      ? 'bg-amber-500 text-black shadow-md shadow-amber-500/10'
                      : 'text-neutral-300 hover:text-amber-400 [.light_&]:text-neutral-600 [.light_&]:hover:text-amber-500 hover:bg-white/5'
                  }`}
                >
                  Login
                </Link>
              )}
            </nav>

            {/* User Login & Header Action cluster */}
            <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
              
              {/* Theme Toggle Button */}
              <button
                onClick={toggleTheme}
                className="p-1.5 border border-white/10 [.light_&]:border-black/10 rounded-full hover:bg-white/5 [.light_&]:hover:bg-black/5 text-amber-500 transition-all flex items-center justify-center cursor-pointer"
                title={theme === 'light' ? 'Set Dark Mode' : 'Set Light Mode'}
              >
                {theme === 'light' ? (
                  <Moon className="h-4 w-4 text-neutral-800 animate-pulse" />
                ) : (
                  <Sun className="h-4 w-4 text-amber-400" />
                )}
              </button>

              {/* Desktop User Sign-In Action Area */}
              <div className="hidden lg:flex items-center space-x-2">
                {currentUser ? (
                  <div className="flex items-center space-x-2">
                    {(currentUser.email === 'muzikworld08@gmail.com' || (currentUser as any).role === 'admin') && (
                      <Link 
                        to="/admin" 
                        className="flex items-center space-x-1 text-[9px] uppercase bg-amber-500 hover:bg-amber-600 text-black font-extrabold px-2.5 py-1.5 rounded-full tracking-wider transition-all shadow-sm"
                      >
                        <Shield className="h-3 w-3" />
                        <span>Admin</span>
                      </Link>
                    )}
                    
                    <Link 
                      to="/dashboard" 
                      className={`flex items-center space-x-1 px-3 py-1.5 rounded-full text-[11px] font-bold text-neutral-300 [.light_&]:text-neutral-700 hover:text-amber-500 border border-white/10 [.light_&]:border-black/10 transition-all ${
                        currentPath.startsWith('/dashboard') ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : ''
                      }`}
                    >
                      <User className="h-3.5 w-3.5" />
                      <span>{currentUser.name ? currentUser.name.split(' ')[0] : 'Athlete'}</span>
                    </Link>
                    
                    <button 
                      onClick={handleLogout}
                      className="p-1.5 rounded-full hover:bg-white/5 [.light_&]:hover:bg-black/15 text-neutral-400 hover:text-rose-500 transition-colors cursor-pointer"
                      title="Logout"
                    >
                      <LogOut className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center space-x-1">
                    <Link 
                      to="/auth/signup" 
                      className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-black text-[10px] font-bold uppercase tracking-wider rounded-full transition-all shadow-md hover:scale-105"
                    >
                      Join Free
                    </Link>
                  </div>
                )}
              </div>

              {/* Mobile Drawer Trigger Menu Button */}
              <button
                onClick={() => setIsOpen(true)}
                className="lg:hidden p-2 border border-white/15 [.light_&]:border-black/10 rounded-full hover:bg-white/5 [.light_&]:hover:bg-black/5 text-neutral-300 [.light_&]:text-neutral-700 focus:outline-none cursor-pointer"
              >
                <Menu className="h-5 w-5" />
              </button>

            </div>

          </div>
        </div>
      </header>

      {/* slide-out Side Drawer on Mobile */}
      <div 
        className={`fixed inset-0 z-50 transition-opacity duration-300 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Backdrop overlay */}
        <div 
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setIsOpen(false)}
        ></div>

        {/* Sliding Panel */}
        <div 
          className={`absolute top-0 right-0 bottom-0 w-80 bg-neutral-950 [.light_&]:bg-white max-w-[85vw] p-6 shadow-2xl flex flex-col justify-between transition-transform duration-300 transform border-l border-white/5 [.light_&]:border-black/5 ${
            isOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div>
            <div className="flex justify-between items-center mb-8 border-b border-white/5 [.light_&]:border-black/5 pb-4">
              <span className="font-display text-md font-extrabold text-white [.light_&]:text-black uppercase">
                ALEX<span className="text-amber-500">FITNESS</span>
              </span>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-2 border border-white/10 [.light_&]:border-black/10 rounded-full text-neutral-400 hover:text-white"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            <nav className="flex flex-col space-y-3.5">
              {navLinks.map((link) => {
                const isActive = currentPath === link.path || (link.path !== '/' && currentPath.startsWith(link.path));
                return (
                  <Link
                    key={link.label + '-' + link.path}
                    to={link.path}
                    onClick={() => setIsOpen(false)}
                    className={`text-xs uppercase tracking-wider font-extrabold py-2 px-4 rounded-full transition-all ${
                      isActive 
                        ? 'bg-amber-500 text-black font-black' 
                        : 'text-neutral-300 hover:text-white [.light_&]:text-neutral-600 [.light_&]:hover:text-black hover:bg-white/5'
                    }`}
                  >
                    {link.label}
                  </Link>
                );
              })}
            </nav>
          </div>

          <div className="border-t border-white/5 [.light_&]:border-black/5 pt-6">
            {currentUser ? (
              <div className="space-y-4">
                <div className="text-xs px-3 text-neutral-405 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                  <span>Athlete: <strong>{currentUser.name || 'Athlete'}</strong></span>
                </div>
                <div className="flex flex-col gap-2">
                  <Link
                    to="/dashboard"
                    onClick={() => setIsOpen(false)}
                    className="flex justify-center items-center space-x-2 bg-amber-500 hover:bg-amber-600 text-black font-bold uppercase text-[10px] tracking-wider py-3 rounded-full shadow-md"
                  >
                    <User className="h-4 w-4" />
                    <span>My Dashboard</span>
                  </Link>
                  {((currentUser as any).email === 'muzikworld08@gmail.com' || (currentUser as any).role === 'admin') && (
                    <Link
                      to="/admin"
                      onClick={() => setIsOpen(false)}
                      className="flex justify-center items-center space-x-2 bg-neutral-900 [.light_&]:bg-neutral-100 hover:bg-neutral-850 text-white [.light_&]:text-black font-extrabold uppercase text-[10px] tracking-wider py-2.5 rounded-full border border-white/10"
                    >
                      <Shield className="h-3.5 w-3.5" />
                      <span>Admin Control Center</span>
                    </Link>
                  )}
                  <button
                    onClick={handleLogout}
                    className="flex justify-center items-center space-x-2 bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white font-bold uppercase text-[10px] tracking-wider py-2.5 rounded-full border border-rose-550/20"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Log Out</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <Link
                  to="/auth/login"
                  onClick={() => setIsOpen(false)}
                  className="flex justify-center items-center bg-white/5 [.light_&]:bg-black/5 hover:bg-white/10 border border-white/10 text-white [.light_&]:text-neutral-850 font-bold uppercase text-[10px] tracking-wider py-3 rounded-full"
                >
                  Login
                </Link>
                <Link
                  to="/auth/signup"
                  onClick={() => setIsOpen(false)}
                  className="flex justify-center items-center bg-amber-500 hover:bg-amber-600 text-black font-black uppercase text-[10px] tracking-wider py-3 rounded-full shadow-md"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
