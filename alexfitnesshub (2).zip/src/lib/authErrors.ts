/**
 * Utility to map Firebase Auth error codes into human-friendly explanations.
 * This guarantees production-ready clarity when errors occur on localhost or in production deployment environments.
 */
export function translateFirebaseAuthError(code: string, originalMessage?: string): string {
  console.error("[FIREBASE AUTH ERROR]:", { code, message: originalMessage });

  switch (code) {
    // Basic account errors
    case 'auth/invalid-email':
      return 'The email address format is invalid. Please double check and try again.';
    case 'auth/user-disabled':
      return 'This user account has been disabled. Please contact Support for access.';
    case 'auth/user-not-found':
      return 'No athlete profile was found for this email address. Please register an account first.';
    case 'auth/wrong-password':
      return 'Incorrect password entered. Please reset your password if you forgot it.';
    case 'auth/invalid-credential':
      return 'Invalid account credentials. Please verify your email and password.';
    case 'auth/email-already-in-use':
      return 'This email address is already registered. Please login or reset your password.';
    case 'auth/weak-password':
      return 'The password is too weak. It must be at least 6 characters long with high security standards.';

    // Interactive popup errors
    case 'auth/popup-blocked':
      return 'The secure Google login popup was blocked by your browser. Please allow popups for this domain, or use the "Google Redirect Sign-In" option below.';
    case 'auth/popup-closed-by-user':
      return 'The login browser window was closed before completing authentication. Please try again.';
    case 'auth/cancelled-popup-request':
      return 'The authorization window request was cancelled due to a concurrent action. Please try again.';

    // General operational errors
    case 'auth/operation-not-allowed':
      return 'The requested sign-in method is currently disabled in the Firebase console. Please enable Google and Email/Password providers.';
    case 'auth/network-request-failed':
      return 'A network connectivity issue occurred. If you are in production, please verify that this customized domain is registered under the "Authorized Domains" settings in your Firebase console.';
    case 'auth/unauthorized-domain':
      return 'Unauthorized Domain. This deployed URL is not included in the "Authorized Domains" list in your Firebase console. Go to Authentication > Settings > Authorized Domains to allowlist it.';
    case 'auth/too-many-requests':
      return 'Access blocked due to excessive unusual activity. Please wait a few minutes and try again.';
    case 'auth/requires-recent-login':
      return 'This sensitive operation requires a recent session login. Please log out and back in to verify identity.';

    default:
      if (originalMessage?.includes('unauthorized-domain') || originalMessage?.includes('unauthorized domain')) {
        return 'Unauthorized Domain. Please register your deployed URL/domain under Firebase Authentication > Settings > Authorized Domains.';
      }
      return originalMessage || 'An unexpected error occurred during raw authorization. Please view browser logs for details.';
  }
}
