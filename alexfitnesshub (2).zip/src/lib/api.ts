export async function apiFetch<T = any>(path: string, options: RequestInit = {}, retries = 2): Promise<T> {
  const baseUrl = (import.meta as any).env?.VITE_API_BASE_URL || '';
  const url = path.startsWith('http') ? path : `${baseUrl}${path}`;
  
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  } as Record<string, string>;
  
  let attempt = 0;
  while (true) {
    try {
      const res = await fetch(url, {
        ...options,
        headers,
      });
      
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Express server responded with code ${res.status}`);
      }
      
      const payload = await res.json();
      return payload as T;
    } catch (err: any) {
      attempt++;
      if (attempt <= retries) {
        const delay = attempt * 1000;
        console.warn(`[API FETCH FAIL] Preflight/Request failed for ${path}. Retrying in ${delay}ms... (Attempt ${attempt}/${retries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      console.error(`[API FETCH HARD FAILURE] Path ${path} collapsed after ${attempt} retry loops.`, err);
      // Format details cleanly for the user UI
      const readableMessage = err instanceof Error ? err.message : String(err);
      throw new Error(readableMessage || "API Connection offline. Please confirm server internet connection or CORS configs.");
    }
  }
}
