import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';
import {   Dumbbell, 
  Home, 
  Zap, 
  ShieldAlert, 
  Sparkles, 
  Flame, 
  CheckCircle, 
  RefreshCw, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Camera, 
  Eye, 
  Lock, 
  Crown, 
  ArrowRight, 
  Layers, 
  AlertCircle,
  Search,
  Filter,
  Clock,
  ChevronRight,
  TrendingUp,
  UserCheck,
  Compass
} from 'lucide-react';
import { DetailedExercise, DETAILED_EXERCISES } from '../exercisesData';

interface WorkoutVideo {
  id: string;
  name: string;
  category: string;
  image: string;
  primaryMuscle: string;
  gripStyle: string;
  tempo: string;
  locked: boolean;
  instructions: string;
  subtitles: { time: number; text: string }[];
  telemetry: { label: string; normal: string; value: string }[];
}

const DEMO_VIDEOS: WorkoutVideo[] = [
  {
    id: '1',
    name: 'Barbell Bench Press',
    category: 'chest',
    image: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Bench-Press.gif',
    primaryMuscle: 'Pectoralis Major (Lower/Mid Fibers)',
    gripStyle: 'Pronated Overhand (1.5x Shoulder Width)',
    tempo: '3-1-1-0 (Eccentric Slow - Hold - Power Press)',
    locked: false,
    instructions: 'Lie back on a flat bench. Grip the barbell with hands slightly wider than shoulder-width. Lower the bar slowly to your chest, then press back up explosively.',
    subtitles: [
      { time: 0, text: "[Coach Alex]: Lie flat, retract scapula, and plant feet firmly. Grip with Pronated power." },
      { time: 4, text: "[Coach Alex]: Inhale deeply, expand lungs. Lower bar under 3s controlled kinetic descent." },
      { time: 9, text: "[Coach Alex]: Touch lower sternum gently. Hold for 1 second of isolated power stretch." },
      { time: 12, text: "[Coach Alex]: Push bar up brutally! Squeeze chest fibers at the terminal joint block." }
    ],
    telemetry: [
      { label: 'Elbow Flare Angle', normal: '45° - 60°', value: '48° (Optimal)' },
      { label: 'Spine Clearance Gap', normal: '1.5 - 2 inches', value: '1.7 inches' },
      { label: 'Bar Path Deviation', normal: '< 1.5 cm', value: '0.6 cm (Perfect)' }
    ]
  },
  {
    id: '2',
    name: 'Strict Dead-Hang Pullups',
    category: 'back',
    image: 'https://fitnessprogramer.com/wp-content/uploads/2021/03/Pull-Up.gif',
    primaryMuscle: 'Latissimus Dorsi & Rhomboids',
    gripStyle: 'Overhand Wide Grip',
    tempo: '2-1-2-1 (Controlled Drop - Full Hang - Explode Up)',
    locked: false,
    instructions: 'Hang from a bar. Pull your body upward until your chin clears the bar. Lower down with full control.',
    subtitles: [
      { time: 0, text: "[Captain Babatunde]: Hang dead with scapula active, ribcage compressed, and core zipped tight." },
      { time: 4, text: "[Captain Babatunde]: Drive elbow joints directly down towards your ribs. Pull with back energy." },
      { time: 8, text: "[Captain Babatunde]: Hold chin strictly over the bar line. Complete back pinch compression." },
      { time: 12, text: "[Captain Babatunde]: Under absolute military cadence, lower 2 seconds back to a dead-hang." }
    ],
    telemetry: [
      { label: 'Shoulder Hinge Range', normal: '120° - 15°', value: '115° (Excellent)' },
      { label: 'Kicking leg momentum', normal: '0% sway', value: '0% (Elite Static)' },
      { label: 'Chin Bar Clearance', normal: '> 2.0 inches', value: '3.4 inches' }
    ]
  },
  {
    id: '3',
    name: 'Deep Barbell Back Squats',
    category: 'legs',
    image: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/BARBELL-SQUAT.gif',
    primaryMuscle: 'Quadriceps Femoris & Gluteus Maximus',
    gripStyle: 'Overhand Tight (Back Shelf)',
    tempo: '3-2-1-0 (Deep Hinge - Active Pause - Ascend)',
    locked: false,
    instructions: 'Bar on upper traps, drop hips low ensuring thighs go parallel or deeper, press up through midfoot.',
    subtitles: [
      { time: 0, text: "[Coach Alex]: Stack bar across your upper trapezius shelf. Unrack with hip power." },
      { time: 4, text: "[Coach Alex]: Sit back as on a chair. Lower knees in line with foot direction." },
      { time: 8, text: "[Coach Alex]: Break parallel line! Drop beneath parallel to recruit glute and groin tissues." },
      { time: 12, text: "[Coach Alex]: Fire through midfoot! Maintain straight alignment of spine. Stand up!" }
    ],
    telemetry: [
      { label: 'Knee Translation Depth', normal: 'Parallel / Below', value: '-3.2 cm (Deep Parallel)' },
      { label: 'Spinal Alignment angle', normal: '15° - 35° incline', value: '26° (Excellent)' },
      { label: 'Midfoot Balance factor', normal: '> 95%', value: '98% (Absolute Center)' }
    ]
  },
  {
    id: '4',
    name: 'Hanging Core Leg Raises',
    category: 'core',
    image: 'https://fitnessprogramer.com/wp-content/uploads/2021/08/Hanging-Leg-Raises.gif',
    primaryMuscle: 'Rectus Abdominis (Lower Segment)',
    gripStyle: 'Medium Width Overhand',
    tempo: '2-1-2-1 (Power Ascend - Hold - Eccentric Return)',
    locked: false,
    instructions: 'Hang from rack, lift legs straight up to bar level for lower abs.',
    subtitles: [
      { time: 0, text: "[Coach Alex]: Hang vertically on pull-up bar. Zip stomach core muscles to neutralize swing." },
      { time: 4, text: "[Coach Alex]: Lift legs straight together. Target toe contact with the high bar." },
      { time: 8, text: "[Coach Alex]: Hold for 1s. Squeeze stomach hard to activate abdominal core walls." },
      { time: 12, text: "[Coach Alex]: Lower down with controlled back resistance. No swinging or kicking." }
    ],
    telemetry: [
      { label: 'Abdominal Activation', normal: '> 85%', value: '94% (High Intensity)' },
      { label: 'Sway Coefficient', normal: '< 5%', value: '2.1% (Superb Grip)' },
      { label: 'Lower Segment Angle', normal: '90° - 110°', value: '105° (Maximum)' }
    ]
  },
  {
    id: '5',
    name: 'Heavy Barbell Deadlift',
    category: 'back',
    image: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Deadlift.gif',
    primaryMuscle: 'Posterior Chain (Hamstrings, Glutes, Erector Spinae)',
    gripStyle: 'Mixed Grip (One Pronated, One Supinated)',
    tempo: '1-1-2-0 (Power Pull - Hinge Lock - Control Descent)',
    locked: true,
    instructions: 'Hinge at the hips, grip the bar, and pull back with strong glutes, hamstrings, and lower back engagement.',
    subtitles: [
      { time: 0, text: "[COACH EXCELLENCE] 🔒 UNLOCK PREMIUM FOR STRATEGIC LIFT TUTORIALS" }
    ],
    telemetry: []
  },
  {
    id: '6',
    name: 'Olympic Military Press',
    category: 'shoulders',
    image: 'https://fitnessprogramer.com/wp-content/uploads/2021/07/Barbell-Standing-Military-Press.gif',
    primaryMuscle: 'Deltoids anterior & Triceps Brachii',
    gripStyle: 'Overhand Narrow Grip',
    tempo: '2-1-1-0 (Overhead Lock - Hold - Slow Drop)',
    locked: true,
    instructions: 'Stand tall with core zipped, press barbell overhead, locking out at the peak.',
    subtitles: [
      { time: 0, text: "[COACH EXCELLENCE] 🔒 UNLOCK PREMIUM FOR STRATEGIC LIFT TUTORIALS" }
    ],
    telemetry: []
  },
  {
    id: '7',
    name: 'Standing Bicep Isolation Curls',
    category: 'arms',
    image: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Barbell-Curl.gif',
    primaryMuscle: 'Biceps Brachii (Long & Short Head)',
    gripStyle: 'Underhand Shoulder-width Grip',
    tempo: '3-0-1-1 (Isolation Power curl - Squeeze peak - Slow descend)',
    locked: true,
    instructions: 'Curl bar up keeping elbows pinned to ribs. Squeeze biceps.',
    subtitles: [
      { time: 0, text: "[COACH EXCELLENCE] 🔒 UNLOCK PREMIUM FOR STRATEGIC LIFT TUTORIALS" }
    ],
    telemetry: []
  }
];

export default function Workouts() {
  const { user: authUser, loading: authLoading } = useAuth();
  const [activeConsoleTab, setActiveConsoleTab] = useState<'video_lab' | 'exercise_database' | 'routine_generator'>('video_lab');
  
  // Video demonstrator state variables
  const [activeVideo, setActiveVideo] = useState<WorkoutVideo>(DEMO_VIDEOS[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [playTime, setPlayTime] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  
  // Real-time AI Camera Form Simulator State
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraLoading, setCameraLoading] = useState<boolean>(false);
  const [aiScore, setAiScore] = useState<number>(92);
  const [spineLabel, setSpineLabel] = useState<string>('Normal alignment');
  const [wristLabel, setWristLabel] = useState<string>('Perfect stack');
  const [jointAngle, setJointAngle] = useState<number>(45);

  const isPremium = authUser?.subscriptionStatus === 'premium';
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // stopwatch timer states
  const [timerMode, setTimerMode] = useState<'workout' | 'rest'>('workout');
  const [timeLeft, setTimeLeft] = useState<number>(45); 
  const [timerPreset, setTimerPreset] = useState<number>(45);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [completedSets, setCompletedSets] = useState<number>(0);
  const [timerBanner, setTimerBanner] = useState<string | null>(null);
  
  // general filters
  const [activeMuscleFilter, setActiveMuscleFilter] = useState<string>('all');
  const [activeLevelFilter, setActiveLevelFilter] = useState<string>('all');
  const [activeObjectiveFilter, setActiveObjectiveFilter] = useState<string>('all');
  const [loggedWorkoutName, setLoggedWorkoutName] = useState<string>('Barbell Bench Press');
  const [loggedWorkoutSets, setLoggedWorkoutSets] = useState<number>(3);
  const [workoutLogs, setWorkoutLogs] = useState<{ id: string; name: string; sets: number; date: string }[]>(() => {
    try {
      const stored = localStorage.getItem('alexfit_workout_log');
      return stored ? JSON.parse(stored) : [
        { id: '1', name: 'Barbell flat press', sets: 4, date: 'May 28, 2026' },
        { id: '2', name: 'Strict Pullups', sets: 5, date: 'May 29, 2026' }
      ];
    } catch { return []; }
  });

  // MASSIVE DATABASE FILTER STATES
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dbCategoryFilter, setDbCategoryFilter] = useState<string>('all');
  const [dbMuscleFilter, setDbMuscleFilter] = useState<string>('all');
  const [dbDifficultyFilter, setDbDifficultyFilter] = useState<string>('all');
  const [dbEquipmentFilter, setDbEquipmentFilter] = useState<string>('all');
  const [selectedDbExercise, setSelectedDbExercise] = useState<DetailedExercise | null>(DETAILED_EXERCISES[0]);
  const [repSchemeGoal, setRepSchemeGoal] = useState<'muscleGrowth' | 'fatLoss' | 'strength' | 'endurance'>('muscleGrowth');

  // WORKOUT GENERATOR STATES
  const [genAge, setGenAge] = useState<number>(26);
  const [genGender, setGenGender] = useState<string>('male');
  const [genHeight, setGenHeight] = useState<number>(175);
  const [genWeight, setGenWeight] = useState<number>(80);
  const [genExperience, setGenExperience] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [genGoal, setGenGoal] = useState<'muscleGrowth' | 'fatLoss' | 'strength' | 'endurance'>('muscleGrowth');
  const [genStyle, setGenStyle] = useState<string>('gym');
  const [generatedPlan, setGeneratedPlan] = useState<{
    daily: { name: string; sets: number; reps: string; rest: string }[];
    weekly: { day: string; title: string; exercises: string[]; status: string }[];
    monthly: { week: string; focus: string; progressiveOverload: string }[];
  } | null>(null);
  const [apiResponseText, setApiResponseText] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Set up video loop simulation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && !activeVideo.locked) {
      interval = setInterval(() => {
        setPlayTime((prev) => {
          const next = prev + (0.5 * playbackSpeed);
          if (next >= 15) {
            return 0; // Loop seamlessly inside 15s sequence
          }
          return next;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, activeVideo]);

  // Handle active video choice and auto restart clock
  const selectTargetVideo = (video: WorkoutVideo) => {
    if (video.locked && !isPremium) {
      setActiveVideo(video);
      setIsPlaying(false);
      setPlayTime(0);
      return;
    }
    setActiveVideo(video);
    setPlayTime(0);
    setIsPlaying(true);
  };

  // Get active subtitle matching playhead clock
  const getSubtitle = () => {
    if (activeVideo.locked && !isPremium) {
      return "🔒 PREMIUM SECURITY SHIELD: Access to this strategic guide is locked.";
    }
    const currentSub = [...activeVideo.subtitles]
      .reverse()
      .find((sub) => playTime >= sub.time);
    return currentSub ? currentSub.text : "...";
  };

  const handleToggleCamera = async () => {
    if (cameraActive) {
      setCameraActive(false);
      if (videoRef.current && videoRef.current.srcObject) {
         const stream = videoRef.current.srcObject as MediaStream;
         stream.getTracks().forEach(track => track.stop());
         videoRef.current.srcObject = null;
      }
      return;
    }

    setCameraLoading(true);
    try {
      const constraints = { video: { width: 320, height: 240 } };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 300);
    } catch (err) {
      console.warn("Camera hardware access sandboxed inside iframe.");
      setCameraActive(true);
    } finally {
      setCameraLoading(false);
    }
  };

  // Simulate joint oscillations while playback ticks
  useEffect(() => {
    if (cameraActive) {
      const timer = setInterval(() => {
        setAiScore(() => Math.floor(Math.random() * 6) + 93);
        setJointAngle((prev) => {
          let next = prev + (Math.random() > 0.5 ? 4 : -4);
          if (next > 75) next = 40;
          if (next < 35) next = 40;
          return next;
        });
        const spineStates = ['Optimized spine alignment', 'Excellent pelvic positioning', 'Neutral spinal tracking'];
        setSpineLabel(spineStates[Math.floor(Math.random() * spineStates.length)]);
      }, 1500);
      return () => clearInterval(timer);
    }
  }, [cameraActive]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && timerRunning) {
      setTimerRunning(false);
      if (timerMode === 'workout') {
        const nextSets = completedSets + 1;
        setCompletedSets(nextSets);
        setTimerBanner(`💪 EXERCISE SET ${nextSets} COMPLETED! Rest interval begins!`);
        setTimerMode('rest');
        setTimeLeft(30);
        setTimerRunning(true);
      } else {
        setTimerBanner("🔥 REST COOLDOWN EXPIRED! Power up next dynamic set!");
        setTimerMode('workout');
        setTimeLeft(timerPreset);
        setTimerRunning(true);
      }
      setTimeout(() => setTimerBanner(null), 3500);
    }
    return () => clearInterval(interval);
  }, [timerRunning, timeLeft, timerMode, timerPreset, completedSets]);

  // Synchronized via subscription hooks

  const handleAddWorkoutLog = (name: string, setsCount: number) => {
    const fresh = {
      id: String(Date.now()),
      name,
      sets: setsCount,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    };
    const nextLogs = [fresh, ...workoutLogs];
    setWorkoutLogs(nextLogs);
    localStorage.setItem('alexfit_workout_log', JSON.stringify(nextLogs));
    setTimerBanner(`✅ Logged: ${name} (${setsCount} sets) successfully recorded!`);
    setTimeout(() => setTimerBanner(null), 3000);
  };

  // EXERCISE DATABASE SEARCH & FILTER CONTROLLER
  const filteredDbExercises = DETAILED_EXERCISES.filter((ex) => {
    const matchesSearch = searchQuery === '' || 
      ex.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      ex.primaryMuscles.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ex.secondaryMuscles.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ex.equipment.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = dbCategoryFilter === 'all' || ex.category === dbCategoryFilter;
    const matchesMuscle = dbMuscleFilter === 'all' || ex.muscleGroup === dbMuscleFilter;
    const matchesDifficulty = dbDifficultyFilter === 'all' || ex.difficulty === dbDifficultyFilter;
    
    let matchesEquipment = true;
    if (dbEquipmentFilter !== 'all') {
      if (dbEquipmentFilter === 'barbell') matchesEquipment = ex.equipment.toLowerCase().includes('barbell');
      if (dbEquipmentFilter === 'dumbbell') matchesEquipment = ex.equipment.toLowerCase().includes('dumbbell');
      if (dbEquipmentFilter === 'bodyweight') matchesEquipment = ex.equipment.toLowerCase().includes('bodyweight') || ex.equipment.toLowerCase().includes('none');
      if (dbEquipmentFilter === 'machine') matchesEquipment = ex.equipment.toLowerCase().includes('machine') || ex.equipment.toLowerCase().includes('cable');
    }

    return matchesSearch && matchesCategory && matchesMuscle && matchesDifficulty && matchesEquipment;
  });

  // INTELLIGENT ROUTINE FORM GENERATORS
  const handleGeneratePrivatePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setApiResponseText(null);

    // Formulate rule-based client side customized template that is extremely robust and contains real exercises from DETAILED_EXERCISES
    const matchExercises = DETAILED_EXERCISES.filter(ex => 
      (genStyle === 'all' || ex.category === genStyle || (genStyle === 'gym' && ex.category === 'gym')) &&
      (genGoal === 'muscleGrowth' ? ex.muscleGroup !== 'cardio' : true)
    ).slice(0, 5);

    const fallbacks = matchExercises.length > 0 ? matchExercises : DETAILED_EXERCISES.slice(0, 4);
    
    // rep scheme calculations based on user guidelines
    let setsValue = 3;
    let repsValue = "8-12";
    let restText = "60-90 seconds";
    let goalLabel = "Muscle Hypertrophy";

    if (genGoal === 'fatLoss') {
      setsValue = 4;
      repsValue = "12-15";
      restText = "45-60 seconds";
      goalLabel = "Fat Loss Shred";
    } else if (genGoal === 'strength') {
      setsValue = 5;
      repsValue = "3-6";
      restText = "2-3 minutes";
      goalLabel = "Force Production Strength";
    } else if (genGoal === 'endurance') {
      setsValue = 3;
      repsValue = "15-25";
      restText = "30-45 seconds";
      goalLabel = "Oxidative Endurance Conditioning";
    }

    const calculatedDaily = fallbacks.map(ex => ({
      name: ex.name,
      sets: setsValue,
      reps: repsValue,
      rest: restText
    }));

    const computedWeekly = [
      { day: "Monday", title: "Target Focus: Heavy Compound Overload", exercises: [fallbacks[0]?.name || "Bench Press", fallbacks[1]?.name || "Squats"], status: "Active Forge" },
      { day: "Tuesday", title: "Target Focus: High-Tension Isolation Workouts", exercises: [fallbacks[2]?.name || "Lateral Raises", fallbacks[3]?.name || "Hammer Curls"], status: "Active Forge" },
      { day: "Wednesday", title: "Active Recovery & Dynamic Mobility Flow", exercises: ["Incline Walking", "Yoga Deep Stretching Core Active"], status: "Rest Protocol" },
      { day: "Thursday", title: "Unilateral Correction & Core Strength Core", exercises: [fallbacks[1]?.name || "Romanian Deadlift", fallbacks[4]?.name || "Hanging Leg Raises"], status: "Active Forge" },
      { day: "Friday", title: "Metabolic Threshold conditioning or HIIT Power", exercises: ["Cardio Sprint Intervals", "Lats Wide Grip Pullups"], status: "Active Forge" },
      { day: "Saturday", title: "Optional Active Recovery or Dynamic Swimming", exercises: ["Steady State Cardio"], status: "Rest Option" },
      { day: "Sunday", title: "Full System Active Tissue Repair", exercises: ["Proactive Rest & Hydration Protocol"], status: "Complete Rest" }
    ];

    const computedMonthly = [
      { week: "Week 1", focus: "Biomechanical Neuromuscular Adaptations", progressiveOverload: "Set base parameters using comfortable heavy loads, focusing strictly on target tempo and form metrics." },
      { week: "Week 2", focus: "Volume Increment & Metabolic Saturation", progressiveOverload: "Increase load intensity by +2.5% to +5% while keeping sets and reps consistent to trigger tension." },
      { week: "Week 3", focus: "Peak Force overload and System Fatigue", progressiveOverload: "Push sets to absolute mechanical failure on core lifts, extending total sets volume." },
      { week: "Week 4", focus: "Strategic Tissue Repair and Active Deload", progressiveOverload: "Reduce total training sets by 40% and drop weights to 65% of max to allow super-compensating." }
    ];

    // Attempt actual Gemini fetch if they are logged in and premium
    if (authUser) {
      try {
        if (authUser.subscriptionStatus === 'premium') {
          const data = await apiFetch<any>('/api/coach/ask', {
            method: 'POST',
            body: JSON.stringify({
              userId: authUser.id,
              goalSearch: `${goalLabel} Workout Program (Athlete Age: ${genAge}, Gender: ${genGender}, Weight: ${genWeight}kg, Height: ${genHeight}cm, Level: ${genExperience}, Style: ${genStyle})`,
              user: authUser
            })
          });
          if (data && data.answer) {
            setApiResponseText(data.answer);
          }
        }
      } catch (err) {
        console.warn("External API fetch bypassed or failed. Falling back to local program builder.", err);
      }
    }

    // Set local compiled program
    setGeneratedPlan({
      daily: calculatedDaily,
      weekly: computedWeekly,
      monthly: computedMonthly
    });

    setIsGenerating(false);
  };

  // Pre-made quick searches
  const searchSuggestions = [
    { label: "🔥 Bench press", query: "Bench Press" },
    { label: "🦵 Heavy squatting", query: "Squat" },
    { label: "🎒 Home calisthenics", query: "calisthenics" },
    { label: "🏃 Intense HIIT", query: "Hiit" },
    { label: "🛡️ Military conditioning", query: "military" },
    { label: "🦾 Arms overload", query: "Bicep" }
  ];

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500 font-bold" />
      </div>
    );
  }

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
        {/* Cinematic Backdrop Pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-[120px]"></div>
        
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-lg w-full text-center space-y-6 shadow-2xl relative z-10">
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-syne text-3xl font-extrabold tracking-wide uppercase">ELITE WORKOUTS LOCKED</h2>
            <p className="text-[10px] text-amber-500 font-mono tracking-widest mt-1.5 uppercase">ATHLETE AUTHENTICATION & PREMIUM SUBSCRIPTION REQUIRED</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans font-light">
            Gain absolute, unrestricted access to the master compound exercise databases, real-time biomechanics skeleton analysis, tactical conditioning regimens, and AI-powered programs.
          </p>
          <div className="pt-2 flex flex-col gap-3">
            <Link
              to="/pricing"
              className="w-full bg-amber-500 hover:bg-gold hover:scale-[1.02] text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm block transition-all font-mono"
            >
              Get Premium Access Now
            </Link>
            <Link
              to="/"
              className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-bold uppercase text-xs tracking-widest py-3 rounded-sm block transition-all font-mono"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white pt-24 min-h-screen relative overflow-hidden app-bg">
      {/* Dynamic Background subtle vector layout pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 z-10">
        
        {/* Cinematic Header Block */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="text-amber-500 uppercase text-xs font-black tracking-widest font-mono">NEURAL COACH MATRIX</span>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white [.light_&]:text-neutral-900 tracking-tighter leading-none mt-2 uppercase">
            ALEXFIT<span className="text-amber-500"> COREGUILD</span>
          </h1>
          <p className="text-neutral-400 [.light_&]:text-neutral-600 font-light mt-3 text-sm italic">
            Unlock heavy compound mechanics, query a massive database of verified athletic instructions, and generate comprehensive custom training regimes.
          </p>
        </div>

        {/* SWISS MODERN GLOWING NAVIGATION CONSOLE BUTTONS */}
        <div className="flex border-b border-white/10 [.light_&]:border-black/5 mb-8 md:mb-12 overflow-x-auto gap-2 p-1 bg-neutral-950/80 [.light_&]:bg-neutral-200/50 rounded backdrop-blur-md">
          {[
            { id: 'video_lab', label: '🎬 Biomechanics Video Lab', desc: 'Skeletal Tracking & Timers' },
            { id: 'exercise_database', label: '📖 Massive Exercise Library', desc: 'Instructions & Anatomy Models' },
            { id: 'routine_generator', label: '⚡ Smart Program Generator', desc: 'Daily, Weekly, Monthly splits' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveConsoleTab(tab.id as any)}
              className={`flex-grow text-left px-5 py-3.5 rounded transition-all shrink-0 ${
                activeConsoleTab === tab.id
                  ? 'bg-amber-500 text-black font-extrabold shadow-lg shadow-amber-500/20'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="block text-sm uppercase tracking-wide font-bold">{tab.label}</span>
              <span className={`block text-[10px] font-medium font-mono mt-0.5 ${activeConsoleTab === tab.id ? 'text-black/80' : 'text-neutral-500'}`}>{tab.desc}</span>
            </button>
          ))}
        </div>

        {/* ————————————————————————————————————————————————————————— */}
        {/* MODULE 1: BIOMECHANICS VIDEO LAB & TIMERS */}
        {/* ————————————————————————————————————————————————————————— */}
        {activeConsoleTab === 'video_lab' && (
          <div className="space-y-12 animate-fade-in text-left">
            
            {/* Split screen content layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
              
              {/* Left Playlist Sidebar */}
              <div className="lg:col-span-4 bg-neutral-950/80 [.light_&]:bg-neutral-100 border border-white/10 [.light_&]:border-black/5 p-5 rounded-sm flex flex-col justify-between app-card">
                <div>
                  <h3 className="font-bebas text-lg tracking-widest text-white [.light_&]:text-neutral-900 uppercase border-b border-white/5 pb-2 mb-4 flex items-center gap-2">
                    <Layers className="h-4.5 w-4.5 text-amber-500" />
                    <span>Video Demonstrators</span>
                  </h3>
                  
                  <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                    {DEMO_VIDEOS.map((vid) => {
                      const isVidActive = activeVideo.id === vid.id;
                      const isPremiumLocked = vid.locked && !isPremium;
                      
                      return (
                        <button
                          key={vid.id}
                          onClick={() => selectTargetVideo(vid)}
                          className={`w-full text-left p-3.5 rounded border transition-all flex items-center justify-between text-xs font-semibold relative ${
                            isVidActive 
                              ? 'bg-amber-505 bg-amber-500 text-black border-amber-500 font-extrabold shadow-md' 
                              : 'bg-black/40 [.light_&]:bg-white text-neutral-300 [.light_&]:text-neutral-800 border-white/10 [.light_&]:border-black/5 hover:border-amber-500/30'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <span className={`w-2 h-2 rounded-full ${isVidActive ? 'bg-black' : isPremiumLocked ? 'bg-gold/40' : 'bg-emerald-500'}`}></span>
                            <span className="truncate uppercase font-bold tracking-wider">{vid.name}</span>
                          </div>
                          
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className={`text-[9px] px-1.5 py-0.5 rounded-sm font-bold uppercase font-mono ${
                              isVidActive ? 'bg-black/10 text-black' : 'bg-white/5 text-neutral-450'
                            }`}>
                              {vid.category}
                            </span>
                            {isPremiumLocked && (
                              <Lock className={`h-3.5 w-3.5 ${isVidActive ? 'text-black' : 'text-amber-500'}`} />
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="mt-6 p-4 bg-white/5 [.light_&]:bg-black/5 border border-white/10 [.light_&]:border-black/5 rounded-sm">
                  <span className="text-[9px] text-[#888] uppercase block tracking-widest mb-1 font-mono">Cadence Tempo Code:</span>
                  <p className="text-xs text-neutral-300 [.light_&]:text-neutral-700 italic leading-normal">
                    Learn optimal concentric/eccentric speed formulas directly from Coach Alex's animations.
                  </p>
                </div>
              </div>

              {/* Middle Playback Window */}
              <div className="lg:col-span-5 bg-neutral-950 border border-white/10 rounded-sm overflow-hidden flex flex-col justify-between relative shadow-2xl min-h-[460px] app-card group group/player">
                
                {/* locked overlay */}
                {activeVideo.locked && !isPremium && (
                  <div className="absolute inset-0 bg-black/95 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-8 text-center animate-fade-in">
                    <div className="w-16 h-16 rounded-full bg-gold/15 border border-gold/30 flex items-center justify-center text-amber-500 mb-4 animate-bounce">
                      <Crown className="h-8 w-8" />
                    </div>
                    <h3 className="font-bebas text-3xl font-black text-white tracking-widest uppercase italic leading-none">
                      VIDEO LOCKED <br />
                      <span className="text-amber-500 font-mono text-lg tracking-wider">(PREMIUM LEVEL)</span>
                    </h3>
                    <p className="text-neutral-400 text-xs mt-3 max-w-xs leading-relaxed italic">
                      Upgrade to our premium tier to unlock high-definition compound movement demonstrations and precision form analyzers.
                    </p>
                    
                    <div className="flex flex-col gap-3 mt-6 w-full max-w-xs">
                      <Link
                        to="/pricing"
                        className="bg-amber-500 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded hover:brightness-110 shadow-lg shadow-amber-500/10 text-center flex items-center justify-center gap-1.5"
                      >
                        <span>Upgrade Account</span>
                        <ArrowRight className="h-4 w-4" />
                      </Link>
                    </div>
                  </div>
                )}

                {/* Scanline decoration */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-amber-500/20 shadow-md pointer-events-none z-15"></div>

                <div className="relative flex-grow bg-black flex items-center justify-center overflow-hidden">
                  <img
                    src={activeVideo.image}
                    alt={activeVideo.name}
                    className={`w-full h-full object-cover transition-all duration-700 ${
                      isPlaying ? 'brightness-[0.75] scale-105' : 'brightness-[0.4]'
                    }`}
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Grid layout lines */}
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:1.8rem_1.8rem]"></div>

                  {!activeVideo.locked && (
                    <div className="absolute inset-x-4 top-4 flex justify-between pointer-events-none text-white z-10 font-mono text-[9px]">
                      <div className="bg-black/75 px-2 py-1 rounded border border-white/10 backdrop-blur-sm">
                        <span className="text-amber-500">LAB_REC: </span>
                        <span>ANALYZING_KINEMATICS</span>
                      </div>
                      <div className="bg-black/75 px-2 py-1 rounded border border-white/10 backdrop-blur-sm uppercase">
                        <span>FPS: 60 // 1080P</span>
                      </div>
                    </div>
                  )}

                  {/* Playhead toggle overlay button */}
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="absolute p-4 rounded-full bg-black/60 hover:bg-amber-500 hover:text-black hover:scale-110 border border-white/10 text-white transition-all z-20 backdrop-blur-sm opacity-0 group-hover:opacity-100 group-hover/player:opacity-100 duration-300"
                  >
                    {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                  </button>
                </div>

                {/* active subtitle strip */}
                <div className="bg-neutral-900 [.light_&]:bg-neutral-200 p-3.5 border-t border-b border-white/10 [.light_&]:border-black/5 text-center text-xs text-amber-500 font-extrabold italic min-h-[54px] flex items-center justify-center px-6">
                  {getSubtitle()}
                </div>

                {/* manual play bar */}
                <div className="p-4 bg-black/95 space-y-3 opacity-0 group-hover:opacity-100 group-hover/player:opacity-100 transition-opacity duration-300">
                  <div className="relative w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="absolute top-0 left-0 h-full bg-amber-500 rounded-full transition-all duration-300"
                      style={{ width: `${(playTime / 15) * 100}%` }}
                    ></div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <div className="flex items-center space-x-2.5 text-neutral-400">
                      <Clock className="h-3.5 w-3.5" />
                      <span className="text-white font-bold">
                        00:{playTime < 10 ? `0${Math.floor(playTime)}` : Math.floor(playTime)}
                      </span>
                      <span>/</span>
                      <span>00:15</span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setPlaybackSpeed(prev => prev === 1 ? 0.5 : 1)}
                        className="px-2.5 py-1 rounded-sm bg-white/5 border border-white/10 hover:border-amber-500/30 text-white text-[10px] font-bold"
                      >
                        {playbackSpeed === 1 ? '1.0x NORMAL' : '0.5x SLOW MOTION'}
                      </button>
                    </div>
                  </div>
                </div>

              </div>

              {/* Right AI Camera Simulator */}
              <div className="lg:col-span-3 bg-neutral-950/80 [.light_&]:bg-neutral-100 border border-white/10 [.light_&]:border-black/5 p-5 rounded-sm flex flex-col justify-between app-card">
                <div>
                  <h3 className="font-bebas text-lg tracking-widest text-white [.light_&]:text-neutral-900 uppercase border-b border-white/5 pb-2 mb-4 flex items-center gap-2">
                    <Camera className="h-4.5 w-4.5 text-amber-500" />
                    <span>AI Video Scanner</span>
                  </h3>

                  <p className="text-xs text-neutral-400 [.light_&]:text-neutral-600 leading-relaxed mb-4">
                    Replicate the target form parameters using our live web camera computer-vision feedback overlay.
                  </p>

                  <div className="relative h-44 bg-black border border-white/15 rounded-sm overflow-hidden flex flex-col justify-center items-center">
                    {cameraActive ? (
                      <>
                        <video 
                          ref={videoRef} 
                          autoPlay 
                          playsInline 
                          className="absolute inset-0 w-full h-full object-cover opacity-60 scale-x-[-1]"
                        />
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <div className="w-20 h-20 border-2 border-emerald-500/80 animate-pulse relative">
                            <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-emerald-400"></div>
                            <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-emerald-400"></div>
                            <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-emerald-400"></div>
                            <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-emerald-400"></div>
                          </div>
                          
                          <svg className="absolute inset-0 w-full h-full text-emerald-500 animate-pulse" strokeWidth="1.2" fill="none">
                            <line x1="50" y1="70" x2="150" y2="70" stroke="currentColor" />
                            <line x1="100" y1="60" x2="100" y2="120" stroke="currentColor" />
                            <circle cx="50" cy="70" r="3" fill="#10B981" />
                            <circle cx="150" cy="70" r="3" fill="#10B981" />
                          </svg>
                        </div>
                      </>
                    ) : (
                      <div className="text-center p-4">
                        <Eye className="h-7 w-7 text-neutral-600 mx-auto mb-2 animate-pulse" />
                        <span className="text-[10px] text-neutral-400 uppercase tracking-widest block font-bold">Biometrics Offline</span>
                        <span className="text-[9px] text-neutral-600 block mt-1 font-mono">Press button below to initiate scan</span>
                      </div>
                    )}

                    {cameraActive && (
                      <div className="absolute bottom-2 left-2 bg-black/85 border border-emerald-500/30 px-2 py-0.5 rounded-sm font-mono text-[9px] text-emerald-400 flex items-center gap-1">
                        <span className="w-1 h-1 rounded-full bg-emerald-500"></span>
                        <span>SCORE: {aiScore}%</span>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={handleToggleCamera}
                    disabled={cameraLoading}
                    className={`w-full mt-3 text-center text-[10px] py-2.5 font-bold uppercase tracking-widest transition-all rounded-sm flex items-center justify-center gap-2 ${
                      cameraActive 
                        ? 'bg-rose-950 border border-rose-950 text-rose-300' 
                        : 'bg-amber-500 text-black hover:brightness-110 font-bold'
                    }`}
                  >
                    {cameraLoading ? (
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    ) : cameraActive ? (
                      <span>Terminate Analyzer</span>
                    ) : (
                      <span>Activate AI Scanner</span>
                    )}
                  </button>
                </div>

                {cameraActive && !activeVideo.locked && (
                  <div className="mt-4 p-3 bg-black border border-white/5 space-y-1.5 font-mono text-[9px] text-left">
                    <div className="text-neutral-500 uppercase tracking-widest text-[8px] border-b border-white/5 pb-1">Joint Readings:</div>
                    <div className="flex justify-between">
                      <span>Vertebra status:</span>
                      <span className="text-emerald-400">{spineLabel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Knee degrees:</span>
                      <span className="text-emerald-400">{jointAngle}°</span>
                    </div>
                  </div>
                )}
              </div>

            </div>

            {/* Timers and interactive logs below */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              
              {/* Circular Stopwatch Area */}
              <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/10 [.light_&]:border-black/5 p-6 rounded shadow-xl flex flex-col justify-between relative overflow-hidden app-card">
                <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
                
                <div>
                  <div className="flex items-center justify-between border-b border-white/5 pb-3 mb-4">
                    <div className="flex items-center space-x-2">
                      <Flame className="h-5 w-5 text-amber-500 animate-pulse text-amber-400" />
                      <h3 className="font-bebas text-lg font-bold text-white [.light_&]:text-neutral-900 uppercase">Set Rest Stopwatch</h3>
                    </div>
                    <span className="text-[9px] font-mono font-bold tracking-widest px-2 py-0.5 rounded border bg-rose-500/10 text-rose-500 border-rose-500/20">
                      {timerMode === 'workout' ? 'ACTIVE LIFT' : 'REST INTERVAL'}
                    </span>
                  </div>

                  {timerBanner && (
                    <div className="bg-amber-500/10 border border-amber-500/30 text-amber-500 font-mono text-[10px] uppercase text-center p-2 rounded mb-4 animate-fade-in font-bold">
                      {timerBanner}
                    </div>
                  )}

                  <div className="flex flex-col items-center justify-center py-4">
                    <div className="relative w-36 h-36 rounded-full border-2 border-white/10 flex flex-col items-center justify-center bg-black/40">
                      <span className="font-bebas text-5xl font-black text-white [.light_&]:text-neutral-905 leading-none text-amber-500">
                        {timeLeft}s
                      </span>
                      <span className="text-[8px] text-neutral-400 font-mono tracking-widest uppercase mt-1">
                        {timerMode === 'workout' ? 'TIMING' : 'REST'}
                      </span>
                    </div>
                  </div>

                  {/* presets */}
                  <div className="grid grid-cols-5 gap-1 mb-5">
                    {[30, 45, 60, 90, 120].map((preset) => (
                      <button
                        key={preset}
                        onClick={() => {
                          setTimerPreset(preset);
                          setTimeLeft(preset);
                          setTimerRunning(false);
                          setTimerMode('workout');
                        }}
                        className={`text-[9px] font-mono py-1.5 border rounded-sm transition-colors ${
                          timerPreset === preset 
                            ? 'bg-amber-505 bg-amber-500 text-black border-amber-500 font-bold' 
                            : 'bg-black/40 text-neutral-400 border-white/10 hover:text-white'
                        }`}
                      >
                        {preset}s
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setTimerRunning(!timerRunning)}
                      className={`py-2 px-4 rounded-sm text-xs font-bold uppercase tracking-wider transition-all ${
                        timerRunning ? 'bg-rose-600 text-white' : 'bg-amber-500 text-black font-black'
                      }`}
                    >
                      {timerRunning ? 'PAUSE' : 'START'}
                    </button>
                    <button
                      onClick={() => {
                        setTimeLeft(timerPreset);
                        setTimerRunning(false);
                      }}
                      className="bg-neutral-900 text-neutral-350 border border-neutral-800 py-2 rounded-sm text-xs uppercase"
                    >
                      RESET
                    </button>
                    <button
                      onClick={() => {
                        setTimerRunning(false);
                        setTimerMode(timerMode === 'workout' ? 'rest' : 'workout');
                        setTimeLeft(timerMode === 'workout' ? 30 : timerPreset);
                      }}
                      className="bg-neutral-900 text-amber-500 border border-neutral-800 py-2 rounded-sm text-xs uppercase"
                    >
                      SKIP
                    </button>
                  </div>
                </div>

                <div className="border-t border-white/15 pt-4 mt-4 font-mono text-xs flex justify-between items-center text-neutral-400">
                  <span>COMPLETED WORKOUT SETS:</span>
                  <span className="font-bebas text-lg text-white [.light_&]:text-neutral-900 font-black tracking-widest">{completedSets} sets</span>
                </div>
              </div>

              {/* Workout History logs */}
              <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/10 [.light_&]:border-black/5 p-6 rounded shadow-xl flex flex-col justify-between app-card text-left">
                <div>
                  <h3 className="font-bebas text-lg tracking-widest text-white [.light_&]:text-neutral-900 border-b border-white/5 pb-2 mb-4 uppercase">📋 LIFT RECONSTRUCTION RECORDER</h3>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex flex-col space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-neutral-400 font-mono">Exercise Name</label>
                      <input
                        type="text"
                        value={loggedWorkoutName}
                        onChange={(e) => setLoggedWorkoutName(e.target.value)}
                        className="bg-black/60 [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 p-2.5 rounded text-xs text-white [.light_&]:text-neutral-900 focus:border-amber-500 outline-none font-semibold"
                      />
                    </div>
                    <div className="flex flex-col space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-neutral-400 font-mono">Active Target Sets</label>
                      <input
                        type="number"
                        min="1"
                        max="12"
                        value={loggedWorkoutSets}
                        onChange={(e) => setLoggedWorkoutSets(Number(e.target.value))}
                        className="bg-black/60 [.light_&]:bg-white border border-white/10 p-2.5 rounded text-xs text-white [.light_&]:text-neutral-900 focus:border-amber-500 outline-none font-bold"
                      />
                    </div>
                    <button
                      onClick={() => handleAddWorkoutLog(loggedWorkoutName, loggedWorkoutSets)}
                      className="w-full bg-amber-500 text-black font-extrabold text-xs uppercase tracking-widest py-3 rounded hover:brightness-110"
                    >
                      COMMIT RECORD ENTRY
                    </button>
                  </div>
                </div>

                <div className="border-t border-white/5 pt-4 mt-2">
                  <span className="text-[9px] text-[#666] font-mono uppercase block mb-2">Saved History Entries:</span>
                  <div className="space-y-1.5 max-h-[110px] overflow-y-auto">
                    {workoutLogs.map((log) => (
                      <div key={log.id} className="bg-black/40 border border-white/5 p-2 rounded flex justify-between items-center text-[10px] font-mono text-neutral-300">
                        <span className="uppercase text-white font-bold">{log.name}</span>
                        <span>{log.sets} sets | {log.date}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* ————————————————————————————————————————————————————————— */}
        {/* MODULE 2: MASSIVE EXERCISE DATABASE */}
        {/* ————————————————————————————————————————————————————————— */}
        {activeConsoleTab === 'exercise_database' && (
          <div className="space-y-10 animate-fade-in text-left">
            
            {/* Suggestion bars and Search Block */}
            <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/10 p-6 rounded shadow-xl app-card">
              <div className="flex flex-col md:flex-row gap-4 items-stretch">
                
                {/* Real-time search query box */}
                <div className="flex-grow relative">
                  <Search className="absolute left-3 top-3.5 h-4.5 w-4.5 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search by exercise name, target muscle working group, recommended equipment..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-black [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 rounded p-3.5 pl-10 text-sm text-white [.light_&]:text-neutral-900 focus:border-amber-500 outline-none font-medium"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-3 text-xs text-neutral-500 hover:text-white"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {/* Reset button */}
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setDbCategoryFilter('all');
                    setDbMuscleFilter('all');
                    setDbDifficultyFilter('all');
                    setDbEquipmentFilter('all');
                  }}
                  className="px-6 bg-neutral-900 hover:bg-neutral-805 text-neutral-300 hover:text-white border border-neutral-850 rounded text-xs font-bold uppercase tracking-widest"
                >
                  Clear Filters
                </button>
              </div>

              {/* Suggestions shortcuts */}
              <div className="flex flex-wrap items-center gap-2 mt-4">
                <span className="text-[10px] text-neutral-500 font-mono uppercase mr-1">Hot suggestions:</span>
                {searchSuggestions.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSearchQuery(item.query)}
                    className="bg-black/50 hover:bg-amber-500/10 border border-white/5 hover:border-amber-500/30 text-neutral-300 hover:text-amber-500 px-3 py-1.5 rounded-full text-xs font-medium transition-colors"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 12 PROFESSIONAL ATHLETIC CATEGORIZATIONS QUICK SELECTORS */}
            <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/10 p-6 rounded shadow-xl app-card space-y-4">
              <div className="flex items-center space-x-2">
                <Compass className="h-5 w-5 text-amber-500" />
                <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono uppercase">DYNAMIC CATEGORY PORTALS</span>
              </div>
              <h3 className="font-bebas text-lg text-white [.light_&]:text-neutral-900 tracking-wide uppercase">PROFESSIONAL ATHLETIC CLASSIFICATIONS</h3>
              <p className="text-[11px] text-neutral-450 leading-relaxed max-w-2xl">
                Quick-link to targeted physical objectives. Selecting a portal automatically configures compound variables, difficulty thresholds, and resistance plans instantly.
              </p>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 pt-2">
                {[
                  { label: "Beginner", desc: "Starter cadence", active: dbDifficultyFilter === 'Beginner', onClick: () => { setDbDifficultyFilter('Beginner'); setDbCategoryFilter('all'); } },
                  { label: "Intermediate", desc: "Overload protocols", active: dbDifficultyFilter === 'Intermediate', onClick: () => { setDbDifficultyFilter('Intermediate'); setDbCategoryFilter('all'); } },
                  { label: "Advanced", desc: "Elite output limits", active: dbDifficultyFilter === 'Advanced', onClick: () => { setDbDifficultyFilter('Advanced'); setDbCategoryFilter('all'); } },
                  { label: "Home Workout", desc: "Calisthenic focus", active: dbCategoryFilter === 'home', onClick: () => { setDbCategoryFilter('home'); setDbDifficultyFilter('all'); } },
                  { label: "Gym Workout", desc: "Barbells & loads", active: dbCategoryFilter === 'gym', onClick: () => { setDbCategoryFilter('gym'); setDbDifficultyFilter('all'); } },
                  { label: "Fat Loss", desc: "High heat shred", active: repSchemeGoal === 'fatLoss', onClick: () => { setRepSchemeGoal('fatLoss'); setDbCategoryFilter('all'); } },
                  { label: "Muscle Building", desc: "Sarcoplasmic growth", active: repSchemeGoal === 'muscleGrowth', onClick: () => { setRepSchemeGoal('muscleGrowth'); setDbCategoryFilter('all'); } },
                  { label: "Strength", desc: "Force production", active: repSchemeGoal === 'strength', onClick: () => { setRepSchemeGoal('strength'); setDbCategoryFilter('all'); } },
                  { label: "Calisthenics", desc: "Absolute static leverage", active: dbCategoryFilter === 'calisthenics', onClick: () => { setDbCategoryFilter('calisthenics'); setDbDifficultyFilter('all'); } },
                  { label: "HIIT", desc: "Cardiovascular peaks", active: searchQuery.toLowerCase() === 'hiit' || searchQuery.toLowerCase() === 'high intensity interval', onClick: () => { setSearchQuery('HIIT'); setDbCategoryFilter('all'); } },
                  { label: "Cardio", desc: "Aerobic oxygenation", active: dbCategoryFilter === 'cardio', onClick: () => { setDbCategoryFilter('cardio'); setDbDifficultyFilter('all'); } },
                  { label: "Mobility", desc: "Joint safety flexibility", active: searchQuery.toLowerCase() === 'stretch' || searchQuery.toLowerCase() === 'flexibility', onClick: () => { setSearchQuery('Stretch'); setDbCategoryFilter('all'); } }
                ].map((portal, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={portal.onClick}
                    className={`p-3.5 rounded-xl border text-left transition-all duration-300 transform hover:-translate-y-0.5 outline-none cursor-pointer flex flex-col justify-between min-h-[75px] ${
                      portal.active
                        ? 'bg-amber-500 border-amber-500 text-black shadow-lg shadow-amber-500/10 font-bold'
                        : 'bg-black border-white/5 hover:border-amber-500/40 text-white'
                    }`}
                  >
                    <span className="text-xs font-extrabold uppercase tracking-wide truncate block">{portal.label}</span>
                    <span className={`text-[8.5px] font-mono tracking-normal leading-normal line-clamp-2 block mt-1 ${portal.active ? 'text-black/70' : 'text-neutral-500'}`}>
                      {portal.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Advanced Filters Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="text-[9px] uppercase tracking-widest text-[#888] font-mono block mb-1.5 font-bold">Category</label>
                <select
                  value={dbCategoryFilter}
                  onChange={(e) => setDbCategoryFilter(e.target.value)}
                  className="w-full bg-neutral-950 [.light_&]:bg-white border border-white/11 p-2.5 text-xs font-semibold rounded focus:border-amber-500 outline-none text-neutral-350"
                >
                  <option value="all">ALL TRAINING CATEGORIES</option>
                  <option value="gym">Gym Workouts</option>
                  <option value="home">Home Bodyweight</option>
                  <option value="calisthenics">Calisthenics Conditioning</option>
                  <option value="cardio">Cardiovascular Exercises</option>
                  <option value="functional">Functional Athletic</option>
                  <option value="military">Military Bootcamp</option>
                  <option value="athletic">Athletic Agility</option>
                  <option value="yoga">Yoga Vinyasa</option>
                  <option value="pilates">Pilates Stability</option>
                </select>
              </div>

              <div>
                <label className="text-[9px] uppercase tracking-widest text-[#888] font-mono block mb-1.5 font-bold">Muscle Target</label>
                <select
                  value={dbMuscleFilter}
                  onChange={(e) => setDbMuscleFilter(e.target.value)}
                  className="w-full bg-neutral-950 [.light_&]:bg-white border border-white/11 p-2.5 text-xs font-semibold rounded focus:border-amber-500 outline-none text-neutral-350"
                >
                  <option value="all">ALL TARGET REGIONS</option>
                  <option value="chest">Chest Pectoralis</option>
                  <option value="back">Back Latissimus/Rhomboids</option>
                  <option value="shoulders">Shoulder Deltoids</option>
                  <option value="arms">Arms Triceps/Biceps</option>
                  <option value="legs">Legs Quadriceps/Glutes</option>
                  <option value="core">Core Rectus Abdominis</option>
                </select>
              </div>

              <div>
                <label className="text-[9px] uppercase tracking-widest text-[#888] font-mono block mb-1.5 font-bold">Equipment Needed</label>
                <select
                  value={dbEquipmentFilter}
                  onChange={(e) => setDbEquipmentFilter(e.target.value)}
                  className="w-full bg-neutral-950 [.light_&]:bg-white border border-white/11 p-2.5 text-xs font-semibold rounded focus:border-amber-500 outline-none text-neutral-350"
                >
                  <option value="all">ALL EQUIPMENT PLATFORMS</option>
                  <option value="barbell">Barbells Compound</option>
                  <option value="dumbbell">Dumbbells Unilateral</option>
                  <option value="bodyweight">No Equipment (Bodyweight)</option>
                  <option value="machine">Machines and Cables</option>
                </select>
              </div>

              <div>
                <label className="text-[9px] uppercase tracking-widest text-[#888] font-mono block mb-1.5 font-bold">Difficulty Level</label>
                <select
                  value={dbDifficultyFilter}
                  onChange={(e) => setDbDifficultyFilter(e.target.value)}
                  className="w-full bg-neutral-950 [.light_&]:bg-white border border-white/11 p-2.5 text-xs font-semibold rounded focus:border-amber-500 outline-none text-neutral-350"
                >
                  <option value="all">ALL ATHLETE LEVELS</option>
                  <option value="Beginner">Beginner Stage</option>
                  <option value="Intermediate">Intermediate Stage</option>
                  <option value="Advanced">Advanced Pro Stage</option>
                </select>
              </div>
            </div>

            {/* Split Database screen */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left results matrix */}
              <div className="lg:col-span-4 bg-neutral-950/40 [.light_&]:bg-neutral-100 p-4 border border-white/10 rounded-lg max-h-[600px] overflow-y-auto space-y-3 scrollbar-thin">
                <div className="flex justify-between items-center text-xs font-mono text-neutral-400 mb-2 border-b border-white/5 pb-2">
                  <span>SEARCH RESULTS</span>
                  <span className="text-amber-500 font-bold">{filteredDbExercises.length} records found</span>
                </div>

                {filteredDbExercises.length === 0 ? (
                  <div className="text-center py-16 text-neutral-500 italic text-sm">
                    No matching exercises in our database. Try a broader search keyword!
                  </div>
                ) : (
                  filteredDbExercises.map((ex) => (
                    <div
                      key={ex.id}
                      onClick={() => setSelectedDbExercise(ex)}
                      className={`p-3.5 rounded border transition-all cursor-pointer text-left relative overflow-hidden group ${
                        selectedDbExercise?.id === ex.id
                          ? 'bg-amber-500/10 border-amber-500 shadow-md'
                          : 'bg-neutral-950 [.light_&]:bg-white border-white/5 hover:border-amber-500/30'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <h4 className="font-bebas text-lg font-bold tracking-wide text-white [.light_&]:text-neutral-900 group-hover:text-amber-500 transition-colors uppercase leading-tight">
                            {ex.name}
                          </h4>
                          <span className="text-[10px] text-neutral-400 font-mono mt-1 block uppercase">
                            💪 {ex.primaryMuscles.split('(')[0]}
                          </span>
                        </div>
                        <span className={`text-[8px] font-mono uppercase tracking-widest px-2 py-0.5 rounded-sm shrink-0 border ${
                          ex.difficulty === 'Beginner' 
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                            : ex.difficulty === 'Intermediate' 
                              ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' 
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                        }`}>
                          {ex.difficulty}
                        </span>
                      </div>

                      <div className="flex gap-2 mt-3 items-center text-[9px] text-[#777] font-mono">
                        <span className="uppercase text-amber-500">{ex.category}</span>
                        <span>•</span>
                        <span>🛠️ {ex.equipment.split('&')[0]}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Right exercise specs view */}
              <div className="lg:col-span-8 bg-neutral-950/80 [.light_&]:bg-neutral-100 border border-white/10 rounded-lg p-6 md:p-8 shadow-2xl relative app-card">
                
                {selectedDbExercise ? (
                  <div className="space-y-6">
                    
                    {/* Header line */}
                    <div className="flex flex-col md:flex-row justify-between items-start gap-4 border-b border-white/10 [.light_&]:border-black/5 pb-4">
                      <div>
                        <div className="flex flex-wrap gap-2 mb-2">
                          <span className="bg-amber-500/10 border border-amber-500/30 text-amber-500 text-[9px] font-mono font-black py-0.5 px-2.5 rounded-sm uppercase tracking-widest">
                            {selectedDbExercise.category}
                          </span>
                          <span className="bg-neutral-900 border border-neutral-800 text-neutral-400 text-[9px] font-mono py-0.5 px-2.5 rounded-sm uppercase tracking-widest">
                            {selectedDbExercise.difficulty} STAGE
                          </span>
                        </div>
                        <h2 className="font-bebas text-3xl sm:text-4xl font-extrabold text-white [.light_&]:text-neutral-900 tracking-wide uppercase italic">
                          {selectedDbExercise.name}
                        </h2>
                        <span className="text-xs text-neutral-400 font-mono font-bold mt-1.5 block">
                          🛠️ SPECIFICATIONS SETUP: <span className="text-white [.light_&]:text-neutral-900 underline font-black">{selectedDbExercise.equipment}</span>
                        </span>
                      </div>

                      {/* Display thumbnail GIF securely */}
                      {selectedDbExercise.videoUrl && (
                        <div className="w-full md:w-36 h-24 bg-black border border-white/10 overflow-hidden rounded shadow-md shrink-0">
                          <img
                            src={selectedDbExercise.videoUrl}
                            alt={selectedDbExercise.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      )}
                    </div>

                    {/* Muscles Loaded bento blocks */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-black/60 p-4 border border-white/5 rounded">
                        <span className="text-[10px] text-amber-500 font-bold uppercase tracking-widest block font-mono">Primary Muscles Worked</span>
                        <p className="text-sm font-semibold tracking-wide text-neutral-200 mt-1 uppercase">
                          🎯 {selectedDbExercise.primaryMuscles}
                        </p>
                      </div>
                      <div className="bg-black/60 p-4 border border-white/5 rounded">
                        <span className="text-[10px] text-neutral-400 font-mono uppercase tracking-widest block font-bold">Secondary Auxiliary Muscles</span>
                        <p className="text-xs text-neutral-400 mt-1 uppercase">
                          🔗 {selectedDbExercise.secondaryMuscles}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step guidance timelines */}
                    <div>
                      <h4 className="font-bebas text-lg tracking-widest text-[#aaa] uppercase mb-3 font-bold">⚙️ EXECUTION PROFILE SEQUENCE</h4>
                      <ol className="space-y-3 pl-1">
                        {selectedDbExercise.instructions.map((step, idx) => (
                          <li key={idx} className="flex gap-4 text-xs leading-relaxed text-neutral-300">
                            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-amber-500/10 text-amber-400 font-mono font-bold text-[11px] shrink-0">
                              {idx + 1}
                            </span>
                            <span className="pt-0.5">{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>

                    {/* Common Mistakes Warning blocks */}
                    <div className="bg-rose-950/20 border border-rose-900/40 p-4 rounded text-left">
                      <div className="flex items-center gap-2 mb-2 text-rose-500">
                        <ShieldAlert className="h-4.5 w-4.5" />
                        <h5 className="font-bebas text-[11px] uppercase tracking-wider font-bold">CRITICAL FORM RED-LINES</h5>
                      </div>
                      <ul className="space-y-1.5 pl-5 list-disc text-xs text-rose-300/90 leading-relaxed font-light">
                        {selectedDbExercise.mistakes.map((m, idx) => (
                          <li key={idx}>{m}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Benefits, Safety and Variations Grid (3 Columns) */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-white/5 pt-5">
                      
                      {/* Benefits */}
                      <div className="space-y-2">
                        <span className="text-[10px] text-emerald-400 font-bold font-mono tracking-wider block uppercase">🌟 Athletic Benefits</span>
                        <ul className="space-y-1 text-xs text-neutral-300 leading-normal pl-4 list-disc font-light">
                          {selectedDbExercise.benefits.map((b, i) => <li key={i}>{b}</li>)}
                        </ul>
                      </div>

                      {/* Safety */}
                      <div className="space-y-2">
                        <span className="text-[10px] text-amber-500 font-bold font-mono tracking-wider block uppercase">🛡️ Safety Precaution Key</span>
                        <ul className="space-y-1 text-xs text-neutral-400 leading-normal pl-4 list-disc font-light">
                          {selectedDbExercise.safetyTips.map((s, i) => <li key={i}>{s}</li>)}
                        </ul>
                      </div>

                      {/* Alternative Pathways */}
                      <div className="space-y-2 bg-black/40 p-3.5 border border-white/5 rounded">
                        <span className="text-[10px] text-neutral-400 font-mono tracking-wider block uppercase font-bold">🔁 Progressive Regressions</span>
                        <div className="space-y-2 mt-1">
                          <div>
                            <span className="text-[9px] uppercase font-bold text-amber-500 font-mono block">Beginner Version:</span>
                            <p className="text-[11px] text-neutral-300 leading-normal italic">{selectedDbExercise.beginnerVersion}</p>
                          </div>
                          <div className="border-t border-white/5 pt-1.5 mt-1.5">
                            <span className="text-[9px] uppercase font-bold text-rose-500 font-mono block">Advanced Version:</span>
                            <p className="text-[11px] text-neutral-300 leading-normal italic">{selectedDbExercise.advancedVersion}</p>
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* Sets & Reps guidelines block */}
                    <div className="border-t border-white/10 pt-5 mt-6">
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-[10px] text-neutral-400 font-bold tracking-widest font-mono uppercase">Calculated Sets & Reps Blueprint</span>
                        <div className="flex gap-1.5">
                          {['muscleGrowth', 'fatLoss', 'strength', 'endurance'].map((goal) => (
                            <button
                              key={goal}
                              onClick={() => setRepSchemeGoal(goal as any)}
                              className={`text-[9px] px-2.5 py-1 rounded font-mono uppercase transition-colors ${
                                repSchemeGoal === goal 
                                  ? 'bg-amber-505 bg-amber-500 text-black font-bold' 
                                  : 'bg-black text-neutral-400 border border-white/5 hover:border-white/15'
                              }`}
                            >
                              {goal}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="bg-black/80 rounded border border-white/5 p-4 flex flex-col md:flex-row justify-between items-center text-center text-xs font-mono">
                        <div>
                          <span className="text-neutral-500 text-[9px] block uppercase">Recommended Sets</span>
                          <span className="text-white text-xl font-black font-bebas tracking-widest block mt-1 hover:text-amber-500 transition-colors">
                            {selectedDbExercise.recommendedSets[repSchemeGoal]} SETS
                          </span>
                        </div>
                        <div className="h-6 w-px bg-white/10 hidden md:block"></div>
                        <div>
                          <span className="text-neutral-500 text-[9px] block uppercase">Recommended Reps</span>
                          <span className="text-white text-xl font-black font-bebas tracking-widest block mt-1 hover:text-amber-500 transition-colors">
                            {selectedDbExercise.recommendedReps[repSchemeGoal]} REPS
                          </span>
                        </div>
                        <div className="h-6 w-px bg-white/10 hidden md:block"></div>
                        <div>
                          <span className="text-neutral-500 text-[9px] block uppercase">Target Rest Interval</span>
                          <span className="text-white text-xl font-black font-bebas tracking-widest block mt-1 hover:text-amber-500 transition-colors">
                            {selectedDbExercise.restTime} SECS
                          </span>
                        </div>
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="text-center py-20 text-neutral-500 select-none">
                    Select an exercise from the catalog results to expand coordinates.
                  </div>
                )}

              </div>

            </div>

          </div>
        )}

        {/* ————————————————————————————————————————————————————————— */}
        {/* MODULE 3: SMART PROGRAM GENERATOR */}
        {/* ————————————————————————————————————————————————————————— */}
        {activeConsoleTab === 'routine_generator' && (
          <div className="space-y-12 animate-fade-in text-left">
            
            <div className="bg-neutral-950/80 border border-white/10 rounded-sm p-6 sm:p-8 relative overflow-hidden app-card">
              <div className="absolute top-0 right-0 w-48 h-48 bg-amber-505 bg-amber-500/5 rounded-full blur-3xl"></div>
              
              <div className="flex items-center space-x-2.5 mb-6">
                <Sparkles className="h-5 w-5 text-amber-500 animate-pulse text-amber-400" />
                <h3 className="font-bebas text-xl sm:text-2xl tracking-widest font-bold uppercase italic">ANABOLIC ADAPTIVE ROUTINE BUILDER</h3>
              </div>

              {/* Onboarding multi-specs onboarding form */}
              <form onSubmit={handleGeneratePrivatePlan} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                
                <div className="flex flex-col space-y-2">
                  <label className="text-[9px] uppercase tracking-widest text-[#aaa] font-bold font-mono">Athlete Age</label>
                  <input
                    type="number"
                    min="14"
                    max="90"
                    value={genAge}
                    onChange={(e) => setGenAge(Number(e.target.value))}
                    className="bg-black border border-white/10 rounded p-2.5 text-xs font-bold text-white outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex flex-col space-y-2">
                  <label className="text-[9px] uppercase tracking-widest text-[#aaa] font-bold font-mono">Biological Gender</label>
                  <select
                    value={genGender}
                    onChange={(e) => setGenGender(e.target.value)}
                    className="bg-black border border-white/10 rounded p-2 text-xs font-bold text-white outline-none focus:border-amber-500"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Non-Binary / Specific</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col space-y-2">
                    <label className="text-[9px] uppercase tracking-widest text-[#aaa] font-bold font-mono">Height (cm)</label>
                    <input
                      type="number"
                      value={genHeight}
                      onChange={(e) => setGenHeight(Number(e.target.value))}
                      className="bg-black border border-white/10 rounded p-2.5 text-xs font-bold text-white outline-none focus:border-amber-500"
                    />
                  </div>
                  <div className="flex flex-col space-y-2">
                    <label className="text-[9px] uppercase tracking-widest text-[#aaa] font-bold font-mono">Weight (kg)</label>
                    <input
                      type="number"
                      value={genWeight}
                      onChange={(e) => setGenWeight(Number(e.target.value))}
                      className="bg-black border border-white/10 rounded p-2.5 text-xs font-bold text-white outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="flex flex-col space-y-2">
                  <label className="text-[9px] uppercase tracking-widest text-[#aaa] font-bold font-mono">Experience Stage</label>
                  <select
                    value={genExperience}
                    onChange={(e) => setGenExperience(e.target.value as any)}
                    className="bg-black border border-white/10 rounded p-2 text-xs font-bold text-white outline-none focus:border-amber-500"
                  >
                    <option value="Beginner">Beginner level</option>
                    <option value="Intermediate">Intermediate level</option>
                    <option value="Advanced">Advanced level</option>
                  </select>
                </div>

                <div className="flex flex-col space-y-2">
                  <label className="text-[9px] uppercase tracking-widest text-[#aaa] font-bold font-mono">Target Fitness Goal</label>
                  <select
                    value={genGoal}
                    onChange={(e) => setGenGoal(e.target.value as any)}
                    className="bg-black border border-white/10 rounded p-2 text-xs font-bold text-white outline-none focus:border-amber-500"
                  >
                    <option value="muscleGrowth">Hypertrophy (Gain Muscle)</option>
                    <option value="fatLoss">Recomposition (Fat Loss Shred)</option>
                    <option value="strength">Deat-lift (Maximize Strength)</option>
                    <option value="endurance">Conditioning (Improve Stamina)</option>
                  </select>
                </div>

                <div className="flex flex-col space-y-2">
                  <label className="text-[9px] uppercase tracking-widest text-[#aaa] font-bold font-mono">Equipment Available</label>
                  <select
                    value={genStyle}
                    onChange={(e) => setGenStyle(e.target.value)}
                    className="bg-black border border-white/10 rounded p-2 text-xs font-bold text-white outline-none focus:border-amber-500"
                  >
                    <option value="gym">Full Gym (Barbells, Machines & Cables)</option>
                    <option value="home">Basic Home (Bodyweight Only)</option>
                    <option value="calisthenics">Calisthenics Setup (Bars / Pull-up racks)</option>
                    <option value="all">Universal / Any Equipment</option>
                  </select>
                </div>

                <div className="sm:col-span-2 lg:col-span-3 pt-3">
                  <button
                    type="submit"
                    disabled={isGenerating}
                    className="w-full bg-amber-500 text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded hover:brightness-110 shadow-lg shadow-amber-500/10 flex items-center justify-center gap-2 transition-all"
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        <span>Compiling Target Ratios...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 text-black" />
                        <span>Compile Custom Workout Blueprint</span>
                      </>
                    )}
                  </button>
                </div>

              </form>

              {/* Generated outcome displays */}
              {generatedPlan && (
                <div className="space-y-8 animate-fade-in border-t border-white/10 pt-8 mt-6">
                  
                  {isPremium && apiResponseText && (
                    <div className="bg-black/90 p-5 rounded border border-amber-505 border-amber-550/30 text-left font-mono text-xs text-neutral-300 leading-relaxed max-h-[350px] overflow-y-auto">
                      <div className="flex justify-between items-center text-amber-500 text-[10px] tracking-widest uppercase mb-3 font-bold">
                        <span>💬 CO-AMPLIFIED NEURAL RESPOND</span>
                        <CheckCircle className="h-4 w-4 text-emerald-400" />
                      </div>
                      <pre className="whitespace-pre-wrap font-sans text-sm text-neutral-200 leading-normal">{apiResponseText}</pre>
                    </div>
                  )}

                  <div className="border border-white/5 rounded-lg overflow-hidden">
                    <div className="bg-neutral-900 [.light_&]:bg-neutral-200 p-4 border-b border-white/10 flex justify-between items-center">
                      <h4 className="font-bebas text-lg font-bold tracking-wider text-white [.light_&]:text-neutral-900 uppercase">
                        ⚡ TARGET DAILY BLUEPRINT WORKOUT PLAN
                      </h4>
                      <span className="text-[9px] font-mono uppercase bg-amber-500 text-black font-black px-2.5 py-0.5 rounded-sm">
                        {genGoal === 'fatLoss' ? 'FAT LOSS 12-15 REPS' : 'MUSCLE 8-12 REPS'}
                      </span>
                    </div>

                    <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      {generatedPlan.daily.map((ex, i) => (
                        <div key={i} className="bg-black p-4 border border-white/5 rounded flex justify-between items-center">
                          <div>
                            <span className="text-amber-500 font-mono text-[10px] font-bold">EXERCISE {i+1}</span>
                            <h5 className="font-bebas text-lg font-bold text-white uppercase mt-0.5">{ex.name}</h5>
                            <span className="text-neutral-400 font-mono text-[9px] block uppercase mt-1">Rest: {ex.rest}</span>
                          </div>
                          <div className="text-right font-mono shrink-0">
                            <span className="text-xs text-neutral-500 block uppercase font-bold">Volume</span>
                            <span className="text-white font-black text-lg">{ex.sets} x {ex.reps}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border border-white/5 rounded-lg overflow-hidden">
                    <div className="bg-neutral-900 [.light_&]:bg-neutral-200 p-4 border-b border-white/10">
                      <h4 className="font-bebas text-lg font-bold tracking-wider text-white [.light_&]:text-neutral-900 uppercase">
                        🗓️ DYNAMIC WEEKLY SPLIT SCHEDULE
                      </h4>
                    </div>
                    <div className="divide-y divide-white/5 p-2 bg-black/60">
                      {generatedPlan.weekly.map((day, i) => (
                        <div key={i} className="p-3 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                          <div className="flex gap-4 items-center">
                            <span className="w-20 font-bold font-mono text-xs uppercase tracking-widest text-amber-500">{day.day}</span>
                            <div>
                              <strong className="text-white text-xs block uppercase">{day.title}</strong>
                              <span className="text-[10px] text-neutral-400 italic">Target: {day.exercises.join(' , ')}</span>
                            </div>
                          </div>
                          <span className={`text-[9.5px] font-mono uppercase bg-neutral-900 border border-neutral-800 py-1 px-2.5 rounded text-[#888] font-semibold ${day.status !== 'Active Forge' && 'opacity-60'}`}>
                            {day.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border border-white/5 rounded-lg overflow-hidden">
                    <div className="bg-neutral-900 [.light_&]:bg-neutral-200 p-4 border-b border-white/10">
                      <h4 className="font-bebas text-lg font-bold tracking-wider text-white [.light_&]:text-neutral-900 uppercase">
                        📈 MONTHLY PROGRESSIVE OVERLOAD MAP
                      </h4>
                    </div>
                    <div className="p-4 grid grid-cols-1 md:grid-cols-4 gap-4 bg-black/60">
                      {generatedPlan.monthly.map((week, idx) => (
                        <div key={idx} className="bg-black border border-white/5 p-4 rounded text-left flex flex-col justify-between">
                          <div>
                            <span className="text-amber-500 font-mono text-[9px] font-bold block mb-1">{week.week}</span>
                            <h5 className="font-bebas text-sm font-extrabold text-white uppercase italic tracking-widest mb-2">{week.focus}</h5>
                            <p className="text-[11px] text-neutral-400 leading-relaxed leading-normal italic font-light">{week.progressiveOverload}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

            </div>

          </div>
        )}

      </div>
    </div>
  );
}
