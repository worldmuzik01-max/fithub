import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { LogIn, RefreshCw, ShieldAlert, CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translateFirebaseAuthError } from '../lib/authErrors';

export default function Login() {
  const navigate = useNavigate();
  const { 
    loginWithEmail, 
    loginWithGoogle, 
    loginWithGoogleRedirect,
    resetPassword, 
    sendVerification,
    loginSimulatedUser
  } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorText, setErrorText] = useState<string | null>(null);
  const [successText, setSuccessText] = useState<string | null>(null);
  const [isSubmit, setIsSubmit] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [unverifiedEmail, setUnverifiedEmail] = useState<string | null>(null);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setErrorText(null);
    setSuccessText(null);
    setIsGoogleLoading(true);
    try {
      await loginWithGoogle();
      setSuccessText(`🎉 Unified Google Authentication verified successfully! Syncing dashboard...`);
      navigate('/dashboard');
    } catch (err: any) {
      setErrorText(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setIsGoogleLoading(false);
    }
  };

  const handleGoogleRedirectLogin = async () => {
    setErrorText(null);
    setSuccessText(null);
    setIsGoogleLoading(true);
    try {
      await loginWithGoogleRedirect();
    } catch (err: any) {
      setErrorText(translateFirebaseAuthError(err.code || 'unknown', err.message));
      setIsGoogleLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmit(true);
    setErrorText(null);
    setSuccessText(null);
    setUnverifiedEmail(null);

    try {
      const u = await loginWithEmail(email, password);
      if (!u.emailVerified) {
        setUnverifiedEmail(email);
        setErrorText("Email verification required before onboarding is loaded. Check your inbox to confirm registration details!");
      } else {
        setSuccessText("🎉 Access verified. Forging your physique!");
        navigate('/dashboard');
      }
    } catch (err: any) {
      setErrorText(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setIsSubmit(false);
    }
  };

  const handleResend = async () => {
    if (!unverifiedEmail) return;
    setIsSubmit(true);
    try {
      await sendVerification();
      setSuccessText("📬 Verification link successfully resent! Please view your inbox.");
      setErrorText(null);
    } catch (e: any) {
      setErrorText(e.message || "Failed to resend confirmation.");
    } finally {
      setIsSubmit(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setErrorText("Please enter your email address first.");
      return;
    }
    setIsSubmit(true);
    setErrorText(null);
    setSuccessText(null);

    try {
      await resetPassword(email);
      setSuccessText("🔒 Recovery link dispatched to secure inbox! Open your email to finalize reset.");
      setShowForgot(false);
    } catch (err: any) {
      setErrorText(err.message || "Reset trigger failed.");
    } finally {
      setIsSubmit(false);
    }
  };

  return (
    <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
      <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full space-y-6 text-left shadow-2xl relative">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
        
        <div className="text-center">
          <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono uppercase block mb-1">Coach Alex Elite System</span>
          <h2 className="font-bebas text-3xl sm:text-4xl font-extrabold text-white tracking-wider">
            {showForgot ? 'PASSWORD RECOVERY' : 'LOGIN TO HUB'}
          </h2>
          <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">
            {showForgot ? 'Request master reset authorization' : 'Access your performance logs'}
          </p>
        </div>

        {errorText === 'auth/operation-not-allowed' ? (
          <div className="bg-neutral-900 border border-amber-500/20 p-4 rounded-sm text-xs leading-5 space-y-3">
            <div className="flex space-x-2 items-center text-amber-500 font-bold uppercase font-mono">
              <ShieldAlert className="h-4.5 w-4.5 text-amber-500 shrink-0" />
              <span>Firebase Auth Provider Disabled</span>
            </div>
            <p className="text-neutral-400">
              The Google or Email/Password Sign-In provider is currently disabled in your Firebase Console for project <strong className="text-white">auspicious-album-qszp9</strong>.
            </p>
            <div className="text-[11px] text-neutral-450 bg-black/50 p-2.5 rounded border border-neutral-850 space-y-1.5 leading-4">
              <div className="font-bold text-amber-400 uppercase tracking-widest text-[9px] font-mono">🔧 How to enable it:</div>
              <div>1. Open your <a href="https://console.firebase.google.com/project/auspicious-album-qszp9/authentication/providers" target="_blank" rel="noopener noreferrer" className="text-amber-500 underline font-semibold">Firebase Authentication Console</a>.</div>
              <div>2. Click on the <strong>Sign-in method</strong> tab.</div>
              <div>3. Click <strong>Add new provider</strong>, choose <strong>Google</strong>, toggle <strong>Enable</strong>, and click <strong>Save</strong>.</div>
              <div>4. Also add and enable <strong>Email/Password</strong> and click <strong>Save</strong>.</div>
            </div>
            <div className="pt-2 border-t border-neutral-850 space-y-2">
              <p className="text-neutral-450 text-[11px]">
                Don't have console access? You can immediately enter the full application using our secure sandbox simulated profile:
              </p>
              <button
                type="button"
                onClick={async () => {
                  setErrorText(null);
                  setSuccessText("Creating high-integrity simulated athlete profile...");
                  await loginSimulatedUser('athlete@alexfitness.com', 'Elite Athlete');
                  setTimeout(() => navigate('/dashboard'), 800);
                }}
                className="w-full bg-amber-500 text-black font-extrabold uppercase py-2.5 rounded-sm text-xs tracking-wider font-mono hover:brightness-110 transition-all cursor-pointer"
              >
                ⚡ Start Sandbox Demo Bypass
              </button>
              <button
                type="button"
                onClick={() => setErrorText(null)}
                className="w-full text-center text-[10px] text-neutral-500 uppercase tracking-widest font-mono hover:text-neutral-350 underline pt-1"
              >
                Clear Error Overlay
              </button>
            </div>
          </div>
        ) : (
          errorText && (
            <div className="flex flex-col space-y-2 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded text-xs leading-5">
              <div className="flex space-x-2.5 items-center">
                <ShieldAlert className="h-4.5 w-4.5 shrink-0" />
                <span>{errorText}</span>
              </div>
              {unverifiedEmail && (
                <button
                  type="button"
                  onClick={handleResend}
                  className="mt-1 text-left uppercase text-[9px] font-black underline tracking-wider hover:text-white"
                >
                  👉 click here to Resend Verification Email
                </button>
              )}
            </div>
          )
        )}

        {successText && (
          <div className="flex space-x-2.5 items-start p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded text-xs leading-5">
            <CheckCircle className="h-5 w-5 shrink-0 mt-0.5 text-emerald-500 animate-pulse" />
            <span>{successText}</span>
          </div>
        )}

        {showForgot ? (
          /* Forgot Password Interface */
          <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
            <div className="flex flex-col space-y-1">
              <label className="text-xs uppercase text-neutral-400 font-bold">Registered Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. champion@example.com"
                className="bg-black border border-neutral-850 rounded-sm p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none transition-colors"
              />
            </div>
            <div className="flex space-x-3 pt-2">
              <button
                type="submit"
                disabled={isSubmit}
                className="flex-grow bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm flex items-center justify-center space-x-1 font-mono cursor-pointer"
              >
                {isSubmit ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
                <span>Get Recovery Link</span>
              </button>
              <button
                type="button"
                onClick={() => setShowForgot(false)}
                className="px-4 border border-neutral-850 hover:bg-neutral-900 text-xs font-bold uppercase tracking-wider rounded-sm text-neutral-400 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : (
          /* Standard Sign In Form */
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="flex flex-col space-y-1">
              <label className="text-xs uppercase text-neutral-400 font-bold">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. athlete@domain.com"
                className="bg-black border border-neutral-850 rounded-sm p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none transition-colors"
              />
            </div>

            <div className="flex flex-col space-y-1">
              <div className="flex justify-between items-center">
                <label className="text-xs uppercase text-neutral-400 font-bold">Account Password</label>
                <button
                  type="button"
                  onClick={() => setShowForgot(true)}
                  className="text-[10px] text-amber-500 uppercase tracking-wider font-bold hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="password"
                className="bg-black border border-neutral-850 rounded-sm p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none transition-colors"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmit}
                className="w-full bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm flex items-center justify-center space-x-2 transition-all font-mono cursor-pointer"
              >
                {isSubmit ? <RefreshCw className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
                <span>{isSubmit ? 'Signing In...' : 'Verify Session Credentials'}</span>
              </button>
            </div>
          </form>
        )}

        {!showForgot && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 my-2 text-neutral-605 text-[10px] uppercase font-bold tracking-widest font-mono">
              <span className="h-px bg-neutral-900 flex-grow"></span>
              <span>or connect via</span>
              <span className="h-px bg-neutral-900 flex-grow"></span>
            </div>

            <button
              type="button"
              disabled={isGoogleLoading || isSubmit}
              onClick={handleGoogleLogin}
              className="w-full bg-[#0A0A0A] border border-neutral-850 hover:bg-neutral-900 hover:border-neutral-700 text-white font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm flex items-center justify-center space-x-2.5 transition-all font-mono cursor-pointer disabled:opacity-50"
            >
              {isGoogleLoading ? (
                <RefreshCw className="h-4 w-4 animate-spin text-amber-500" />
              ) : (
                <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05" />
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335" />
                </svg>
              )}
              <span>{isGoogleLoading ? 'Choosing Google Account...' : 'Continue with Google Account'}</span>
            </button>

            <button
              type="button"
              disabled={isGoogleLoading || isSubmit}
              onClick={handleGoogleRedirectLogin}
              className="w-full bg-black border border-neutral-900 hover:bg-neutral-900 text-neutral-400 font-extrabold uppercase text-[10px] tracking-wider py-2.5 rounded-sm flex items-center justify-center space-x-1 transition-all font-mono cursor-pointer disabled:opacity-50"
            >
              <span>Or use Google Redirect Fallback</span>
            </button>
          </div>
        )}

        {/* Security assurance */}
        <div className="text-center pt-2 border-t border-neutral-900">
          <span className="text-[9px] font-mono text-neutral-500 uppercase tracking-widest bg-neutral-950 px-2 py-1 rounded inline-block">
            🛡️ Secured via SHA-256 Hashed Password Database
          </span>
        </div>

        <div className="pt-2 flex flex-col space-y-2 text-center text-xs text-neutral-500">
          <div>
            Don't have an account yet? <Link to="/auth/signup" className="text-amber-500 font-bold hover:underline">Register here</Link>
          </div>
          <div className="pt-2 border-t border-neutral-900">
            <Link to="/auth/diagnostic" className="text-amber-500/60 hover:text-amber-500 text-[10px] font-mono hover:underline block">
              🛡️ Facing Auth or Connection obstacles? Run Diagnostics
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
