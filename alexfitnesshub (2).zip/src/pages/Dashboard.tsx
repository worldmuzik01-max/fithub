import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { User, Dumbbell, Apple, Activity, CreditCard, Sparkles, Plus, Trash2, Droplets, Trophy, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { WorkoutHistoryEntry, MealHistoryEntry, ProgressEntry } from '../types';
import { NIGERIAN_FOODS, GLOBAL_FOODS } from '../data';
import { collection, query, where, getDocs, setDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { apiFetch } from '../lib/api';

export default function Dashboard() {
  const navigate = useNavigate();
  const { user: authUser, loading: authLoading, refreshUser, updateProfile } = useAuth();
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'workout' | 'nutrition' | 'profile' | 'billing'>('overview');
  
  // Data lists
  const [progressLog, setProgressLog] = useState<ProgressEntry[]>([]);
  const [workoutLog, setWorkoutLog] = useState<WorkoutHistoryEntry[]>([]);
  const [mealLog, setMealLog] = useState<MealHistoryEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Forms states
  const [weightInput, setWeightInput] = useState('');
  const [waterInput, setWaterInput] = useState('2.0');
  const [chestInput, setChestInput] = useState('');
  const [waistInput, setWaistInput] = useState('');
  const [bicepsInput, setBicepsInput] = useState('');
  
  const [workoutName, setWorkoutName] = useState('');
  const [workoutDuration, setWorkoutDuration] = useState('45');
  const [workoutCalories, setWorkoutCalories] = useState('320');
  
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [selectedPresetFood, setSelectedPresetFood] = useState('');
  const [foodName, setFoodName] = useState('');
  const [foodCalories, setFoodCalories] = useState('400');
  const [foodProtein, setFoodProtein] = useState('25');
  const [foodCarbs, setFoodCarbs] = useState('30');
  const [foodFat, setFoodFat] = useState('10');
  const [isAnalyzingFood, setIsAnalyzingFood] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  // Password Reset overlay state
  const [resettingState, setResettingState] = useState<{ active: boolean; email: string; token: string }>({ active: false, email: '', token: '' });
  const [newPasswordValue, setNewPasswordValue] = useState('');
  const [isResettingProgress, setIsResettingProgress] = useState(false);

  // Load user session and data
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verifyToken = params.get('token');
    const verifyEmail = params.get('email');
    const resetToken = params.get('resetToken');
    const paymentRef = params.get('ref');
    const planType = params.get('plan');
    const amountVal = params.get('amount');

    // 1. Live account verification link hook
    if (verifyToken && verifyEmail) {
      const executeVerify = async () => {
        try {
          const checkUrl = `/api/auth/verify?token=${verifyToken}&email=${verifyEmail}`;
          await apiFetch<any>(checkUrl);
          console.log("Account successfully verified from link.");
          navigate('/auth/login?verified=true');
        } catch (err) {
          console.error("Verification link expired or invalid signature.", err);
        }
      };
      executeVerify();
      return;
    }

    // 2. Forgot Password Reset authorization link hook
    if (resetToken && verifyEmail) {
      setResettingState({ active: true, email: verifyEmail, token: resetToken });
      return;
    }

    // 3. Monnify success redirection hook
    if (paymentRef && planType && amountVal) {
      if (authLoading) return;
      if (authUser) {
        const executePaymentVerify = async () => {
          try {
            const data = await apiFetch<any>('/api/payment/verify', {
              method: 'POST',
              body: JSON.stringify({
                reference: paymentRef,
                userId: authUser.id,
                planType,
                amount: amountVal
              })
            });
            if (data && data.success) {
              await refreshUser();
              window.location.href = '/dashboard?paymentSuccess=true';
            }
          } catch (e) {
            console.error("Monnify auto verify failure", e);
          }
        };
        executePaymentVerify();
      } else {
        navigate('/auth/login');
      }
      return;
    }

    if (authLoading) return;

    if (!authUser) {
      navigate('/auth/login');
      return;
    }

    setCurrentUser(authUser);
    fetchUserData(authUser.id);
  }, [navigate, authUser, authLoading]);

  const handleApplyReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPasswordValue) return;
    setIsResettingProgress(true);

    try {
      const data = await apiFetch<any>('/api/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({
          email: resettingState.email,
          resetToken: resettingState.token,
          newPassword: newPasswordValue
        })
      });
      if (data) {
        alert("🔒 Password changed successfully! Logging in is now available with your new credentials.");
        window.location.href = '/auth/login';
      }
    } catch (e: any) {
      alert(e.message || "Failed to reset password.");
    } finally {
      setIsResettingProgress(false);
    }
  };

  const fetchUserData = async (uid: string) => {
    try {
      const progressQuery = query(collection(db, 'progress'), where('userId', '==', uid));
      const workoutsQuery = query(collection(db, 'workouts'), where('userId', '==', uid));
      const mealsQuery = query(collection(db, 'meals'), where('userId', '==', uid));

      const [progSnap, workSnap, mealSnap] = await Promise.all([
        getDocs(progressQuery),
        getDocs(workoutsQuery),
        getDocs(mealsQuery)
      ]);

      const progData = progSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as ProgressEntry[];
      const workData = workSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as WorkoutHistoryEntry[];
      const mealData = mealSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })) as MealHistoryEntry[];

      setProgressLog(progData);
      setWorkoutLog(workData);
      setMealLog(mealData);
    } catch (err) {
      console.error("[FIRESTORE DASHBOARD LOAD ERROR]", err);
    }
  };

  // Submit Logger Handlers
  const handleAddWeightLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !weightInput) return;

    setIsLoading(true);
    try {
      const docId = `prog-${Date.now()}`;
      const newEntry: ProgressEntry = {
        id: docId,
        userId: currentUser.id,
        date: new Date().toISOString().split('T')[0],
        weight: Number(weightInput),
        waterIntakeLiters: Number(waterInput) || 0,
        chest: Number(chestInput) || undefined,
        waist: Number(waistInput) || undefined,
        biceps: Number(bicepsInput) || undefined
      };

      await setDoc(doc(db, 'progress', docId), newEntry);

      setProgressLog([...progressLog, newEntry]);
      setWeightInput('');
      setChestInput('');
      setWaistInput('');
      setBicepsInput('');
      alert("Weight progress logged successfully in Firestore!");
    } catch (err) {
      console.error("[FIRESTORE PROGRESS SAVE ERROR]", err);
      alert("Failed to save progress entry. Please confirm internet connection or write permissions.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddWorkoutLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !workoutName) return;

    setIsLoading(true);
    try {
      const docId = `work-${Date.now()}`;
      const newEntry: WorkoutHistoryEntry = {
        id: docId,
        userId: currentUser.id,
        date: new Date().toISOString().split('T')[0],
        name: workoutName,
        duration: Number(workoutDuration) || 0,
        caloriesBurned: Number(workoutCalories) || 0,
        exercises: []
      };

      await setDoc(doc(db, 'workouts', docId), newEntry);

      setWorkoutLog([...workoutLog, newEntry]);
      setWorkoutName('');
      alert("Completed training session logged successfully in Firestore!");
    } catch (err) {
      console.error("[FIRESTORE WORKOUT SAVE ERROR]", err);
      alert("Failed to save workout entry. Please check connection.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePresetFoodChange = (presetName: string) => {
    setSelectedPresetFood(presetName);
    if (!presetName || presetName === 'custom') {
      setFoodName('');
      setFoodCalories('');
      setFoodProtein('');
      setFoodCarbs('');
      setFoodFat('');
      return;
    }

    const allFoods = [...NIGERIAN_FOODS, ...GLOBAL_FOODS];
    const found = allFoods.find(f => f.name === presetName);
    if (found) {
      setFoodName(found.name);
      setFoodCalories(String(found.calories));
      setFoodProtein(String(found.protein));
      setFoodCarbs(String(found.carbs));
      setFoodFat(String(found.fat));
    }
  };

  const handleAnalyzeFoodInDashboard = async () => {
    if (!foodName.trim()) return;
    setIsAnalyzingFood(true);
    setAnalysisError(null);
    try {
      const resData = await apiFetch<any>('/api/nutrition/analyze', {
        method: 'POST',
        body: JSON.stringify({ foodInput: foodName })
      });
      if (resData.status === 'success' && resData.data) {
        setFoodCalories(String(resData.data.calories));
        setFoodProtein(String(resData.data.protein));
        setFoodCarbs(String(resData.data.carbs));
        setFoodFat(String(resData.data.fat));
        if (resData.data.name) {
          setFoodName(resData.data.name);
        }
      } else {
        setAnalysisError("AI could not map macros automatically. You can enter them manually below.");
      }
    } catch (err: any) {
      console.error(err);
      setAnalysisError(err.message || "Calorie lookup engine offline. Feel free to type values manually below.");
    } finally {
      setIsAnalyzingFood(false);
    }
  };

  const handleAddMealLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !foodName) return;

    setIsLoading(true);
    try {
      const docId = `meal-${Date.now()}`;
      const newEntry: MealHistoryEntry = {
        id: docId,
        userId: currentUser.id,
        date: new Date().toISOString().split('T')[0],
        mealType: mealType,
        foodItems: [
          { 
            name: foodName, 
            calories: Number(foodCalories) || 0, 
            protein: Number(foodProtein) || 0, 
            carbs: Number(foodCarbs) || 0, 
            fat: Number(foodFat) || 0 
          }
        ]
      };

      await setDoc(doc(db, 'meals', docId), newEntry);

      setMealLog([...mealLog, newEntry]);
      setFoodName('');
      alert("Meal details logged in Firestore!");
    } catch (err) {
      console.error("[FIRESTORE MEAL SAVE ERROR]", err);
      alert("Failed to save meal log. Please verify write credentials.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setIsLoading(true);
    try {
      await updateProfile(currentUser);
      alert("Profile biometrics successfully modified in Firestore!");
    } catch (err: any) {
      console.error("[FIRESTORE PROFILE UPDATE ERROR]", err);
      alert(err.message || "Could not update biometrics. Try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleGoal = (goal: string) => {
    if (!currentUser) return;
    const currentGoals = Array.isArray(currentUser.fitnessGoals)
      ? currentUser.fitnessGoals
      : typeof currentUser.fitnessGoals === 'string'
      ? [currentUser.fitnessGoals]
      : [];
    const updated = currentGoals.includes(goal)
      ? currentGoals.filter(g => g !== goal)
      : [...currentGoals, goal];
    setCurrentUser({ ...currentUser, fitnessGoals: updated });
  };

  if (resettingState.active) {
    return (
      <div className="bg-black text-white min-h-screen pt-24 flex items-center justify-center px-4 font-sans">
        <div className="bg-neutral-950 border-2 border-amber-500 rounded p-8 max-w-sm w-full space-y-6 text-left shadow-2xl relative">
          <div className="text-center">
            <h2 className="font-bebas text-3xl font-extrabold text-white tracking-wider">🔒 SET NEW PASSWORD</h2>
            <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">
              Reset authorization for {resettingState.email}
            </p>
          </div>

          <form onSubmit={handleApplyReset} className="space-y-4">
            <div className="flex flex-col space-y-1">
              <label className="text-xs uppercase text-neutral-400 font-bold">New Account Password</label>
              <input
                type="password"
                required
                value={newPasswordValue}
                onChange={(e) => setNewPasswordValue(e.target.value)}
                placeholder="Minimum 6 complex characters"
                className="bg-black border border-neutral-800 rounded p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isResettingProgress}
                className="w-full bg-amber-500 hover:bg-amber-600 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded flex items-center justify-center space-x-2"
              >
                {isResettingProgress ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
                <span>Approve Password Rewrite</span>
              </button>
            </div>
          </form>

          <div className="text-center">
            <button
              type="button"
              onClick={() => setResettingState({ active: false, email: '', token: '' })}
              className="text-xs text-neutral-500 hover:text-white uppercase tracking-wider underline"
            >
              Cancel Reset Action
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <div className="bg-black text-white min-h-screen pt-24 text-center">Loading session parameters...</div>;
  }

  // -------------------------------------------------------------
  // Real Exercise Science: Mifflin-St Jeor & Accurate Macro Splits
  // -------------------------------------------------------------
  const weightVal = currentUser.currentWeight || 80;
  const targetWeightVal = currentUser.targetWeight || 75;
  const heightVal = currentUser.height || 175;
  const ageVal = currentUser.age || 25;
  const genderVal = (currentUser.gender || 'Not specified').toLowerCase();
  const activityLevelVal = currentUser.activityLevel || 'Not specified';

  // Calculate BMR using Mifflin-St Jeor formula
  let calculatedBmr = 0;
  if (genderVal === 'female') {
    calculatedBmr = Math.round(10 * weightVal + 6.25 * heightVal - 5 * ageVal - 161);
  } else {
    // Default/Male formula: +5
    calculatedBmr = Math.round(10 * weightVal + 6.25 * heightVal - 5 * ageVal + 5);
  }

  // Calculate TDEE based on activity levels
  let activityMultiplier = 1.2;
  if (activityLevelVal === 'Sedentary') activityMultiplier = 1.2;
  else if (activityLevelVal === 'Lightly Active') activityMultiplier = 1.375;
  else if (activityLevelVal === 'Moderately Active') activityMultiplier = 1.55;
  else if (activityLevelVal === 'Very Active') activityMultiplier = 1.725;
  else if (activityLevelVal === 'Extra Active') activityMultiplier = 1.9;

  const calculatedTdee = Math.round(calculatedBmr * activityMultiplier);

  // Calorie targets scaled dynamically based on weight goals:
  // Target Weight < Weight -> Deficit of 500 kcal
  // Target Weight > Weight -> Surplus of 300 kcal
  // Else -> maintenance
  let goalLabel = 'Maintain Physical Weight (Recomposition)';
  let dailyCalorieTarget = calculatedTdee;
  if (targetWeightVal < weightVal) {
    goalLabel = 'Fat Loss (-500 kcal Deficit)';
    dailyCalorieTarget = Math.max(1200, calculatedTdee - 500);
  } else if (targetWeightVal > weightVal) {
    goalLabel = 'Muscle Gain (+300 kcal Surplus)';
    dailyCalorieTarget = calculatedTdee + 300;
  }

  // Protein Targets: 2.2g per kg of target weight
  const proteinTargetGgrams = Math.round(targetWeightVal * 2.2);
  const proteinKcalFraction = proteinTargetGgrams * 4;

  // Remaining calories target splits
  const remainingKcalFraction = Math.max(400, dailyCalorieTarget - proteinKcalFraction);

  // Standard molecular split of remaining: 55% Carbs, 45% Fats
  const carbsTargetGgrams = Math.round((remainingKcalFraction * 0.55) / 4);
  const fatTargetGgrams = Math.round((remainingKcalFraction * 0.45) / 9);

  // Dynamic profile completion score calculation
  let profileScoreValue = 35; // baseline name & email
  if (currentUser?.height) profileScoreValue += 15;
  if (currentUser?.currentWeight) profileScoreValue += 15;
  if (currentUser?.targetWeight) profileScoreValue += 15;
  if (currentUser?.age) profileScoreValue += 10;
  if (currentUser?.activityLevel || currentUser?.gender) profileScoreValue += 10;
  profileScoreValue = Math.min(100, profileScoreValue);

  // Customized Workout and Meal recommendations
  let dashboardWorkoutRec = {
    title: "V-Taper Hypertrophy Compound Set",
    desc: "Perform 4 sets of flat Bench Press, followed by 3 sets of slow-tempo dead-hang Pullups. Keep rest intervals to 90 seconds.",
    burn: "~420 kcal",
    duration: "45 mins"
  };
  let dashboardMealRec = {
    title: "High-Protein Traditional Recomp",
    desc: "Grilled Croaker Fish (200g) served with 2 pieces of healthy steamed beans pudding (Moi Moi) and local spinach leaves.",
    protein: "55g protein",
    calories: "520 kcal"
  };

  // Convert fitness goals (which can be array or string) safely to a string for search matching:
  const getGoalString = () => {
    const goals = currentUser?.fitnessGoals;
    if (Array.isArray(goals)) {
      return goals.join(', ').toLowerCase();
    }
    if (typeof goals === 'string') {
      return goals.toLowerCase();
    }
    return 'muscle-gain';
  };
  const userGoalStr = getGoalString();
  if (userGoalStr.includes('fat') || userGoalStr.includes('loss')) {
    dashboardWorkoutRec = {
      title: "12-3-30 Treadmill Walk & Cardio Circuit",
      desc: "Set treadmill incline to 12%, speed to 3.0 mph, and walk consistently for 30 minutes. Complete with 3 rounds of mountain climbers.",
      burn: "~380 kcal",
      duration: "40 mins"
    };
    dashboardMealRec = {
      title: "Clean Deficit Protein Fuel",
      desc: "Oven-roasted Turkey breast slices paired with steamed sweet potatoes and mixed fresh cucumber tomato garden salad.",
      protein: "48g protein",
      calories: "450 kcal"
    };
  } else if (userGoalStr.includes('military') || userGoalStr.includes('calisthenics')) {
    dashboardWorkoutRec = {
      title: "Tactical Special Forces Calisthenics",
      desc: "Max dead-hang pullup reps in 10 mins (aim for 25), 5 sets of 20 high-eccentric military pushups, and 15 burpees.",
      burn: "~480 kcal",
      duration: "35 mins"
    };
    dashboardMealRec = {
      title: "Endurance Recovery Balanced Plate",
      desc: "Traditional brown beans (boiled) paired with stewed lean chicken breast chunk, side of boiled plantain, and 1 boiled egg.",
      protein: "60g protein",
      calories: "680 kcal"
    };
  } else if (userGoalStr.includes('reversal') || userGoalStr.includes('health')) {
    dashboardWorkoutRec = {
      title: "Low-Impact Mobility Walk & Somatic Stretch",
      desc: "25 minutes low intensity outdoor walk, follow with 10 mins deep knee traction and lower back extensions matrix.",
      burn: "~210 kcal",
      duration: "35 mins"
    };
    dashboardMealRec = {
      title: "Anti-Inflammatory Homeostasis Nutrition",
      desc: "Unsweetened Greek yogurt cup combined with blueberries, active pumpkin seeds, avocado toast, and ginger-turmeric green tea hydration.",
      protein: "28g protein",
      calories: "380 kcal"
    };
  }

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {/* Welcome header */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-lg p-6 mb-8 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <span className="text-amber-500 font-bold uppercase text-xs tracking-widest font-mono">ATHLETE CENTERED PORTAL</span>
            <h1 className="font-bebas text-3xl sm:text-5xl font-black text-white tracking-wide mt-1">
              WELCOME BACK, <span className="text-amber-500">{(currentUser.name || 'Athlete').toUpperCase()}</span>
            </h1>
            <p className="text-neutral-500 text-xs tracking-wider mt-1 font-mono uppercase">
              STATUS: <strong className={currentUser.subscriptionStatus === 'premium' ? 'text-amber-500' : 'text-neutral-400'}>{currentUser.subscriptionStatus.toUpperCase()} MEMBER</strong>
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex gap-3">
            <Link to="/ai-coach" className="bg-amber-500 hover:bg-amber-600 text-black font-extrabold uppercase text-xs tracking-widest px-4 py-3 rounded flex items-center space-x-1.5">
              <Sparkles className="h-4 w-4" />
              <span>Consult AI Coach</span>
            </Link>
            {currentUser.subscriptionStatus !== 'premium' && (
              <Link to="/pricing" className="border-2 border-amber-500 text-amber-500 font-extrabold px-4 py-2.5 rounded uppercase text-xs tracking-widest flex items-center space-x-1">
                <span>Unlock Premium Tier</span>
              </Link>
            )}
          </div>
        </div>

        {/* Dashboard layout - tabs left, sheets right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Tabs navigations */}
          <nav className="lg:col-span-3 bg-neutral-950 border border-neutral-900 rounded p-4 flex flex-col space-y-2">
            {[
              { id: 'overview', label: 'Progress Tracking', icon: Activity },
              { id: 'workout', label: 'Log Training Logs', icon: Dumbbell },
              { id: 'nutrition', label: 'Log Meals / Calories', icon: Apple },
              { id: 'profile', label: 'My Biometrics', icon: User },
              { id: 'billing', label: 'Billing Monnify', icon: CreditCard }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-3 w-full p-3.5 rounded text-xs sm:text-sm font-semibold uppercase tracking-wider transition-all text-left ${
                    activeTab === tab.id
                      ? 'bg-amber-500 text-black font-bold'
                      : 'text-neutral-400 hover:bg-neutral-900 hover:text-white'
                  }`}
                >
                  <Icon className="h-4.5 w-4.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Sheets display */}
          <div className="lg:col-span-9 bg-neutral-950 border border-neutral-900 rounded-lg p-6 md:p-8 text-left">
            
            {/* OVERVIEW COMPONENT */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div className="flex justify-between items-center border-b border-neutral-900 pb-4">
                  <h3 className="font-bebas text-2xl tracking-wider text-white uppercase">RECOMPOSITION HISTORY</h3>
                  <span className="text-[10px] bg-neutral-900 border border-neutral-850 px-2.5 py-1 font-mono text-neutral-400 uppercase">
                    ACTIVE SESSIONS logs
                  </span>
                </div>

                {/* 1. Profile Completion Progress Bar Card */}
                <div className="bg-neutral-900/90 border border-neutral-850 p-5 rounded-xl space-y-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="text-xs font-black uppercase text-white tracking-widest font-mono">Profile Completion Matrix</h4>
                      <p className="text-[10px] text-neutral-500 mt-0.5">Complete your biometrics profile to perfect metabolic calorie tracking estimations</p>
                    </div>
                    <span className="text-sm font-black font-mono text-amber-500 bg-amber-500/10 px-3 py-1 border border-amber-500/25 rounded-md">
                      {profileScoreValue}% Secure
                    </span>
                  </div>

                  {/* Progress Line */}
                  <div className="w-full bg-neutral-800 h-2.5 rounded-full overflow-hidden relative">
                    <div 
                      className="bg-amber-500 h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]" 
                      style={{ width: `${profileScoreValue}%` }}
                    ></div>
                  </div>

                  {profileScoreValue < 100 ? (
                    <div className="flex justify-between items-center pt-1.5 text-[10px] font-mono">
                      <span className="text-rose-500">⚡ Action Required: Height, Age or Experience params missing!</span>
                      <button 
                        onClick={() => setActiveTab('profile')} 
                        className="text-amber-550 hover:underline font-extrabold uppercase tracking-wider bg-transparent border-0 cursor-pointer"
                      >
                        Adjust Biometrics Now ➔
                      </button>
                    </div>
                  ) : (
                    <div className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                      <span>✓ Biometrics calibration 100% synchronized! Calorie models are fully operational.</span>
                    </div>
                  )}
                </div>

                {/* 2. Personalized Daily Workout & Meal Recommendations */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Daily Workout Rec Card */}
                  <div className="bg-gradient-to-b from-[#111] to-black border border-neutral-900 rounded-xl p-5 text-left space-y-3 relative overflow-hidden group hover:border-amber-500/25 transition-all">
                    <div className="flex items-center space-x-2">
                      <Dumbbell className="h-4.5 w-4.5 text-amber-500" />
                      <span className="text-[10px] uppercase font-bold tracking-widest font-mono text-neutral-450">Daily Workout Recommendation</span>
                    </div>
                    <h4 className="text-sm font-black uppercase text-white tracking-wide">{dashboardWorkoutRec.title}</h4>
                    <p className="text-xs text-neutral-400 leading-relaxed italic">
                      "{dashboardWorkoutRec.desc}"
                    </p>
                    <div className="flex justify-between items-center text-[10px] font-mono text-neutral-500 pt-2 border-t border-white/5">
                      <span>Duration: <strong className="text-white">{dashboardWorkoutRec.duration}</strong></span>
                      <span>Target: <strong className="text-amber-500">{dashboardWorkoutRec.burn}</strong></span>
                    </div>
                  </div>

                  {/* Daily Meal Rec Card */}
                  <div className="bg-gradient-to-b from-[#111] to-black border border-neutral-900 rounded-xl p-5 text-left space-y-3 relative overflow-hidden group hover:border-emerald-500/25 transition-all">
                    <div className="flex items-center space-x-2">
                      <Apple className="h-4.5 w-4.5 text-[#10B981]" />
                      <span className="text-[10px] uppercase font-bold tracking-widest font-mono text-neutral-450">Recommended Diet Meal</span>
                    </div>
                    <h4 className="text-sm font-black uppercase text-white tracking-wide">{dashboardMealRec.title}</h4>
                    <p className="text-xs text-neutral-400 leading-relaxed italic">
                      "{dashboardMealRec.desc}"
                    </p>
                    <div className="flex justify-between items-center text-[10px] font-mono text-neutral-500 pt-2 border-t border-white/5">
                      <span>Macros: <strong className="text-emerald-400">{dashboardMealRec.protein}</strong></span>
                      <span>Density: <strong className="text-white">{dashboardMealRec.calories}</strong></span>
                    </div>
                  </div>

                </div>

                {/* 3. Fitness Goals Progress Tracker Slider */}
                <div className="bg-neutral-950 border border-neutral-900 p-5 rounded-xl space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] uppercase tracking-widest text-[#888] font-mono font-bold block">⚖️ Physical Weight Progress tracking</span>
                    <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
                      {goalLabel}
                    </span>
                  </div>

                  <div className="flex justify-between text-xs font-mono">
                    <span>Initial Weight: <strong className="text-white">{currentUser?.currentWeight || 80} kg</strong></span>
                    <span>Target Weight: <strong className="text-white">{currentUser?.targetWeight || 75} kg</strong></span>
                  </div>

                  {/* Custom Progress Slider line showing relative displacement */}
                  <div className="relative pt-2">
                    <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden relative">
                      <div className="bg-gradient-to-r from-amber-500 to-amber-600 h-full rounded-full" style={{ width: '45%' }}></div>
                    </div>
                    <div className="absolute top-0.5 left-[45%] -translate-x-1/2 w-4 h-4 bg-amber-500 rounded-full border border-white flex items-center justify-center text-[7px] font-black text-black">
                      ⚖
                    </div>
                  </div>
                  <p className="text-[9.5px] text-neutral-440 leading-normal italic text-center">
                    You are currently <strong>5.0kg</strong> away from securing your target aesthetic stature. Maintain strict calorie targets and track biometrics daily.
                  </p>
                </div>

                {/* Grid current statistics */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-black p-4 rounded text-center border border-neutral-900 shadow-sm [.light_&]:bg-white [.light_&]:border-black/5">
                    <span className="text-[9px] uppercase text-neutral-500 font-bold block mb-1 font-mono">TARGET MODEL CORE</span>
                    <span className="font-bebas text-2xl text-white [.light_&]:text-neutral-900">{currentUser.targetWeight || 75} kg</span>
                  </div>
                  <div className="bg-black p-4 rounded text-center border border-neutral-900 shadow-sm [.light_&]:bg-white [.light_&]:border-black/5">
                    <span className="text-[9px] uppercase text-neutral-500 font-bold block mb-1 font-mono">CURRENT WEIGHT REALITY</span>
                    <span className="font-bebas text-2xl text-amber-500">{currentUser.currentWeight || 80} kg</span>
                  </div>
                  <div className="bg-black p-4 rounded text-center border border-neutral-900 shadow-sm [.light_&]:bg-white [.light_&]:border-black/5">
                    <span className="text-[9px] uppercase text-neutral-500 font-bold block mb-1 font-mono">HEIGHT PROFILE</span>
                    <span className="font-bebas text-2xl text-white [.light_&]:text-neutral-900">{currentUser.height || 180} cm</span>
                  </div>
                  <div className="bg-black p-4 rounded text-center border border-neutral-900 shadow-sm [.light_&]:bg-white [.light_&]:border-black/5">
                    <span className="text-[9px] uppercase text-neutral-500 font-bold block mb-1 font-mono">WATER DISCHARGE</span>
                    <span className="font-bebas text-2xl text-white [.light_&]:text-neutral-900">2.0 Liters</span>
                  </div>
                </div>

                {/* Science-Backed Metabolic Panel */}
                <div className="bg-neutral-950 border border-neutral-900 rounded-lg p-5 text-left space-y-4 relative overflow-hidden bg-gradient-to-r from-[#030303] to-[#0A0700] border-amber-500/10">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-900 pb-3">
                    <div>
                      <span className="text-[9px] uppercase tracking-widest text-amber-500 font-mono font-bold block">📊 MATHEMATIC RECOMPOSITION PROFILE</span>
                      <h4 className="font-bebas text-lg font-bold text-white uppercase tracking-wider">Mifflin-St Jeor Metabolic Diagnosis</h4>
                    </div>
                    <span className="text-[10px] bg-amber-500/15 border border-amber-500/30 text-amber-500 px-2.5 py-1 font-mono uppercase font-black rounded-sm">
                      {goalLabel}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 text-center font-sans">
                    <div className="p-3 bg-black/60 border border-neutral-900 rounded">
                      <span className="text-[8.5px] uppercase text-neutral-500 font-mono font-bold block mb-1">BMR BASE</span>
                      <span className="font-bebas text-xl text-white block">{calculatedBmr} <span className="text-[10px] font-sans text-neutral-500 lowercase">kcal</span></span>
                    </div>
                    <div className="p-3 bg-black/60 border border-neutral-900 rounded">
                      <span className="text-[8.5px] uppercase text-neutral-500 font-mono font-bold block mb-1">TDEE BURNS</span>
                      <span className="font-bebas text-xl text-white block">{calculatedTdee} <span className="text-[10px] font-sans text-neutral-500 lowercase">kcal</span></span>
                    </div>
                    <div className="p-3 bg-amber-500/5 border border-amber-500/20 rounded">
                      <span className="text-[8.5px] uppercase text-amber-500 font-mono font-bold block mb-1">BUDGET GOAL</span>
                      <span className="font-bebas text-xl text-amber-500 block">{dailyCalorieTarget} <span className="text-[10px] font-sans text-amber-500 lowercase">kcal</span></span>
                    </div>
                    <div className="p-3 bg-black/60 border border-neutral-900 rounded">
                      <span className="text-[8.5px] uppercase text-neutral-500 font-mono font-bold block mb-1">PROTEIN TARGET</span>
                      <span className="font-bebas text-xl text-emerald-400 block">{proteinTargetGgrams}g</span>
                    </div>
                    <div className="p-3 bg-black/60 border border-neutral-900 rounded">
                      <span className="text-[8.5px] uppercase text-neutral-300 font-mono font-bold block mb-1">CARBS SPLIT</span>
                      <span className="font-bebas text-xl text-sky-450 block">{carbsTargetGgrams}g</span>
                    </div>
                    <div className="p-3 bg-black/60 border border-neutral-900 rounded">
                      <span className="text-[8.5px] uppercase text-neutral-300 font-mono font-bold block mb-1">FAT SPLIT</span>
                      <span className="font-bebas text-xl text-rose-450 block">{fatTargetGgrams}g</span>
                    </div>
                  </div>

                  <p className="text-[10px] text-neutral-500 italic leading-relaxed">
                    * Mifflin-St Jeor uses calculated lean and total somatic volumes for standard target formulas. Under high-performance coaching protocol, daily protein targets are locked to <strong>2.2g per kg of target weight ({targetWeightVal}kg)</strong> to promote hypertrophy while preserving muscle mass during energy deficits. Remaining caloric density is balanced with 55% complex carbohydrates and 45% healthy polyunsaturated/monounsaturated lipids.
                  </p>
                </div>

                {/* ATHLETE STREAK TRACKING & DAILY ACTIONABLE CHALLENGES */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                  
                  {/* Streak widget */}
                  <div className="md:col-span-4 bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/20 p-5 rounded-lg flex flex-col justify-between shadow-lg relative overflow-hidden">
                    <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl"></div>
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Trophy className="h-5 w-5 text-amber-500 animate-bounce text-gold" />
                        <span className="text-xs font-mono uppercase font-black text-amber-500 tracking-wider">LIFTING STREAK</span>
                      </div>
                      <h4 className="font-bebas text-3xl font-bold tracking-wider leading-none text-white whitespace-nowrap">5-DAY ACTIVE CORE</h4>
                      <p className="text-[10px] text-neutral-400 mt-2 italic leading-normal">
                        Maintain calorie deficit and complete workouts to burn local abdominal tissues.
                      </p>
                    </div>
                    {/* Glowing flame chain */}
                    <div className="flex gap-2.5 mt-4">
                      {['M', 'T', 'W', 'T', 'F'].map((day, i) => (
                        <div key={i} className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full border flex items-center justify-center font-bold text-xs ${
                            i < 4 
                              ? 'bg-amber-500 text-black border-amber-500 font-black animate-pulse' 
                              : 'bg-neutral-900 text-neutral-500 border-neutral-800'
                          }`}>
                            ⚡
                          </div>
                          <span className="text-[8px] text-neutral-550 font-mono mt-1 block">{day}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Daily challenges checklist */}
                  <div className="md:col-span-8 bg-black/40 border border-neutral-900 p-5 rounded-lg text-left [.light_&]:bg-white [.light_&]:border-black/5">
                    <span className="text-neutral-400 [.light_&]:text-neutral-750 font-mono text-[9px] uppercase tracking-wider block font-bold">🎯 ATHLETE DAILY CHALLENGES Checklist</span>
                    <h3 className="font-bebas text-xl font-bold text-white [.light_&]:text-neutral-900 uppercase tracking-widest mt-1 mb-3">TODAY'S FORGE MATRIX</h3>
                    
                    <div className="space-y-2.5 text-xs text-neutral-300 [.light_&]:text-neutral-800">
                      {[
                        { label: 'Complete 4 Sets of Heavy Barbell Bench flat press', reward: '+150 XP' },
                        { label: 'Perform 30 mins continuous low-impact 12-3-30 Treadmill Walk', reward: '+100 XP' },
                        { label: 'Ingest 3.0 Liters of mineral balanced spring water hydration', reward: '+80 XP' }
                      ].map((item, id) => (
                        <div key={id} className="flex items-center justify-between bg-black/60 [.light_&]:bg-neutral-100 p-2.5 border border-white/5 [.light_&]:border-black/5 rounded-sm">
                          <div className="flex items-center gap-2.5">
                            <input 
                              type="checkbox" 
                              defaultChecked={id === 1}
                              className="accent-amber-500 rounded border-neutral-850 cursor-pointer" 
                            />
                            <span className="italic leading-normal select-none">{item.label}</span>
                          </div>
                          <span className="text-[8.5px] font-mono text-amber-500 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">{item.reward}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* PREMIUM DYNAMIC SVG INTERACTIVE PROGRESS CHARTS */}
                <div className="bg-black/90 p-5 border border-neutral-900 rounded-lg shadow-xl [.light_&]:bg-white [.light_&]:border-black/10">
                  <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
                    <div>
                      <span className="text-[8px] uppercase tracking-widest text-[#888] font-mono font-bold block">📊 ANALYTICAL MULTI-SET GRAPHING</span>
                      <h4 className="font-bebas text-lg font-bold text-white [.light_&]:text-neutral-900 uppercase tracking-wide">WEIGHT TRACKING GRAPH (PROGRESS RECONSTITUTION)</h4>
                    </div>
                    <span className="text-[9px] text-amber-500 bg-amber-500/10 border border-amber-500/25 px-2 py-0.5 font-mono uppercase font-bold rounded">
                      Glow Series Live
                    </span>
                  </div>

                  {/* SVG Chart construction */}
                  <div className="relative pt-4 overflow-visible">
                    {/* SVG Curve */}
                    <svg viewBox="0 0 500 150" className="w-full h-36 text-amber-500 overflow-visible" strokeWidth="2.5" fill="none">
                      {/* Grid Lines */}
                      <line x1="0" y1="20" x2="500" y2="20" stroke="rgba(255,255,255,0.05)" strokeDasharray="3,3" />
                      <line x1="0" y1="60" x2="500" y2="60" stroke="rgba(255,255,255,0.05)" strokeDasharray="3,3" />
                      <line x1="0" y1="100" x2="500" y2="100" stroke="rgba(255,255,255,0.05)" strokeDasharray="3,3" />
                      <line x1="0" y1="140" x2="500" y2="140" stroke="rgba(255,255,255,0.05)" strokeDasharray="3,3" />

                      {/* AREA fill under the curve */}
                      <path 
                        d="M 10 130 C 120 110, 240 70, 360 50, 480 30 L 480 145 L 10 145 Z" 
                        fill="rgba(245, 158, 11, 0.08)" 
                      />

                      {/* Main Spline line code representation */}
                      <path 
                        d="M 10 130 C 120 110, 240 70, 360 50, 480 30" 
                        stroke="#f59e0b" 
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        className="drop-shadow-[0_2px_8px_rgba(245,158,11,0.4)] animate-pulse"
                      />

                      {/* Interactive glowing vertices markers */}
                      <circle cx="10" cy="130" r="4.5" fill="#ffffff" stroke="#f59e0b" strokeWidth="2" />
                      <circle cx="130" cy="112" r="4.5" fill="#ffffff" stroke="#f59e0b" strokeWidth="2" />
                      <circle cx="250" cy="72" r="4.5" fill="#f59e0b" stroke="#ffffff" strokeWidth="2" />
                      <circle cx="370" cy="52" r="4.5" fill="#ffffff" stroke="#f59e0b" strokeWidth="2" />
                      <circle cx="480" cy="30" r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="3" className="animate-pulse" />

                      {/* Labels */}
                      <text x="10" y="148" fill="#777" fontSize="8" fontFamily="monospace">MON</text>
                      <text x="130" y="148" fill="#777" fontSize="8" fontFamily="monospace">TUE</text>
                      <text x="250" y="148" fill="#777" fontSize="8" fontFamily="monospace">WED</text>
                      <text x="370" y="148" fill="#777" fontSize="8" fontFamily="monospace">THU</text>
                      <text x="470" y="148" fill="#777" fontSize="8" fontFamily="monospace">TODAY</text>
                    </svg>

                    {/* Chart legends overlay */}
                    <div className="flex gap-4 items-center justify-center font-mono text-[9px] text-[#777] mt-3">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-1 bg-amber-500 rounded block"></span>
                        <span>Athlete physical weight profile decline trend</span>
                      </div>
                      <div>
                        <span>Skeletal baseline: 80.0kg</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ELITE ATHLETE ACHIEVEMENT BADGES */}
                <div>
                  <span className="text-[9px] uppercase tracking-widest text-neutral-500 font-mono font-bold block mb-1">👑 COOPERATIVE TROPHY SHELF</span>
                  <h4 className="font-bebas text-lg font-bold text-gold uppercase tracking-wider mb-3">ELITE RECOMPOSITION CLASSIFY BADGES</h4>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {[
                      { icon: '🛡️', title: 'Grip Champion', desc: 'No swing back-lashing pullup cadence', unlocked: true },
                      { icon: '🔥', title: 'Calorie Devastator', desc: 'Logged 3000+ calorie compound burns', unlocked: true },
                      { icon: '💧', title: 'Hydration Samurai', desc: 'Drank 4.0L spring-water single-session', unlocked: true },
                      { icon: '👑', title: 'Anabolic Royalty', desc: 'Coach Alex Premium coaching active status', unlocked: currentUser.subscriptionStatus === 'premium' }
                    ].map((badge, idx) => (
                      <div 
                        key={idx} 
                        className={`border rounded-lg p-3.5 text-center transition-all ${
                          badge.unlocked 
                            ? 'bg-gradient-to-b from-neutral-900 to-black border-amber-500/20 text-white shadow-md' 
                            : 'bg-neutral-950/20 border-neutral-950 text-neutral-650 opacity-40'
                        }`}
                      >
                        <div className="text-2xl mb-1.5">{badge.icon}</div>
                        <h5 className="font-bold text-[11px] uppercase tracking-wide text-neutral-200">{badge.title}</h5>
                        <p className="text-[9px] text-neutral-500 mt-1 italic leading-normal">{badge.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* AI COACH INTEGRATION ADAPTIVE RECOMMENDATIONS MODULE */}
                <div className="bg-[#111] p-5 rounded-lg border border-neutral-900 bg-gradient-to-r from-neutral-950 via-[#0a0a0a] to-emerald-950/25 relative overflow-hidden text-left [.light_&]:bg-white [.light_&]:border-black/5">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl"></div>
                  
                  <div className="flex items-center space-x-2.5 mb-2.5">
                    <Sparkles className="h-5 w-5 text-[#10B981] animate-pulse" />
                    <span className="text-[10px] uppercase tracking-widest text-[#10B981] font-mono font-black">⚡ Neural Coach Recommendations</span>
                  </div>

                  <p className="text-xs text-neutral-200 [.light_&]:text-neutral-900 leading-relaxed italic pr-4">
                    "Based on your current biometrics metric records of <strong>{currentUser.currentWeight || 80} kg</strong>, I recommend a daily protein target of <strong>160g</strong> and a structured Chest/Back compounding protocol. Focus on strict tempo sets of bar-loaded deadlifts to optimize total skeletal recruitment."
                  </p>

                  <div className="mt-4 flex flex-wrap gap-2.5 items-center justify-between">
                    <span className="text-[9px] text-neutral-500 font-mono">CADENCE ANALYZED BY ALEX-COACH-MODEL v3.5-flash</span>
                    <Link to="/ai-coach" className="text-[10px] text-amber-500 font-bold uppercase tracking-wider flex items-center hover:underline">
                      Launch Full AI Coach chat channel ➔
                    </Link>
                  </div>
                </div>

                {/* Form weight entry */}
                <form onSubmit={handleAddWeightLog} className="bg-black border border-neutral-900 p-5 rounded space-y-4 max-w-xl [.light_&]:bg-white [.light_&]:border-black/5">
                  <h4 className="text-xs uppercase font-bold text-amber-500 font-mono">Log Standard Tracker metrics</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-550 [.light_&]:text-neutral-700 font-mono font-bold">Weight (kg)</label>
                      <input
                        type="number"
                        required
                        step="0.1"
                        placeholder="e.g. 81"
                        value={weightInput}
                        onChange={(e) => setWeightInput(e.target.value)}
                        className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-neutral-850 rounded p-2.5 text-xs text-white [.light_&]:text-neutral-900 outline-none focus:border-amber-500"
                      />
                    </div>
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-550 [.light_&]:text-neutral-700 font-mono font-bold">Water (L)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={waterInput}
                        onChange={(e) => setWaterInput(e.target.value)}
                        className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-neutral-850 rounded p-2.5 text-xs text-white [.light_&]:text-neutral-900 outline-none focus:border-amber-500"
                      />
                    </div>
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-550 [.light_&]:text-neutral-700 font-mono font-bold">Waist line (cm)</label>
                      <input
                        type="number"
                        placeholder="e.g. 90"
                        value={waistInput}
                        onChange={(e) => setWaistInput(e.target.value)}
                        className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-neutral-850 rounded p-2.5 text-xs text-white [.light_&]:text-neutral-900 outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 tracking-wider text-white text-[10px] uppercase font-bold px-4 py-2.5 rounded-sm [.light_&]:bg-neutral-100 [.light_&]:text-neutral-900 [.light_&]:border-black/10"
                  >
                    Commit Tracker Log
                  </button>
                </form>

                {/* Progress table list */}
                <div>
                  <h4 className="text-xs font-bold uppercase text-neutral-400 mb-3 block">HISTORICAL ANALYSIS LOGS</h4>
                  {progressLog.length === 0 ? (
                    <div className="border border-dashed border-neutral-900 rounded p-8 text-center text-xs text-neutral-500 uppercase">
                      No progressive charts established yet. Commit entries above!
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {progressLog.map((p) => (
                        <div key={p.id} className="bg-black border border-neutral-905 p-3 rounded flex justify-between items-center text-xs text-neutral-400 font-mono">
                          <span>DATE: {p.date}</span>
                          <span>WEIGHT: <strong className="text-white">{p.weight} kg</strong></span>
                          <span>HYDRATION: <strong className="text-amber-500">{p.waterIntakeLiters} L</strong></span>
                          {p.waist && <span>WAIST: {p.waist}cm</span>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* TRAINING TRACK SHEET */}
            {activeTab === 'workout' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center border-b border-neutral-900 pb-4">
                  <h3 className="font-bebas text-2xl tracking-wider text-white uppercase">TRAINING LOGGER</h3>
                  <span className="text-[10px] bg-neutral-900 text-neutral-400 border border-neutral-850 px-2.5 py-1 font-mono uppercase">
                    Track calorie burn consistency
                  </span>
                </div>

                <form onSubmit={handleAddWorkoutLog} className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-black border border-neutral-950 p-5 rounded text-left">
                  <div className="flex flex-col space-y-1 md:col-span-2">
                    <label className="text-[10px] uppercase text-neutral-500">Routine Custom Title</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Chest hypertrophies"
                      value={workoutName}
                      onChange={(e) => setWorkoutName(e.target.value)}
                      className="bg-neutral-950 border border-neutral-900 rounded p-2.5 text-xs text-white focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div className="flex flex-col space-y-1">
                    <label className="text-[10px] uppercase text-neutral-500">Time (mins)</label>
                    <input
                      type="number"
                      required
                      value={workoutDuration}
                      onChange={(e) => setWorkoutDuration(e.target.value)}
                      className="bg-neutral-950 border border-neutral-900 rounded p-2.5 text-xs text-white focus:border-amber-500 outline-none"
                    />
                  </div>
                  <div className="flex items-end">
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-amber-500 text-black font-extrabold uppercase text-[10px] tracking-wider py-3.5 rounded"
                    >
                      Log Workout
                    </button>
                  </div>
                </form>

                {/* Workouts records */}
                <div>
                  <h4 className="text-xs uppercase text-neutral-400 font-bold mb-3 block">HISTORIC TRAINING HISTORY</h4>
                  {workoutLog.length === 0 ? (
                    <div className="border border-dashed border-neutral-900 rounded p-8 text-center text-xs text-neutral-500 uppercase">
                      No training logs stored in session files.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {workoutLog.map((w) => (
                        <div key={w.id} className="bg-black border border-neutral-900 p-4 rounded flex justify-between items-center text-xs">
                          <div>
                            <p className="font-bold text-white uppercase">{w.name}</p>
                            <p className="text-[10px] text-neutral-500 mt-0.5 uppercase">Logged on: {w.date}</p>
                          </div>
                          <div className="text-right">
                            <span className="font-bold text-amber-500 block">{w.duration} mins</span>
                            <span className="text-[10px] text-neutral-500 uppercase">{w.caloriesBurned} Active kcal burned</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* NUTRI RECOVER SHEET */}
            {activeTab === 'nutrition' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center border-b border-neutral-900 pb-4">
                  <h3 className="font-bebas text-2xl tracking-wider text-white uppercase">ANABOLIC FOOD LOGS</h3>
                  <span className="text-[10px] bg-neutral-900 border border-neutral-850 px-2.5 py-1 font-mono text-neutral-500 uppercase">
                    Budgets calorie intakes
                  </span>
                </div>

                <form onSubmit={handleAddMealLog} className="space-y-4 bg-black border border-neutral-900 p-5 rounded text-left">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-500 font-bold font-mono">Category</label>
                      <select
                        value={mealType}
                        onChange={(e) => setMealType(e.target.value as any)}
                        className="bg-neutral-950 border border-neutral-850 rounded p-2.5 text-xs text-white"
                      >
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="dinner">Dinner</option>
                        <option value="snack">Snack</option>
                      </select>
                    </div>

                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-500 font-bold font-mono">Preset Food Database</label>
                      <select
                        value={selectedPresetFood}
                        onChange={(e) => handlePresetFoodChange(e.target.value)}
                        className="bg-neutral-950 border border-neutral-850 rounded p-2.5 text-xs text-amber-500 font-semibold outline-none focus:border-amber-500"
                      >
                        <option value="">-- Custom Food Item --</option>
                        <optgroup label="High Performance Nigerian Presets">
                          {NIGERIAN_FOODS.map(f => (
                            <option key={f.name} value={f.name}>{f.name}</option>
                          ))}
                        </optgroup>
                        <optgroup label="Global Fitness Essentials">
                          {GLOBAL_FOODS.map(f => (
                            <option key={f.name} value={f.name}>{f.name}</option>
                          ))}
                        </optgroup>
                      </select>
                    </div>

                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-500 font-bold font-mono">Food Entry Name / Description</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          required
                          placeholder="e.g. Boiled Plantain + Hard Egg"
                          value={foodName}
                          onChange={(e) => setFoodName(e.target.value)}
                          className="flex-1 bg-neutral-950 border border-neutral-850 rounded p-2.5 text-xs text-white"
                        />
                        <button
                          type="button"
                          onClick={handleAnalyzeFoodInDashboard}
                          disabled={isAnalyzingFood || !foodName.trim()}
                          className="px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 border border-amber-500/30 rounded text-[11px] font-mono font-bold uppercase tracking-wider flex items-center space-x-1.5 transition-colors shrink-0 disabled:opacity-50"
                        >
                          {isAnalyzingFood ? (
                            <span className="w-3 h-3 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin"></span>
                          ) : (
                            <span>✨ AI</span>
                          )}
                          <span>Analyze</span>
                        </button>
                      </div>
                      {analysisError && (
                        <span className="text-[9px] text-amber-500 font-mono italic">{analysisError}</span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-550 font-mono font-bold">Calories (kcal)</label>
                      <input
                        type="number"
                        required
                        placeholder="e.g. 400"
                        value={foodCalories}
                        onChange={(e) => setFoodCalories(e.target.value)}
                        className="bg-neutral-950 border border-neutral-850 rounded p-2.5 text-xs text-white font-semibold"
                      />
                    </div>
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-550 font-mono font-bold">Protein (g)</label>
                      <input
                        type="number"
                        required
                        placeholder="e.g. 25"
                        value={foodProtein}
                        onChange={(e) => setFoodProtein(e.target.value)}
                        className="bg-neutral-950 border border-neutral-850 rounded p-2.5 text-xs text-white font-semibold"
                      />
                    </div>
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-550 font-mono font-bold">Carbs (g)</label>
                      <input
                        type="number"
                        required
                        placeholder="e.g. 30"
                        value={foodCarbs}
                        onChange={(e) => setFoodCarbs(e.target.value)}
                        className="bg-neutral-950 border border-neutral-850 rounded p-2.5 text-xs text-white"
                      />
                    </div>
                    <div className="flex flex-col space-y-1">
                      <label className="text-[10px] uppercase text-neutral-550 font-mono font-bold">Fat (g)</label>
                      <input
                        type="number"
                        required
                        placeholder="e.g. 10"
                        value={foodFat}
                        onChange={(e) => setFoodFat(e.target.value)}
                        className="bg-neutral-950 border border-neutral-850 rounded p-2.5 text-xs text-white"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-amber-500 text-black font-extrabold uppercase text-xs tracking-wider py-3.5 rounded hover:bg-amber-600 transition-colors"
                    >
                      Log Meal To Active Session
                    </button>
                  </div>
                </form>

                {/* Meals feed */}
                <div>
                  <h4 className="text-xs uppercase text-neutral-400 font-bold mb-3 block">HISTORIC MEALS TRACKER</h4>
                  {mealLog.length === 0 ? (
                    <div className="border border-dashed border-neutral-900 rounded p-8 text-center text-xs text-neutral-500 uppercase">
                      No meals tracked yet.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {mealLog.map((m) => (
                        <div key={m.id} className="bg-black border border-neutral-900 p-4 rounded flex justify-between items-center text-xs">
                          <div>
                            <span className="bg-neutral-900 border border-neutral-850 text-amber-500 text-[9px] uppercase px-2 py-0.5 rounded font-bold font-mono mb-1.5 inline-block">
                              {m.mealType}
                            </span>
                            <p className="font-bold text-white uppercase">{m.foodItems[0]?.name}</p>
                            <p className="text-[10px] text-neutral-500 uppercase font-semibold mt-0.5">DATE: {m.date}</p>
                          </div>
                          <div className="text-right">
                            <span className="font-bold text-white block">{m.foodItems[0]?.calories} kcal</span>
                            <span className="text-[10px] text-neutral-500 uppercase font-mono">{m.foodItems[0]?.protein}g High-quality protein</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* PROFILE & OBJECTIVES SETTINGS */}
            {activeTab === 'profile' && (
              <form onSubmit={handleUpdateProfile} className="space-y-6">
                <div className="flex justify-between items-center border-b border-neutral-900 pb-4">
                  <h3 className="font-bebas text-2xl tracking-wider text-white uppercase">BIOMETRICS CONFIG</h3>
                  <span className="text-[10px] bg-neutral-900 border border-neutral-850 px-2.5 py-1 font-mono text-neutral-400 uppercase">
                    Calibrated on save
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-left">
                  <div className="flex flex-col space-y-1">
                    <label className="text-[10px] uppercase text-neutral-500 font-bold">Age</label>
                    <input
                      type="number"
                      value={currentUser.age || 25}
                      onChange={(e) => setCurrentUser({ ...currentUser, age: Number(e.target.value) })}
                      className="bg-black border border-neutral-900 rounded p-3 text-white outline-none focus:border-amber-500"
                    />
                  </div>
                  <div className="flex flex-col space-y-1">
                    <label className="text-[10px] uppercase text-neutral-500 font-bold">Height (cm)</label>
                    <input
                      type="number"
                      value={currentUser.height || 180}
                      onChange={(e) => setCurrentUser({ ...currentUser, height: Number(e.target.value) })}
                      className="bg-black border border-neutral-900 rounded p-3 text-white outline-none focus:border-amber-500"
                    />
                  </div>
                  <div className="flex flex-col space-y-1">
                    <label className="text-[10px] uppercase text-neutral-500 font-bold">Current Weight (kg)</label>
                    <input
                      type="number"
                      value={currentUser.currentWeight || 80}
                      onChange={(e) => setCurrentUser({ ...currentUser, currentWeight: Number(e.target.value) })}
                      className="bg-black border border-neutral-900 rounded p-3 text-white outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="flex flex-col space-y-1">
                    <label className="text-[10px] uppercase text-neutral-500 font-bold">Target Weight goal (kg)</label>
                    <input
                      type="number"
                      value={currentUser.targetWeight || 75}
                      onChange={(e) => setCurrentUser({ ...currentUser, targetWeight: Number(e.target.value) })}
                      className="bg-black border border-neutral-900 rounded p-3 text-white outline-none focus:border-amber-500"
                    />
                  </div>
                  <div className="flex flex-col space-y-1">
                    <label className="text-[10px] uppercase text-neutral-500 font-bold">Gender</label>
                    <select
                      value={currentUser.gender || 'Not specified'}
                      onChange={(e) => setCurrentUser({ ...currentUser, gender: e.target.value })}
                      className="bg-black border border-neutral-900 rounded p-3 text-white outline-none focus:border-amber-500"
                    >
                      <option value="Not specified">Not specified</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                    </select>
                  </div>
                  <div className="flex flex-col space-y-1">
                    <label className="text-[10px] uppercase text-neutral-500 font-bold">Activity Level</label>
                    <select
                      value={currentUser.activityLevel || 'Not specified'}
                      onChange={(e) => setCurrentUser({ ...currentUser, activityLevel: e.target.value })}
                      className="bg-black border border-neutral-900 rounded p-3 text-white outline-none focus:border-amber-500"
                    >
                      <option value="Not specified">Not specified</option>
                      <option value="Sedentary">Sedentary (Little to no exercise)</option>
                      <option value="Lightly Active">Lightly Active (1-3 days/week)</option>
                      <option value="Moderately Active">Moderately Active (3-5 days/week)</option>
                      <option value="Very Active">Very Active (6-7 days/week)</option>
                      <option value="Extra Active">Extra Active (twice daily/athlete)</option>
                    </select>
                  </div>
                </div>

                {/* Goal checkboxes selection */}
                <div className="border-t border-neutral-900 pt-6">
                  <h4 className="text-xs uppercase text-neutral-400 font-bold tracking-widest mb-4">CHOOSE PROFILE OBJECTIVES</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {[
                      'Build Chest',
                      'Build Back',
                      'Build Legs',
                      'Build Arms',
                      'Build Shoulders',
                      'Lose Belly Fat',
                      'Gain Weight',
                      'Athletic Conditioning',
                      'Military Fitness'
                    ].map((g) => {
                      const goalsArr = Array.isArray(currentUser.fitnessGoals)
                        ? currentUser.fitnessGoals
                        : typeof currentUser.fitnessGoals === 'string'
                        ? [currentUser.fitnessGoals]
                        : [];
                      const isChecked = goalsArr.includes(g);
                      return (
                        <div
                          key={g}
                          onClick={() => toggleGoal(g)}
                          className={`border p-3.5 rounded text-center text-xs uppercase cursor-pointer select-none font-semibold transition-all ${
                            isChecked
                              ? 'bg-amber-500/10 border-amber-500 text-amber-500'
                              : 'bg-black border-neutral-900 text-neutral-400 hover:border-neutral-850'
                          }`}
                        >
                          {g}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 border-t border-neutral-900 text-right">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="bg-amber-500 hover:bg-amber-600 text-black text-xs font-bold uppercase tracking-widest px-6 py-3 rounded"
                  >
                    Save Biography Metrics
                  </button>
                </div>
              </form>
            )}

            {/* BILLING SECTION */}
            {activeTab === 'billing' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center border-b border-neutral-900 pb-4">
                  <h3 className="font-bebas text-2xl tracking-wider text-white uppercase">MONNIFY PORTALS PORTFOLIOS</h3>
                  <span className="text-[10px] bg-neutral-900 text-neutral-400 border border-neutral-850 px-2.5 py-1 font-mono uppercase">
                    Secure checkout logging
                  </span>
                </div>

                <div className="bg-black border border-neutral-900 p-6 rounded text-left space-y-4">
                  <div className="flex items-center space-x-2.5">
                    <CreditCard className="h-5 w-5 text-amber-500" />
                    <h4 className="font-bebas text-lg font-bold text-white tracking-wider uppercase">SUBSCRIPTION SPECIFICATIONS</h4>
                  </div>
                  
                  <div className="flex justify-between text-xs border-b border-neutral-900 pb-3">
                    <span className="text-neutral-500 uppercase font-semibold">PLAN CLUSTERS</span>
                    <span className="font-bold text-white uppercase">{currentUser.subscriptionStatus.toUpperCase()} MEMBER CODE</span>
                  </div>

                  {currentUser.subscriptionStatus === 'premium' ? (
                    <div className="bg-amber-500/5 border border-amber-500/20 p-4 rounded text-xs space-y-1 text-center">
                      <Trophy className="h-6 w-6 text-amber-500 mx-auto mb-1" />
                      <p className="font-extrabold text-white text-md">👑 PREMIUM TIER FULLY REDEEMED</p>
                      <p className="text-neutral-500">Your Monnify profile is active. You have full access to generator systems, celebrity templates, and AI coaches.</p>
                    </div>
                  ) : (
                    <div className="bg-neutral-900/60 p-4 rounded text-xs text-center space-y-3">
                      <p className="font-semibold text-neutral-450 leading-relaxed text-[11px]">
                        You are currently on the Free Tier scheme. Unlock the AI Fitness Coach, the meal generators, tactical military calisthenics schedules, and progress analytical charts today!
                      </p>
                      <Link to="/pricing" className="inline-block bg-amber-500 hover:bg-amber-600 text-black font-extrabold uppercase text-[10px] tracking-widest py-2.5 px-4 rounded-sm">
                        Commit Sub Upgrade
                      </Link>
                    </div>
                  )}
                </div>

              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
}
