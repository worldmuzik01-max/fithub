import React from 'react';
import { BLOG_POSTS } from '../data';
import { Calendar, User, ArrowRight } from 'lucide-react';

export default function Blog() {
  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">SCIENCE CORNER BLOG</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            FITNESS & <span className="text-amber-500">HEALTH INSIGHTS</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Stay educated on real body recomposition guides. We filter out the commercial pseudo-science to outline raw, verifiable fitness research.
          </p>
        </div>

        {/* Blog Post list */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {BLOG_POSTS.map((post) => (
            <article key={post.id} className="bg-neutral-950 border border-neutral-900 rounded-lg overflow-hidden flex flex-col justify-between hover:border-amber-500/10 transition-all">
              <div>
                <div className="h-56 relative border-b border-neutral-900">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover opacity-85"
                  />
                  <div className="absolute top-4 left-4 bg-amber-500 text-black text-[10px] uppercase font-bold tracking-widest px-2.5 py-1">
                    {post.category}
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <div className="flex items-center space-x-4 text-[10px] text-neutral-500 font-mono">
                    <span className="flex items-center space-x-1">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{post.date}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <User className="h-3.5 w-3.5" />
                      <span>By {post.author}</span>
                    </span>
                  </div>

                  <h3 className="font-bebas text-2xl font-bold tracking-wide text-white hover:text-amber-500 transition-colors">
                    {post.title}
                  </h3>

                  <p className="text-xs text-neutral-400 leading-relaxed font-light font-sans">
                    {post.excerpt}
                  </p>

                  <div className="border-t border-neutral-900 pt-4 mt-6 text-neutral-300 text-xs text-left leading-relaxed font-sans">
                    {post.content}
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0 mt-4">
                <span className="text-[10px] uppercase font-bold text-amber-500 tracking-widest block border-t border-neutral-900 pt-3">
                  ★ COACH VERIFIED RESOURCE
                </span>
              </div>
            </article>
          ))}
        </div>

      </div>
    </div>
  );
}
