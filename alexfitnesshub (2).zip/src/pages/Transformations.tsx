import React from 'react';
import { Star, Trophy, ArrowRight, HeartPulse, Sparkles, Scale, Percent, Dumbbell } from 'lucide-react';
import { TESTIMONIALS } from '../data';

export default function Transformations() {
  return (
    <div className="bg-black text-white pt-28 min-h-screen relative overflow-hidden app-bg">
      {/* Background Cinematic Lighting */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
      <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-amber-500/5 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-500/5 rounded-full blur-[140px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        
        {/* Title Section */}
        <div className="text-center max-w-3xl mx-auto mb-20 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full mb-4">
            <Sparkles className="h-3 w-3 text-amber-500" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-500 font-mono">
              VERIFIED BIOMETRIC ARCHIVES
            </span>
          </div>
          <h1 className="font-syne text-5xl sm:text-7xl font-extrabold text-white [.light_&]:text-neutral-900 tracking-tight leading-none uppercase">
            CONVERSION <span className="text-amber-500 italic">JOURNALS</span>
          </h1>
          <p className="text-neutral-400 [.light_&]:text-neutral-600 mt-4 text-sm sm:text-base leading-relaxed font-light max-w-xl mx-auto">
            Explore the authentic, certified biometric entries and physical milestones achieved by our extreme athletes. These statistics trace actual body composition transformations.
          </p>
        </div>

        {/* Master stats overview cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-20 text-center">
          <div className="bg-neutral-950/90 border border-neutral-900 rounded-sm p-8 shadow-2xl relative group overflow-hidden">
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-all"></div>
            <Trophy className="h-7 w-7 text-amber-500 mx-auto mb-3" />
            <p className="font-syne text-3xl sm:text-4xl font-extrabold text-white tracking-tight">20,400+ KG</p>
            <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold font-mono mt-1">Total Body Fat Shredded</p>
          </div>
          <div className="bg-neutral-950/90 border border-neutral-900 rounded-sm p-8 shadow-2xl relative group overflow-hidden">
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-all"></div>
            <Star className="h-7 w-7 text-amber-500 mx-auto mb-3" />
            <p className="font-syne text-3xl sm:text-4xl font-extrabold text-white tracking-tight">99.4%</p>
            <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold font-mono mt-1">Success Progression Rate</p>
          </div>
          <div className="bg-neutral-950/90 border border-neutral-900 rounded-sm p-8 shadow-2xl relative group overflow-hidden">
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-all"></div>
            <HeartPulse className="h-7 w-7 text-amber-500 mx-auto mb-3" />
            <p className="font-syne text-3xl sm:text-4xl font-extrabold text-white tracking-tight">4,800+</p>
            <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold font-mono mt-1">Reversed Metabolic Logs</p>
          </div>
        </div>

        {/* Detailed stories grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {TESTIMONIALS.map((t) => (
            <div 
              key={t.id} 
              className="bg-neutral-950/70 border border-neutral-900 rounded-sm p-6 sm:p-8 hover:border-amber-500/30 transition-all duration-300 flex flex-col md:flex-row gap-6 relative justify-between group shadow-xl hover:shadow-2xl hover:shadow-amber-500/5"
            >
              {/* Photo Area with overlay tag */}
              <div className="md:w-2/5 shrink-0">
                <div className="h-64 md:h-full w-full rounded-sm overflow-hidden relative border border-neutral-900">
                  <img
                    src={t.image}
                    alt={t.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500 opacity-75 group-hover:opacity-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="bg-amber-500 text-black font-mono text-[9px] font-black tracking-widest px-2.5 py-1 uppercase rounded-xs shadow-md">
                      {t.resultType.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Bio & transformation outcomes details */}
              <div className="md:w-3/5 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-syne text-xl sm:text-2xl font-bold tracking-tight text-white uppercase group-hover:text-amber-500 transition-colors">
                        {t.name}
                      </h4>
                      <p className="text-[10px] text-neutral-400 tracking-widest font-mono uppercase mt-0.5">
                        {t.role}
                      </p>
                    </div>
                    <div className="flex space-x-0.5 mt-1 shrink-0">
                      {[...Array(t.rating)].map((_, i) => (
                        <Star key={i} className="h-3 w-3 fill-amber-500 text-amber-500" />
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-amber-500 font-bold uppercase tracking-wider mb-3 bg-amber-500/5 border border-amber-500/10 px-2.5 py-1.5 rounded-sm w-fit">
                    <Trophy className="h-3 w-3 shrink-0" />
                    <span>{t.result}</span>
                  </div>
                  
                  <p className="text-xs text-neutral-300 leading-relaxed font-light font-sans italic">
                    "{t.story}"
                  </p>
                </div>

                {/* Weight Parameters logs */}
                <div className="border-t border-neutral-900/80 pt-4 mt-2 flex justify-between items-center text-[10px] text-neutral-500 font-mono">
                  <div className="flex items-center gap-1.5">
                    <Scale className="h-3.5 w-3.5 text-neutral-600" />
                    <span>BEFORE: <strong className="text-rose-500 font-extrabold">{t.beforeWeight}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Dumbbell className="h-3.5 w-3.5 text-amber-500" />
                    <span>AFTER: <strong className="text-emerald-400 font-extrabold">{t.afterWeight}</strong></span>
                  </div>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Call to action section */}
        <div className="mt-20 text-center max-w-xl mx-auto border border-neutral-900 rounded-sm p-8 bg-neutral-950/40 backdrop-blur-sm">
          <h3 className="font-syne text-xl font-bold uppercase tracking-wide">Ready to design your own transformation entry?</h3>
          <p className="text-xs text-neutral-400 mt-2 max-w-sm mx-auto leading-relaxed">
            Configure your biometrics, track workout performance metrics, and let Coach Alex custom-match your food and lifting splits.
          </p>
          <div className="mt-6">
            <a
              href="/pricing"
              className="inline-flex items-center gap-2 bg-amber-500 hover:bg-gold text-black font-extrabold text-xs uppercase tracking-widest py-3.5 px-8 rounded-sm shadow-xl shadow-amber-500/10 transition-all font-mono"
            >
              <span>Activate Your Premium Account</span>
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
