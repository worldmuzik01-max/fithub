import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Apple, Plus, Trash2, Heart, Droplet, Flame, Sparkles, ShieldAlert, CheckCircle, HelpCircle, Activity, Eye, Zap, BookOpen, Coffee, Crown, Lock, RefreshCw } from 'lucide-react';
import { NIGERIAN_FOODS, GLOBAL_FOODS } from '../data';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

interface PlateItem {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  quantity: number; // serving count
}

export default function Nutrition() {
  const { user: authUser, loading: authLoading } = useAuth();
  const [typedFood, setTypedFood] = useState(NIGERIAN_FOODS[0].name);
  const [customCalories, setCustomCalories] = useState<string>(String(NIGERIAN_FOODS[0].calories));
  const [customProtein, setCustomProtein] = useState<string>(String(NIGERIAN_FOODS[0].protein));
  const [customCarbs, setCustomCarbs] = useState<string>(String(NIGERIAN_FOODS[0].carbs));
  const [customFat, setCustomFat] = useState<string>(String(NIGERIAN_FOODS[0].fat));
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const [servingQty, setServingQty] = useState(1);
  const [plate, setPlate] = useState<PlateItem[]>([]);
  const [activeGuide, setActiveGuide] = useState<'loss' | 'gain' | 'maintenance' | 'hydration'>('loss');
  const [activeNutritionTab, setActiveNutritionTab] = useState<'calculator' | 'fruits_smoothies' | 'avoid_list' | 'fat_loss_center'>('calculator');

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!authUser) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full text-center space-y-6 shadow-2xl relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-bebas text-3xl font-extrabold tracking-wider">NUTRITION SYSTEM LOCKED</h2>
            <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">Authentic Session Verification Required</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans">
            Gaining access to traditional Nigerian food trackers, fruits index guides, and customized calorie-budget planners requires verified active athlete credentials.
          </p>
          <div className="pt-2">
            <Link
              to="/auth/login"
              className="w-full bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm block font-mono"
            >
              Sign In to Unlock
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const isPremium = authUser.subscriptionStatus === 'premium' || authUser.email === 'muzikworld08@gmail.com' || (authUser as any).role === 'admin';

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full text-center space-y-6 shadow-2xl relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-full blur-2xl"></div>
          <div className="w-16 h-16 bg-gold/10 border border-gold/20 text-gold rounded-full flex items-center justify-center mx-auto animate-pulse">
            <Crown className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-bebas text-3xl font-extrabold tracking-wider">ELITE NUTRITION HUB LOCKED</h2>
            <p className="text-xs text-amber-500 uppercase tracking-widest mt-1">Premium subscription required</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans">
            Traditional Nigerian-focused calorie trackers, premium fat-shredding smoothie schemes, and fruit metabolic enzymes lookup are reserved exclusively for Premium athletes.
          </p>
          <div className="pt-2 flex flex-col space-y-3">
            <Link
              to="/pricing"
              className="w-full bg-gold hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm block font-mono"
            >
              Get Premium Access
            </Link>
            <Link
              to="/dashboard"
              className="w-full border border-white/10 hover:bg-white/5 text-white font-bold uppercase text-[10px] tracking-wider py-2.5 rounded-sm block"
            >
              Back to Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const foodRegistry = [...NIGERIAN_FOODS, ...GLOBAL_FOODS];

  const handleFoodInputChange = (val: string) => {
    setTypedFood(val);
    const matched = foodRegistry.find(f => f.name.toLowerCase() === val.trim().toLowerCase());
    if (matched) {
      setCustomCalories(String(matched.calories));
      setCustomProtein(String(matched.protein));
      setCustomCarbs(String(matched.carbs));
      setCustomFat(String(matched.fat));
    }
  };

  const handleAnalyzeFood = async () => {
    if (!typedFood.trim()) return;
    setIsAnalyzing(true);
    setAnalysisError(null);
    try {
      const resData = await apiFetch<any>('/api/nutrition/analyze', {
        method: 'POST',
        body: JSON.stringify({ foodInput: typedFood })
      });
      if (resData.status === 'success' && resData.data) {
        setCustomCalories(String(resData.data.calories));
        setCustomProtein(String(resData.data.protein));
        setCustomCarbs(String(resData.data.carbs));
        setCustomFat(String(resData.data.fat));
        if (resData.data.name) {
          setTypedFood(resData.data.name);
        }
      } else {
        setAnalysisError("Could not calculate nutritional values automatically. You can enter them manually below.");
      }
    } catch (err: any) {
      console.error(err);
      setAnalysisError(err.message || "Calorie lookup service offline. Feel free to type values manually below.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAddToPlate = () => {
    if (!typedFood.trim()) return;

    const caloriesVal = Number(customCalories) || 0;
    const proteinVal = Number(customProtein) || 0;
    const carbsVal = Number(customCarbs) || 0;
    const fatVal = Number(customFat) || 0;

    const existing = plate.find(p => p.name.toLowerCase() === typedFood.trim().toLowerCase());
    if (existing) {
      setPlate(plate.map(p => p.name.toLowerCase() === typedFood.trim().toLowerCase() 
        ? { ...p, quantity: p.quantity + Number(servingQty), calories: caloriesVal, protein: proteinVal, carbs: carbsVal, fat: fatVal } 
        : p
      ));
    } else {
      setPlate([...plate, {
        id: `p-${Date.now()}`,
        name: typedFood.trim(),
        calories: caloriesVal,
        protein: proteinVal,
        carbs: carbsVal,
        fat: fatVal,
        quantity: Number(servingQty)
      }]);
    }
    setServingQty(1);
  };

  const handleRemove = (id: string) => {
    setPlate(plate.filter(p => p.id !== id));
  };

  const totals = plate.reduce((acc, curr) => ({
    calories: acc.calories + (curr.calories * curr.quantity),
    protein: acc.protein + (curr.protein * curr.quantity),
    carbs: acc.carbs + (curr.carbs * curr.quantity),
    fat: acc.fat + (curr.fat * curr.quantity)
  }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

  // Custom data arrays forFruits
  const premiumFruits = [
    {
      name: "Avocado (Pear)",
      benefits: "High monounsaturated lipid fats. Aids hormone synthesis, lowers systemic cortisol, and contains high potassium to prevent muscle cramps.",
      calories: "160 kcal / 100g",
      macros: "P: 2g | C: 8g | F: 15g | Fiber: 7g",
      vitamins: "Vitamins K, C, B5, B6, E"
    },
    {
      name: "Bananas",
      benefits: "Fast-absorbing glycemic energy fuel. Repletes active skeletal muscle glycogen storage immediately post-workout and delivers potassium.",
      calories: "89 kcal / 100g",
      macros: "P: 1.1g | C: 23g | F: 0.3g | Fiber: 2.6g",
      vitamins: "Vitamin B6, C, Potassium"
    },
    {
      name: "Papaya (Pawpaw)",
      benefits: "Contains papain proteolytic enzymes that speed up dietary protein digestion. Ideal immediately after heavy meat/poultry meals.",
      calories: "43 kcal / 100g",
      macros: "P: 0.5g | C: 11g | F: 0.3g | Fiber: 1.7g",
      vitamins: "Vitamin C, A, Folate"
    },
    {
      name: "Apples",
      benefits: "High pectin soluble fibers. Inhibits lipogenesis, regulates stable postprandial insulin spikes, and increases subjective meal satiety.",
      calories: "52 kcal / 100g",
      macros: "P: 0.3g | C: 14g | F: 0.2g | Fiber: 2.4g",
      vitamins: "Vitamin C, Potassium, Quercetin"
    },
    {
      name: "Pineapple(Ananas)",
      benefits: "High in active bromelain. Minimizes systemic joint inflammation and speeds muscular cellular restructuring during sleep cycles.",
      calories: "50 kcal / 100g",
      macros: "P: 0.5g | C: 13g | F: 0.1g | Fiber: 1.4g",
      vitamins: "Manganese, Vitamin C, B1"
    }
  ];

  // High protein smoothies
  const highProteinSmoothies = [
    {
      title: "Alex V-Taper Bulk Shake",
      calories: "580 kcal",
      protein: "42g Protein",
      ingredients: "1 Large Frozen Banana, 30g Premium Vanilla Whey Isolate, 2 Tbsps Ground Peanut Butter, 1 Cup Oatmeal, 300ml Unsweetened Almond Milk.",
      prep: "Blend on high intensity speed for 90 seconds until perfectly homogeneous. Drink 30 minutes post mechanical training."
    },
    {
      title: "Hollywood Fat Shredder",
      calories: "290 kcal",
      protein: "31g Protein",
      ingredients: "1 Cup Mixed Strawberries/Blueberries, 30g Premium Casein or Pea Isolate, 1 Tbsp Chia Seeds, 1 Cup Baby Spinach, 250ml Alkaline Chilled Water.",
      prep: "Blend until smooth. High soluble dietary fibers support continuous fat burning and keep appetite suppressed for up to 4 hours."
    },
    {
      title: "Nigerian Green Cleanser",
      calories: "340 kcal",
      protein: "26g Protein",
      ingredients: "1/2 Frozen Pawpaw, 20g Active Collagen/Whey Protein, 1 Tsp Grated Raw Ginger, Handful of Clean Pumpkin Leaves (Ugu), 250ml Cold Water.",
      prep: "Blend thoroughly. Delivers high magnesium, speeds up nitrogen absorption, and cleanses physical digestive tracks."
    }
  ];

  // Foods to limit or avoid
  const avoidFoods = [
    {
      food: "Industrial Trans-Fats (Margarine)",
      reason: "Alters cardiovascular lipid fractions, sparks heavy cellular inflammation, and inhibits standard fat oxidation pathways."
    },
    {
      food: "Sugary Soft Beverages & Sodas",
      reason: "Loads the liver with concentrated fructose syrup, triggering lipogenesis (de novo fat storage) and insulin resistance."
    },
    {
      food: "Deep Fried Plantain (Dodo) / Meat",
      reason: "Releasing dangerous acrylamides and free radicals when fried at extreme heat with cheap oxidized seed oils. Prefer baking or boiling."
    },
    {
      food: "Refined White Flour & Pastries",
      reason: "Stripped of organic dietary fibers. Sparks immediate glucose spikes and high fat accumulation around abdominal organs."
    }
  ];

  return (
    <div className="app-bg pt-20 min-h-screen transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-10 animate-fade-in animate-once">
          <p className="text-gold uppercase text-xs font-bold tracking-widest mb-2 font-mono">ANABOLIC ENERGY BALANCE</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white [.light_&]:text-neutral-900 tracking-wide transition-colors">
            NUTRITION & <span className="text-gold">DIETETICS</span>
          </h1>
          <p className="text-neutral-400 [.light_&]:text-neutral-600 mt-4 leading-relaxed font-light text-sm italic transition-colors">
            Measure your daily energy expenditure accurately. Deploy custom fruits, smoothie routines, and fat-shredding strategies grounded in sports science.
          </p>
        </div>

        {/* Dynamic Bento Tab Selector for premium feel */}
        <div className="flex flex-wrap items-center justify-center gap-2 max-w-4xl mx-auto mb-12">
          <button
            onClick={() => setActiveNutritionTab('calculator')}
            className={`px-5 py-3 rounded-sm font-bebas text-sm sm:text-base uppercase tracking-wider transition-all border flex items-center space-x-2 ${
              activeNutritionTab === 'calculator'
                ? 'bg-gold text-black border-gold font-extrabold shadow-lg shadow-gold/15'
                : 'app-card text-neutral-400 border-white/5 hover:text-white'
            }`}
          >
            <Activity className="h-4.5 w-4.5" />
            <span>Macro Calculator</span>
          </button>
          
          <button
            onClick={() => setActiveNutritionTab('fruits_smoothies')}
            className={`px-5 py-3 rounded-sm font-bebas text-sm sm:text-base uppercase tracking-wider transition-all border flex items-center space-x-2 ${
              activeNutritionTab === 'fruits_smoothies'
                ? 'bg-gold text-black border-gold font-extrabold shadow-lg shadow-gold/15'
                : 'app-card text-neutral-400 border-white/5 hover:text-white'
            }`}
          >
            <Apple className="h-4.5 w-4.5" />
            <span>Fruits & Smoothies</span>
          </button>

          <button
            onClick={() => setActiveNutritionTab('avoid_list')}
            className={`px-5 py-3 rounded-sm font-bebas text-sm sm:text-base uppercase tracking-wider transition-all border flex items-center space-x-2 ${
              activeNutritionTab === 'avoid_list'
                ? 'bg-gold text-black border-gold font-extrabold shadow-lg shadow-gold/15'
                : 'app-card text-neutral-400 border-white/5 hover:text-white'
            }`}
          >
            <ShieldAlert className="h-4.5 w-4.5" />
            <span>What to Limit/Avoid</span>
          </button>

          <button
            onClick={() => setActiveNutritionTab('fat_loss_center')}
            className={`px-5 py-3 rounded-sm font-bebas text-sm sm:text-base uppercase tracking-wider transition-all border flex items-center space-x-2 ${
              activeNutritionTab === 'fat_loss_center'
                ? 'bg-gold text-black border-gold font-extrabold shadow-lg shadow-gold/15'
                : 'app-card text-neutral-400 border-white/5 hover:text-white'
            }`}
          >
            <Flame className="h-4.5 w-4.5" />
            <span>Fat Loss Center</span>
          </button>
        </div>

        {/* CONTAINER DISPLAY WINDOW BASED ON SELECTED TAB */}
        <div className="animate-fade-in">
          
          {/* TAB 1: MACRO CALCULATOR */}
          {activeNutritionTab === 'calculator' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16 items-stretch">
              {/* Plate form selection */}
              <div className="lg:col-span-5 app-card border rounded-sm p-6 flex flex-col justify-between shadow-xl">
                <div>
                  <div className="flex items-center space-x-2 mb-6">
                    <Apple className="h-5 w-5 text-gold animate-bounce" />
                    <h3 className="font-bebas text-xl sm:text-2xl font-bold tracking-wide text-white [.light_&]:text-neutral-900 uppercase">MACRO PLATE CALCULATOR</h3>
                  </div>

                  <p className="text-xs text-neutral-400 [.light_&]:text-neutral-600 leading-relaxed font-light mb-6">
                    Type any food, recipe, or description below. Hit the <strong className="text-gold">AI Analyze</strong> button to dynamically calculate its exact sports nutritional metrics using Gemini AI, or refine any values manually!
                  </p>

                  <div className="space-y-4">
                    <div className="flex flex-col space-y-1.5 pt-1">
                      <label className="text-xs uppercase text-neutral-400 [.light_&]:text-neutral-800 font-bold font-mono">Type Food Description</label>
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <input
                            type="text"
                            value={typedFood}
                            onChange={(e) => handleFoodInputChange(e.target.value)}
                            placeholder="e.g. 3 Boiled Egg Whites or Jollof Rice with Roasted Beef"
                            list="food-datalist"
                            className="w-full bg-black [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 rounded p-3 text-xs font-bold text-white [.light_&]:text-neutral-900 focus:border-gold outline-none transition-colors"
                          />
                          <datalist id="food-datalist">
                            {foodRegistry.map(f => (
                              <option key={f.name} value={f.name} />
                            ))}
                          </datalist>
                        </div>
                        <button
                          onClick={handleAnalyzeFood}
                          disabled={isAnalyzing || !typedFood.trim()}
                          type="button"
                          className="px-3 bg-amber-500/10 hover:bg-amber-500/20 text-gold border border-gold/30 rounded text-[11px] font-mono font-bold uppercase tracking-wider flex items-center space-x-1.5 transition-colors shrink-0 disabled:opacity-50"
                        >
                          {isAnalyzing ? (
                            <RefreshCw className="h-3 w-3 animate-spin text-gold" />
                          ) : (
                            <Sparkles className="h-3 w-3 text-gold" />
                          )}
                          <span>{isAnalyzing ? "Analyzing" : "AI Analyze"}</span>
                        </button>
                      </div>
                      {analysisError && (
                        <span className="text-[10px] text-amber-500 italic font-mono">{analysisError}</span>
                      )}
                    </div>

                    {/* Dynamic Macronutrients Section */}
                    <div>
                      <span className="text-[10px] uppercase font-mono font-bold text-neutral-400 [.light_&]:text-neutral-700 block mb-1.5">Nutritional Information (Adjustable)</span>
                      <div className="grid grid-cols-4 gap-2 bg-neutral-950/60 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-3 rounded-sm">
                        <div className="flex flex-col text-center">
                          <span className="text-[8px] uppercase text-neutral-500 font-mono font-black mb-1">Calories</span>
                          <input
                            type="number"
                            value={customCalories}
                            onChange={(e) => setCustomCalories(e.target.value)}
                            className="bg-black/30 [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 text-center font-bold text-gold rounded py-1 text-xs outline-none focus:border-gold"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex flex-col text-center">
                          <span className="text-[8px] uppercase text-neutral-500 font-mono font-black mb-1">Protein (g)</span>
                          <input
                            type="number"
                            value={customProtein}
                            onChange={(e) => setCustomProtein(e.target.value)}
                            className="bg-black/30 [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 text-center font-bold text-white [.light_&]:text-neutral-900 rounded py-1 text-xs outline-none focus:border-gold"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex flex-col text-center">
                          <span className="text-[8px] uppercase text-neutral-500 font-mono font-black mb-1">Carbs (g)</span>
                          <input
                            type="number"
                            value={customCarbs}
                            onChange={(e) => setCustomCarbs(e.target.value)}
                            className="bg-black/30 [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 text-center font-bold text-white [.light_&]:text-neutral-900 rounded py-1 text-xs outline-none focus:border-gold"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex flex-col text-center">
                          <span className="text-[8px] uppercase text-neutral-500 font-mono font-black mb-1">Fat (g)</span>
                          <input
                            type="number"
                            value={customFat}
                            onChange={(e) => setCustomFat(e.target.value)}
                            className="bg-black/30 [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 text-center font-bold text-white [.light_&]:text-neutral-900 rounded py-1 text-xs outline-none focus:border-gold"
                            placeholder="0"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col space-y-1.5">
                      <label className="text-xs uppercase text-neutral-400 [.light_&]:text-neutral-800 font-bold font-mono">Serving Quantity (Multiplier)</label>
                      <input
                        type="number"
                        min="1"
                        max="10"
                        value={servingQty}
                        onChange={(e) => setServingQty(Number(e.target.value))}
                        className="bg-black [.light_&]:bg-white border border-white/10 [.light_&]:border-black/10 rounded p-3 text-xs font-bold text-white [.light_&]:text-neutral-900 focus:border-gold outline-none transition-colors"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-4 border-t border-white/5 [.light_&]:border-black/5">
                  <button
                    onClick={handleAddToPlate}
                    className="w-full bg-gold hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded flex items-center justify-center space-x-2 rounded-sm shadow-md transition-all"
                  >
                    <Plus className="h-4.5 w-4.5" />
                    <span>Append Custom Food to Plate</span>
                  </button>
                </div>
              </div>

              {/* Active Plate & Accumulators */}
              <div className="lg:col-span-7 app-card border rounded-sm p-6 flex flex-col justify-between shadow-xl">
                <div>
                  <div className="flex items-center space-x-2 mb-4">
                    <Activity className="h-4 w-4 text-gold" />
                    <h3 className="font-bebas text-xl sm:text-2xl font-bold tracking-wider text-white [.light_&]:text-neutral-900 uppercase">ACTIVE PLATE SUMMARY</h3>
                  </div>
                  
                  {plate.length === 0 ? (
                    <div className="border border-dashed border-white/10 [.light_&]:border-black/10 rounded-sm p-12 text-center text-neutral-500 text-xs uppercase tracking-wider font-mono">
                      Your plate is currently empty. Mix ingredients on the left to start compiling your energy stats!
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[220px] overflow-y-auto mb-6 pr-2">
                      {plate.map((p) => (
                        <div key={p.id} className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-3 rounded-sm flex justify-between items-center text-xs">
                          <div>
                            <p className="font-bold text-white [.light_&]:text-neutral-950 uppercase">{p.name}</p>
                            <p className="text-neutral-400 [.light_&]:text-neutral-600 text-[10px] uppercase font-bold mt-0.5">
                              {p.quantity} Servings | C: {p.calories * p.quantity} kcal | P: {p.protein * p.quantity}g | C: {p.carbs * p.quantity}g
                            </p>
                          </div>
                          <button
                            onClick={() => handleRemove(p.id)}
                            className="text-neutral-600 hover:text-rose-500 p-1.5 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Aggregates block */}
                <div className="border-t border-white/10 [.light_&]:border-black/15 pt-6 mt-6">
                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-3 rounded-sm shadow-inner">
                      <span className="text-[8px] sm:text-[9px] uppercase text-neutral-400 [.light_&]:text-neutral-500 font-bold block font-mono">CALORIES</span>
                      <span className="font-bebas text-base sm:text-2xl font-bold text-gold">{totals.calories} kcal</span>
                    </div>
                    <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-3 rounded-sm shadow-inner">
                      <span className="text-[8px] sm:text-[9px] uppercase text-neutral-400 [.light_&]:text-neutral-500 font-bold block font-mono">PROTEIN</span>
                      <span className="font-bebas text-base sm:text-2xl font-bold text-white [.light_&]:text-neutral-900">{totals.protein}g</span>
                    </div>
                    <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-3 rounded-sm shadow-inner">
                      <span className="text-[8px] sm:text-[9px] uppercase text-neutral-400 [.light_&]:text-neutral-500 font-bold block font-mono">CARBS</span>
                      <span className="font-bebas text-base sm:text-2xl font-bold text-white [.light_&]:text-neutral-900">{totals.carbs}g</span>
                    </div>
                    <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-3 rounded-sm shadow-inner">
                      <span className="text-[8px] sm:text-[9px] uppercase text-neutral-400 [.light_&]:text-neutral-500 font-bold block font-mono">FATS</span>
                      <span className="font-bebas text-base sm:text-2xl font-bold text-white [.light_&]:text-neutral-900">{totals.fat}g</span>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 2: FRUITS & SMOOTHIES HUB */}
          {activeNutritionTab === 'fruits_smoothies' && (
            <div className="space-y-12 mb-16">
              
              {/* Premium Fruits Section */}
              <div className="app-card border rounded-sm p-6 sm:p-8 shadow-xl">
                <div className="flex items-center space-x-3 mb-6">
                  <Apple className="h-6 w-6 text-gold animate-pulse" />
                  <div>
                    <h3 className="font-bebas text-2xl sm:text-3xl font-black text-white [.light_&]:text-neutral-900 tracking-wide uppercase">PREMIUM ATHLETIC FRUITS GUIDE</h3>
                    <p className="text-xs text-neutral-400 [.light_&]:text-neutral-500 font-mono text-left">PROPERTIES, ACTIVE ENZYMES, AND HORMONAL IMPACTS</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {premiumFruits.map((fruit, idx) => (
                    <div key={idx} className="bg-neutral-950/60 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/10 p-5 rounded-sm relative shadow-inner">
                      <div className="flex justify-between items-start mb-3">
                        <h4 className="font-bebas text-lg font-bold text-gold italic tracking-wide">{fruit.name}</h4>
                        <span className="text-[9px] bg-gold/15 text-gold font-mono px-2 py-0.5 rounded border border-gold/10 font-bold uppercase">{fruit.calories}</span>
                      </div>
                      <p className="text-xs text-neutral-300 [.light_&]:text-neutral-700 leading-relaxed italic mb-4">
                        "{fruit.benefits}"
                      </p>
                      <div className="border-t border-white/5 [.light_&]:border-black/5 pt-3 space-y-1.5 text-[10px] font-mono uppercase text-neutral-400 [.light_&]:text-neutral-600">
                        <div><strong className="text-neutral-300 [.light_&]:text-neutral-800">MACROS:</strong> {fruit.macros}</div>
                        <div><strong className="text-neutral-300 [.light_&]:text-neutral-800">MICROS:</strong> {fruit.vitamins}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Real High-Protein Smoothie Guide */}
              <div className="app-card border rounded-sm p-6 sm:p-8 shadow-xl">
                <div className="flex items-center space-x-3 mb-6">
                  <Coffee className="h-6 w-6 text-gold animate-bounce" />
                  <div>
                    <h3 className="font-bebas text-2xl sm:text-3xl font-black text-white [.light_&]:text-neutral-900 tracking-wide uppercase">HIGH PROTEIN SHAKES & SMOOTHIES</h3>
                    <p className="text-xs text-neutral-400 [.light_&]:text-neutral-500 font-mono text-left">DESIGNED FOR RECONSTRUCTION AND DEEP SATIETY</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {highProteinSmoothies.map((smoothie, idx) => (
                    <div key={idx} className="bg-neutral-950/60 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/10 p-6 rounded-sm shadow-md relative flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-center mb-4">
                          <h4 className="font-bebas text-xl font-bold text-white [.light_&]:text-neutral-900 uppercase italic tracking-wider">{smoothie.title}</h4>
                          <span className="text-[9px] bg-emerald-500/10 text-emerald-500 font-mono font-black px-2 py-1 rounded border border-emerald-500/20">{smoothie.calories}</span>
                        </div>
                        <div className="bg-gold/10 border border-gold/20 py-2 px-3 rounded text-[10px] uppercase font-bold tracking-widest text-gold text-center mb-4">
                          ⚡ {smoothie.protein}
                        </div>
                        <p className="text-xs text-neutral-350 [.light_&]:text-neutral-850 mb-4 leading-relaxed font-mono">
                          <strong className="text-white [.light_&]:text-neutral-950 uppercase font-mono">Composition:</strong> {smoothie.ingredients}
                        </p>
                      </div>
                      <div className="border-t border-white/5 [.light_&]:border-black/10 pt-4 mt-2">
                        <p className="text-[10px] text-neutral-400 [.light_&]:text-neutral-600 leading-relaxed italic">
                          <strong className="text-gold font-bold font-mono">PREPARATION:</strong> {smoothie.prep}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: FOODS TO LIMIT OR AVOID */}
          {activeNutritionTab === 'avoid_list' && (
            <div className="max-w-4xl mx-auto mb-16">
              <div className="app-card border rounded-sm p-6 sm:p-8 shadow-xl">
                <div className="flex items-center space-x-3 mb-6">
                  <ShieldAlert className="h-7 w-7 text-rose-500 animate-pulse" />
                  <div>
                    <h3 className="font-bebas text-2xl sm:text-3xl font-black text-rose-500 tracking-wide uppercase">FOODS TO LIMIT OR INHIBIT</h3>
                    <p className="text-xs text-neutral-400 [.light_&]:text-neutral-500 font-mono text-left">METABOLIC IRRITANTS, TOXIC LIPIDS, AND ENZYME REPRESSORS</p>
                  </div>
                </div>

                <div className="space-y-4">
                  {avoidFoods.map((item, idx) => (
                    <div key={idx} className="bg-neutral-950/70 [.light_&]:bg-neutral-100 border border-rose-950/20 [.light_&]:border-rose-200 p-5 rounded-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-start space-x-3">
                        <span className="w-5 h-5 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center font-bold text-xs shrink-0 font-mono mt-0.5">!</span>
                        <div>
                          <h4 className="font-bold text-rose-450 [.light_&]:text-rose-700 text-sm sm:text-base uppercase tracking-wide font-mono">{item.food}</h4>
                          <p className="text-xs text-neutral-400 [.light_&]:text-neutral-600 mt-1 leading-relaxed italic">
                            {item.reason}
                          </p>
                        </div>
                      </div>
                      <div className="shrink-0 bg-rose-500/10 border border-rose-500/25 py-2 px-3.5 rounded text-[9px] uppercase font-black text-rose-500 tracking-wider text-center font-mono w-fit">
                        BLOCK OR CEASE
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 bg-neutral-950/30 [.light_&]:bg-amber-100/30 border border-gold/15 rounded p-4 text-center">
                  <p className="text-xs text-neutral-350 [.light_&]:text-neutral-700 leading-relaxed italic">
                    <strong className="text-gold">PRO COACH WARNS:</strong> Avoid consuming fast caloric sugars or high trans-fats before intensive exercise. Refined seed lipids bind to blood vessels, dramatically lowering cardiovascular performance coefficient and fat absorption rates.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: FAT LOSS EDUCATION CENTER */}
          {activeNutritionTab === 'fat_loss_center' && (
            <div className="space-y-12 mb-16">
              
              {/* Specialized Fat Loss Botanicals Lookup */}
              <div className="app-card border rounded-sm p-6 sm:p-8 shadow-xl">
                <div className="flex items-center space-x-3 mb-6">
                  <Flame className="h-6 w-6 text-gold text-amber-500 animate-pulse" />
                  <div>
                    <h3 className="font-bebas text-2xl sm:text-3xl font-black text-white [.light_&]:text-neutral-900 tracking-wide uppercase">FAT BURNING SCIENCE & THERMOGENETICS</h3>
                    <p className="text-xs text-neutral-400 [.light_&]:text-neutral-500 font-mono text-left">METABOLIC STIMULATORS AND CELLULAR ADIPOSE DESTROYERS</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Item 1: Lemon & Ginger */}
                  <div className="bg-neutral-950/60 [.light_&]:bg-neutral-200 border border-white/5 [.light_&]:border-black/5 p-6 rounded-sm relative hover:border-gold/30 transition-all shadow-inner">
                    <div className="w-10 h-10 rounded-sm bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 flex items-center justify-center font-black text-sm mb-4 uppercase">
                      🍋
                    </div>
                    <h4 className="font-bebas text-xl font-bold tracking-wider text-white [.light_&]:text-neutral-900 uppercase">LEMON & GINGER</h4>
                    <p className="text-xs text-neutral-300 [.light_&]:text-neutral-700 leading-relaxed mt-3 italic mb-4">
                      Ginger contains active "gingerol" compounds that induce continuous thermogenetic output, whereas Lemon supplies highly alkaline citric trace minerals.
                    </p>
                    <div className="bg-black/40 [.light_&]:bg-white/50 p-3 rounded text-[10px] font-mono uppercase text-neutral-400 [.light_&]:text-neutral-600 space-y-1">
                      <div><strong className="text-gold font-bold text-[9px] font-mono">PRIMARY PATHWAY:</strong> Inhibits lipid synthesis</div>
                      <div><strong className="text-gold font-bold text-[9px] font-mono">RECOMMENDED DOSE:</strong> 1 Tsp Daily (Mornings)</div>
                    </div>
                  </div>

                  {/* Item 2: Turmeric */}
                  <div className="bg-neutral-950/60 [.light_&]:bg-neutral-200 border border-white/5 [.light_&]:border-black/5 p-6 rounded-sm relative hover:border-gold/30 transition-all shadow-inner">
                    <div className="w-10 h-10 rounded-sm bg-orange-500/10 border border-orange-500/20 text-orange-500 flex items-center justify-center font-black text-sm mb-4 uppercase">
                      🌱
                    </div>
                    <h4 className="font-bebas text-xl font-bold tracking-wider text-white [.light_&]:text-neutral-900 uppercase">TURMERIC (CURCUMIN)</h4>
                    <p className="text-xs text-neutral-300 [.light_&]:text-neutral-700 leading-relaxed mt-3 italic mb-4">
                      Curcumin binds directly to cellular adipose vascular arrays, preventing weight-bearing lipid growth. Decreases mechanical muscle tissue inflammation post training.
                    </p>
                    <div className="bg-black/40 [.light_&]:bg-white/50 p-3 rounded text-[10px] font-mono uppercase text-neutral-400 [.light_&]:text-neutral-600 space-y-1">
                      <div><strong className="text-gold font-bold text-[9px] font-mono">PRIMARY PATHWAY:</strong> Inflammatory pathways suppression</div>
                      <div><strong className="text-gold font-bold text-[9px] font-mono">RECOMMENDED DOSE:</strong> 500mg (With Black Pepper)</div>
                    </div>
                  </div>

                  {/* Item 3: Garlic */}
                  <div className="bg-neutral-950/60 [.light_&]:bg-neutral-200 border border-white/5 [.light_&]:border-black/5 p-6 rounded-sm relative hover:border-gold/30 transition-all shadow-inner">
                    <div className="w-10 h-10 rounded-sm bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center font-black text-sm mb-4 uppercase">
                      🧄
                    </div>
                    <h4 className="font-bebas text-xl font-bold tracking-wider text-white [.light_&]:text-neutral-900">GARLIC (ALLICIN)</h4>
                    <p className="text-xs text-neutral-300 [.light_&]:text-neutral-700 leading-relaxed mt-3 italic mb-4">
                      Allicin activates organic cold-shock metabolic proteins, accelerating fat expenditure. Supports stable vascular pressure levels and muscle circulation.
                    </p>
                    <div className="bg-black/40 [.light_&]:bg-white/50 p-3 rounded text-[10px] font-mono uppercase text-neutral-400 [.light_&]:text-neutral-600 space-y-1">
                      <div><strong className="text-gold font-bold text-[9px] font-mono">PRIMARY PATHWAY:</strong> Mitochondrial activation boost</div>
                      <div><strong className="text-gold font-bold text-[9px] font-mono">RECOMMENDED DOSE:</strong> 1 Sliced Raw Clove Daily</div>
                    </div>
                  </div>

                </div>
              </div>

              {/* Skin Health & Acne Education Block */}
              <div className="app-card border rounded-sm p-6 sm:p-8 shadow-xl">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-6">
                  <div className="flex items-center space-x-3">
                    <Sparkles className="h-7 w-7 text-gold text-amber-500 shrink-0" />
                    <div>
                      <h3 className="font-bebas text-2xl sm:text-3xl font-black text-white [.light_&]:text-neutral-900 tracking-wide uppercase">SKIN HEALTH & ACNE REVERSAL CODE</h3>
                      <p className="text-xs text-neutral-400 [.light_&]:text-neutral-500 font-mono text-left">ESTABLISHING CLEAR ANDROGEN BALANCE UNDER ACTIVE TRAINING</p>
                    </div>
                  </div>
                  <div className="bg-gold/10 border border-gold/25 py-1.5 px-3 rounded text-[10px] uppercase font-black text-gold tracking-widest font-mono shrink-0 w-fit">
                    Esthetic & Sports Science
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs leading-relaxed text-neutral-350">
                  <div className="space-y-4">
                    <p className="text-neutral-300 [.light_&]:text-neutral-700 italic">
                      During intensive sports and calisthenics training, increases in physical androgen response compounds can accelerate sebum secretion, provoking breakouts.
                    </p>
                    <ul className="space-y-2 list-disc pl-4 font-mono">
                      <li><strong className="text-white [.light_&]:text-neutral-950 uppercase font-mono">Limit Whey Concentrate & Cow Dairy:</strong> High in bioactive IG-F1 hormones, causing rapid follicular blockages and skin inflammation. Prefer Vegan Pea Isolate when skin-sensitive.</li>
                      <li><strong className="text-white [.light_&]:text-neutral-950 uppercase font-mono">Insulin Regulation:</strong> Simple high-GI sugars immediately foster skin hyperkeratosis. Limit simple white sugar and pastries.</li>
                    </ul>
                  </div>

                  <div className="bg-neutral-950/60 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-5 rounded">
                    <p className="font-bebas text-lg text-gold font-bold tracking-wide italic mb-3">DERMATOLOGIC CLEARANCE STACKS</p>
                    <div className="space-y-3 font-mono text-[10px]">
                      <div>
                        <strong className="text-emerald-500 uppercase">1. Highly Hydrated Matrix:</strong>
                        <p className="text-neutral-450 [.light_&]:text-neutral-600 italic">Consume minimum 4 Liters of clean water daily to continually flush metabolic byproducts.</p>
                      </div>
                      <div>
                        <strong className="text-emerald-500 uppercase">2. Vitamins A, C, E Ratios:</strong>
                        <p className="text-neutral-450 [.light_&]:text-neutral-600 italic">Acquire organic Vitamin A from Spinach & sweet potatoes, Vitamin C from Papayas, and Vitamin E from Avocados for skin recovery.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* NUTRITION GUIDES & HYDRATION SECTION (Original but themed!) */}
        <div className="border-t border-white/10 [.light_&]:border-black/10 pt-16 mt-6">
          <h3 className="font-bebas text-3xl font-extrabold text-center tracking-wider text-white [.light_&]:text-neutral-900 uppercase mb-10">SCIENCE BIOMETRICS & NUTRITION CODES</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-10">
            {[
              { id: 'loss', label: 'Weight Custom Deficits' },
              { id: 'gain', label: 'Hypertrophic Bulk' },
              { id: 'maintenance', label: 'Homeostatic Balance' },
              { id: 'hydration', label: 'Water Protocols' }
            ].map((g) => (
              <button
                key={g.id}
                onClick={() => setActiveGuide(g.id as any)}
                className={`py-3 rounded-sm font-bebas text-sm sm:text-base uppercase tracking-wider transition-all border ${
                  activeGuide === g.id
                    ? 'bg-amber-500 text-black border-amber-500 font-extrabold shadow-lg shadow-amber-500/10'
                    : 'app-card text-neutral-400 border-white/5 hover:text-white'
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>

          {/* Guide Display Panel */}
          <div className="app-card border p-8 rounded max-w-4xl mx-auto text-left shadow-lg">
            {activeGuide === 'loss' && (
              <div className="space-y-4">
                <h4 className="font-bebas text-2xl text-gold tracking-wide">FAT DESTRUCTS: CALORIC LAW</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs leading-relaxed">
                  <p className="text-neutral-300 [.light_&]:text-neutral-700 italic">
                    <strong>1. Caloric Deficit</strong>: Establish a 15-20% deficit relative to Total Daily Energy Expenditure. This forces systemic lipase actions, breaking down visceral neutral lipids.
                  </p>
                  <p className="text-neutral-300 [.light_&]:text-neutral-700 italic">
                    <strong>2. Protein Multipliers</strong>: Deliver 2.0g of protein per kilogram of weight. Preserves structural muscle nitrogen balances securely.
                  </p>
                </div>
              </div>
            )}

            {activeGuide === 'gain' && (
              <div className="space-y-4">
                <h4 className="font-bebas text-2xl text-gold tracking-wide">HYPERTROPHY BULK STATE CODES</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs leading-relaxed">
                  <p className="text-neutral-300 [.light_&]:text-neutral-700 italic">
                    <strong>1. Caloric Abundance</strong>: Add 300 to 500 clean calories above metabolic expenditure baseline to supply structural energetic needs of muscle synthesis.
                  </p>
                  <p className="text-neutral-300 [.light_&]:text-neutral-700 italic">
                    <strong>2. Progressive Load Overload</strong>: Increment weight metrics consistently, logging deadlifts, bench setups, squatted rows, and physical pull reps.
                  </p>
                </div>
              </div>
            )}

            {activeGuide === 'maintenance' && (
              <div className="space-y-4">
                <h4 className="font-bebas text-2xl text-gold tracking-wide">METABOLIC HOMEOSTASIS RULES</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs leading-relaxed">
                  <p className="text-neutral-300 [.light_&]:text-neutral-700 italic">
                    <strong>1. Isocaloric Target</strong>: Feed exactly up to baseline expenditure demands. Equates system inputs and outputs perfectly to maintain physical state.
                  </p>
                  <p className="text-neutral-300 [.light_&]:text-neutral-700 italic">
                    <strong>2. Daily Tracking Logs</strong>: Track active steps (aiming for 10,000 steps daily) and hydration levels to keep hormonal parameters pristine.
                  </p>
                </div>
              </div>
            )}

            {activeGuide === 'hydration' && (
              <div className="space-y-4 relative overflow-hidden">
                <div className="absolute top-0 right-0 text-amber-500/10"><Droplet className="w-16 h-16" /></div>
                <h4 className="font-bebas text-2xl text-gold tracking-wide flex items-center space-x-2">
                  <Droplet className="h-5 w-5" />
                  <span>PREMIUM SPORT WATER HYDRATION RECIPES</span>
                </h4>
                <div className="bg-neutral-950 [.light_&]:bg-neutral-100 border border-white/5 [.light_&]:border-black/5 p-5 rounded text-xs leading-relaxed max-w-2xl">
                  <p className="text-white [.light_&]:text-neutral-900 font-bold uppercase tracking-wider mb-2">🍹 CITRUS DETOX & ELECTROLYTE STACK</p>
                  <ul className="space-y-1.5 text-neutral-400 [.light_&]:text-neutral-600 list-disc pl-4 mb-4 font-mono text-[11px]">
                    <li>1/2 Fresh squeezed Organic Lemon (alkaline balancing agent)</li>
                    <li>3 Slices of fresh crisp Cucumber (natural electrolyte source)</li>
                    <li>2 Liters of fresh, clean chilled mineral water</li>
                  </ul>
                  <p className="text-gold font-bold uppercase text-[10px] tracking-widest bg-gold/10 border border-gold/20 py-1.5 px-3 rounded inline-block font-mono">
                    COACH RECOVERY PROTOCOL: TAKE FIRST THING UPON WAKING UP TO 3 TIMES WEEKLY
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
