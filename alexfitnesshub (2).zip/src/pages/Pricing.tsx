import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Check, Sparkles, CreditCard, Award, Zap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { User } from '../types';
import { apiFetch } from '../lib/api';

interface MultiMonthSelectorProps {
  premiumFeatures: string[];
  isLoading: boolean;
  handleInitializePayment: (plan: any, amount: number) => void;
}

function MultiMonthSelector({ premiumFeatures, isLoading, handleInitializePayment }: MultiMonthSelectorProps) {
  const [months, setMonths] = useState(3); // default to 3 months
  
  // No discount for 1 month, 5% discount for 2-6 months
  const isDiscounted = months >= 2 && months <= 6;
  const priceBeforeDiscount = 25000 * months;
  const discountMultiplier = isDiscounted ? 0.95 : 1.0;
  const finalPrice = Math.floor(priceBeforeDiscount * discountMultiplier);
  const savings = priceBeforeDiscount - finalPrice;

  return (
    <div className="bg-[#111111]/90 border border-white/10 rounded-sm p-8 flex flex-col justify-between hover:border-gold/30 transition-all relative">
      <div>
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-bebas text-3xl font-bold tracking-wider text-white italic">MULTI-MONTH ELITE</h3>
            <p className="text-[10px] text-amber-500 uppercase font-mono tracking-widest mt-1">
              {isDiscounted ? '🔥 5% AUTOMATIC MULTI-MONTH DISCOUNT' : 'Short-term target'}
            </p>
          </div>
          <span className="bg-white/5 text-neutral-400 border border-gold/40 text-[9px] px-2.5 py-1 rounded-sm font-bold uppercase tracking-wider">
            {months} {months === 1 ? 'Month' : 'Months'} Plan
          </span>
        </div>

        {/* Dynamic Month Selector Slider */}
        <div className="my-6 bg-black/60 p-4 border border-white/5 rounded-sm">
          <div className="flex justify-between text-xs text-neutral-400 mb-2 font-mono">
            <span>CHOOSE PLAN DURATION:</span>
            <span className="text-white font-bold text-amber-500">{months} {months === 1 ? 'Month' : 'Months'}</span>
          </div>
          <input 
            type="range" 
            min="1" 
            max="6" 
            value={months} 
            onChange={(e) => setMonths(Number(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[8px] text-neutral-500 font-mono mt-1.5">
            <span>1 Mo (₦25k)</span>
            <span>2 Mo (5%)</span>
            <span>3 Mo (5%)</span>
            <span>4 Mo (5%)</span>
            <span>5 Mo (5%)</span>
            <span>6 Mo (5%)</span>
          </div>
        </div>
        
        <div className="my-6">
          <div className="flex items-baseline space-x-2">
            <span className="font-bebas text-5xl font-black text-white">₦{finalPrice.toLocaleString()}</span>
            {isDiscounted && (
              <span className="text-xs line-through text-neutral-500 font-mono">₦{priceBeforeDiscount.toLocaleString()}</span>
            )}
          </div>
          {isDiscounted ? (
            <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest block mt-1">
              🎁 YOU SAVE ₦{savings.toLocaleString()} AUTOMATICALLY!
            </span>
          ) : (
            <span className="text-[10px] text-neutral-500 uppercase tracking-widest block mt-1">₦25,000 billed flat rate</span>
          )}
        </div>

        <ul className="space-y-3.5 border-t border-white/5 pt-6">
          {premiumFeatures.map((feat, i) => (
            <li key={i} className="flex items-start space-x-3 text-xs text-neutral-300">
              <Check className="h-4 w-4 text-gold shrink-0 mt-0.5" />
              <span>{feat}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-10">
        <button
          disabled={isLoading}
          onClick={() => handleInitializePayment(`${months} months`, finalPrice)}
          className="w-full bg-white/5 border border-gold hover:bg-gold/10 text-white font-bold uppercase text-xs tracking-widest py-4 rounded-sm transition-all"
        >
          {isLoading ? 'Setting up transaction...' : `Get ${months} Month${months > 1 ? 's' : ''} Premium`}
        </button>
        <p className="text-[9px] text-center text-neutral-500 mt-3 uppercase tracking-widest">Securely initiated Monnify checkout</p>
      </div>
    </div>
  );
}

export default function Pricing() {
  const navigate = useNavigate();
  const { user, refreshUser } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [currentCheckout, setCurrentCheckout] = useState<{
    plan: string;
    amount: number;
    reference: string;
  } | null>(null);
  
  const handleInitializePayment = async (plan: string, amount: number) => {
    if (!user) {
      alert("Please Sign Up or Login first to unlock ALEXFITNESSHUB premium programs!");
      navigate('/auth/signup');
      return;
    }

    setIsLoading(true);
    try {
      const data = await apiFetch<any>('/api/payment/initialize', {
        method: 'POST',
        body: JSON.stringify({
          userId: user.id,
          planType: plan,
          amount,
          email: user.email,
          customerName: user.name || 'Athlete Name'
        })
      });
      
      const { paymentReference, checkoutUrl, apiKey, contractCode } = data;
      const monnify = (window as any).MonnifySDK;

      if (monnify) {
        console.log("[MONNIFY] Launching Inline payment checkout flow...");
        monnify.initialize({
          amount: Number(amount),
          currency: "NGN",
          reference: paymentReference,
          customerName: user.name || 'Athlete Client',
          customerEmail: user.email,
          apiKey: apiKey || "MK_TEST_XXXXXXXXXX",
          contractCode: contractCode || "xxxxxxxxx",
          paymentDescription: `ALEXFITNESSHUB Premium Subscription: ${plan} Elite`,
          onComplete: async function (response: any) {
            console.log("[MONNIFY COMPLETED]", response);
            // Verify payment on backend to confirm securely
            setIsLoading(true);
            try {
              await apiFetch<any>('/api/payment/verify', {
                method: 'POST',
                body: JSON.stringify({
                  reference: paymentReference,
                  transactionReference: response.transactionReference || '',
                  userId: user.id,
                  planType: plan,
                  amount: amount,
                  paymentStatus: response.paymentStatus || 'PAID'
                })
              });
              await refreshUser();
              alert(`🎉 Premium tier details unlocked! Welcome to ALEXFITNESSHUB.`);
              navigate('/dashboard');
            } catch (err: any) {
              console.error(err);
              alert("Verification complete. Confirming details inside your athlete dashboard panel...");
              navigate('/dashboard');
            } finally {
              setIsLoading(false);
            }
          },
          onClose: function (closeData: any) {
            console.log("[MONNIFY CLOSED]", closeData);
            if (closeData && closeData.paymentStatus === "USER_CANCELLED") {
              alert("Payment cancelled. Feel free to upgrade whenever you are ready to forge your physique!");
            } else {
              refreshUser().then(() => {
                navigate('/dashboard');
              });
            }
          },
          onError: function (error: any) {
            console.error("[MONNIFY ERROR]", error);
            alert("An error occurred during payment processing. Please crosscheck internet stability and card credentials.");
          }
        });
      } else {
        console.warn("[MONNIFY] SDK was not loaded. Activating robust interactive sandbox simulator modal fallback.");
        setCurrentCheckout({
          plan,
          amount,
          reference: paymentReference
        });
        setShowModal(true);
      }
    } catch (err: any) {
      console.error(err);
      alert(`Payment initialization failed: ${err.message || 'Check server connection'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyComplete = async () => {
    if (!currentCheckout || !user) return;
    
    setIsLoading(true);
    try {
      const data = await apiFetch<any>('/api/payment/verify', {
        method: 'POST',
        body: JSON.stringify({
          reference: currentCheckout.reference,
          userId: user.id,
          planType: currentCheckout.plan,
          amount: currentCheckout.amount
        })
      });
      
      if (data && data.success) {
        await refreshUser();
        setShowModal(false);
        alert(`🎉 Premium Unlocked! Welcome to ALEXFITNESSHUB Elite tier.`);
        navigate('/dashboard');
      }
    } catch (err) {
      console.error(err);
      alert("Failed to confirm transaction.");
    } finally {
      setIsLoading(false);
    }
  };

  const premiumFeatures = [
    'Complete AI Fitness Coach Real-time consultation',
    'Custom Workout Generator powered by Google Gemini',
    'Interactive Nutrition Planner and Cook Guide Generator',
    'Full access to all 5 Celebrity Physique programs',
    'Unlock Military Calisthenics tactical tracks',
    'All Gym & Home Exercise library guides',
    'Historical Transformation progress charts & analytics',
    'Log and track daily calorie budgets perfectly'
  ];

  return (
    <div className="bg-black text-white pt-24 min-h-screen relative overflow-hidden">
      {/* High Density Radial Dot Grid Background Overlay */}
      <div className="absolute inset-0 bg-grid-pattern opacity-15"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 z-10">
        
        {/* Header content */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-3 py-1 rounded-full text-[10px] text-gold font-bold uppercase mb-4 tracking-widest">
            <Sparkles className="h-3.5 w-3.5 animate-pulse" />
            <span>Monnify Secure Billing Gateway Integration</span>
          </div>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-tighter uppercase italic">
            UPGRADE TO <span className="text-gold">PREMIUM</span>
          </h1>
          <p className="text-white/50 mt-4 leading-relaxed font-light text-sm italic">
            Unlock the absolute training blueprints of Coach Alex & Captain Babatunde. Get full AI consulting, dynamic workout generation, and progress logging today.
          </p>
        </div>

        {/* Dual pricing grids */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto items-stretch">
          
          {/* Monthly / Custom Multi-Month plan */}
          <MultiMonthSelector 
            premiumFeatures={premiumFeatures} 
            isLoading={isLoading} 
            handleInitializePayment={handleInitializePayment} 
          />

          {/* Yearly plan - RECOMMENDED */}
          <div className="bg-[#111111]/95 border-2 border-gold rounded-sm p-8 flex flex-col justify-between hover:scale-[1.01] transition-all relative shadow-2xl shadow-gold/5">
            <div className="absolute -top-4 right-6 bg-gold text-black font-bebas text-xs font-black uppercase tracking-widest px-3 py-1.5 rounded-sm shadow">
              🚀 BEST VALUE - SAVE 10%
            </div>
            
            <div>
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bebas text-3xl font-bold tracking-wider text-gold italic">ANNUAL CHAMPION</h3>
                  <p className="text-[10px] text-gold/80 uppercase font-mono tracking-widest mt-1">Ultimate transformation</p>
                </div>
                <span className="bg-gold/10 text-gold border border-gold/20 text-[9px] px-3 py-1 rounded-sm font-bold uppercase tracking-wider">12 Months</span>
              </div>
              
              <div className="my-8">
                <span className="font-bebas text-5xl font-black text-white">₦270,000</span>
                <span className="text-[10px] text-neutral-500 uppercase tracking-widest block mt-1">₦22,500 monthly equivalent</span>
              </div>

              <ul className="space-y-3.5 border-t border-white/5 pt-6">
                {premiumFeatures.map((feat, i) => (
                  <li key={i} className="flex items-start space-x-3 text-xs text-neutral-300">
                    <Check className="h-4 w-4 text-gold shrink-0 mt-0.5" />
                    <span className="font-semibold">{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-10">
              <button
                disabled={isLoading}
                onClick={() => handleInitializePayment('yearly', 270000)}
                className="w-full bg-gold hover:brightness-110 text-black font-black uppercase text-xs tracking-widest py-4 rounded-sm transition-all"
              >
                {isLoading ? 'Setting up transaction...' : 'Get Yearly Premium (Save 10%)'}
              </button>
              <p className="text-[9px] text-center text-gold mt-3 uppercase tracking-widest font-bold">Most popular result focused tier</p>
            </div>
          </div>

        </div>

      </div>

      {/* MONNIFY CHECKOUT SIMULATED MODAL */}
      {showModal && currentCheckout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 px-4 animate-fade-in relative">
          <div className="bg-neutral-950 border border-white/10 rounded-sm p-6 max-w-sm w-full space-y-6 z-50">
            
            {/* Monnify logo design */}
            <div className="text-center border-b border-white/10 pb-4">
              <div className="inline-flex items-center space-x-1.5 text-gold bg-gold/10 border border-gold/20 px-3 py-1 rounded-sm">
                <Zap className="h-4 w-4 animate-pulse" />
                <span className="text-[10px] uppercase font-black tracking-widest">MONNIFY PORTAL SECURE</span>
              </div>
              <h3 className="font-bebas text-xl text-white tracking-widest mt-2 uppercase italic font-bold">TRANSACT VERIFICATION</h3>
            </div>

            {/* Bill details */}
            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex justify-between text-neutral-400">
                <span>Paying To:</span>
                <span className="text-white font-bold">ALEXFITNESSHUB NIG LTD</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Account Email:</span>
                <span className="text-white font-bold">{user?.email}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Plan Selection:</span>
                <span className="text-gold uppercase font-bold">{currentCheckout.plan} Elite</span>
              </div>
              <div className="flex justify-between text-neutral-400 border-t border-white/10 pt-3 mt-2">
                <span>Total Amount:</span>
                <span className="text-white text-lg font-bebas font-black">₦{currentCheckout.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-500 truncate text-[9px] uppercase tracking-wider">
                <span>Log Ref:</span>
                <span className="text-neutral-400">{currentCheckout.reference}</span>
              </div>
            </div>

            {/* Simulated gateway actions */}
            <div className="space-y-2.5 pt-2">
              <button
                onClick={handleVerifyComplete}
                className="w-full flex items-center justify-center space-x-2 bg-emerald-500 hover:bg-emerald-600 text-black font-black uppercase text-xs tracking-widest py-3.5 rounded-sm"
              >
                <CreditCard className="h-4 w-4" />
                <span>Simulate Card Transaction</span>
              </button>
              <button
                onClick={() => setShowModal(false)}
                className="w-full bg-[#111111] hover:bg-neutral-900 text-neutral-450 text-xs uppercase tracking-widest py-2.5 rounded-sm border border-white/5"
              >
                Cancel Billing
              </button>
            </div>

            <p className="text-[9px] text-neutral-500 text-center uppercase tracking-widest leading-normal font-mono">
              secure billing integration sandbox. Clicking simulate verifies instantly via backend webhooks.
            </p>

          </div>
        </div>
      )}

    </div>
  );
}
