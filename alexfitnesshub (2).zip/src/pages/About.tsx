import React from 'react';
import { Target, ShieldCheck, HeartPulse, Trophy } from 'lucide-react';

export default function About() {
  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">ESTABLISHED 2020</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black tracking-wide text-white">
            CHALLENGING HUMAN <span className="text-amber-500">LIMITATIONS</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            ALEXFITNESSHUB is a premier digital transformational infrastructure designed to bridge the gap between hard science and daily physical training.
          </p>
        </div>

        {/* Content Split */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <div className="relative h-[450px] border border-neutral-800 rounded overflow-hidden">
            <img
              src="https://play-lh.googleusercontent.com/8mOFzDYXpXV9Z7n6pt5WlIthsjtvprvsqYVvXHb81ctGblmEhmheZxgSOsZFlUsWVqjj=w240-h480-rw"
              alt="Coach Alex biography"
              className="w-full h-full object-cover opacity-70"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            <div className="absolute bottom-6 left-6 right-6">
              <span className="bg-amber-500 text-black font-bebas text-xs font-bold px-3 py-1 uppercase">FOUNDER & CEO</span>
              <h2 className="font-bebas text-2xl font-bold text-white tracking-wide mt-2">COACH ALEX</h2>
              <p className="text-xs text-neutral-300 mt-1">Former Tactical Athlete & Peak Recomposition Specialist</p>
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="font-bebas text-3xl sm:text-4xl font-extrabold tracking-wide text-amber-500">THE RECOMPOSITION ARCHITECT</h2>
            <p className="text-neutral-300 leading-relaxed font-light">
              "When I created ALEXFITNESSHUB, my goal was to eliminate the standard commercial guesswork from training. Many platforms recycle templates without understanding individual mechanical thresholds. We leverage advanced mathematical parameters combined with artificial intelligence to optimize your energy expenditure, structural loading, and anabolic recovery."
            </p>
            <p className="text-neutral-400 text-sm leading-relaxed">
              Coach Alex has spent over 12 years helping busy executives, military recruits, and everyday fitness beginners drop weight, gain lean density, and cure metabolic syndromes. Supported by Captain Babatunde, the former special forces performance lead, ALEXFITNESSHUB is built to get you in absolute peak condition.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-900">
              <div className="flex space-x-3 items-start">
                <Target className="h-5 w-5 text-amber-500 shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-sm text-white uppercase">ULTIMATE ACCURACY</h4>
                  <p className="text-xs text-neutral-500">Calibrated to your exact height, weight, activity variables, and desired target mass.</p>
                </div>
              </div>
              <div className="flex space-x-3 items-start">
                <ShieldCheck className="h-5 w-5 text-amber-500 shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-sm text-white uppercase">MILITARY RIGOR</h4>
                  <p className="text-xs text-neutral-500">Elite calisthenics routines tested and proven under intense high-stamina tactical guidelines.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Vision blocks */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-neutral-950 border border-neutral-900 p-8 rounded hover:border-amber-500/30 transition-all">
            <Trophy className="h-8 w-8 text-amber-500 mb-4" />
            <h3 className="font-bebas text-2xl font-bold text-white tracking-wider mb-2">METABOLIC SCIENCE</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              We focus heavily on the Laws of Thermodynamics. Fat loss is driven through exact, healthy energy deficits; muscle gain is sustained through progressive mechanical loading and optimal nitrogen balance.
            </p>
          </div>
          <div className="bg-neutral-950 border border-neutral-900 p-8 rounded hover:border-amber-500/30 transition-all">
            <HeartPulse className="h-8 w-8 text-amber-500 mb-4" />
            <h3 className="font-bebas text-2xl font-bold text-white tracking-wider mb-2">METICULOUS NUTRITION</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              We respect your cultural cuisine. Our database features full macros for delicious Nigerian staples (yam, plantain, grilled fish, beans) paired with global power foods (egg whites, salmon, oats, Greek yogurt).
            </p>
          </div>
          <div className="bg-neutral-950 border border-neutral-900 p-8 rounded hover:border-amber-500/30 transition-all">
            <Target className="h-8 w-8 text-amber-500 mb-4" />
            <h3 className="font-bebas text-2xl font-bold text-white tracking-wider mb-2">ACCESSIBLE EXCELLENCE</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Whether you are training at home without any equipment (Military calisthenics) or inside a world-class compound power rack, we provide the full, precise blueprint to succeed.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
