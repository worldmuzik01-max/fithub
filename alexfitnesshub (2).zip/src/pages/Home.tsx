import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Dumbbell, Star, ArrowRight, Award, Trophy, Users, ShieldCheck, HeartPulse, 
  Zap, Play, Sparkles, ChevronDown, Check, ChevronRight, HelpCircle, Shield, Apple, Flame, UserCheck 
} from 'lucide-react';
import { TESTIMONIALS } from '../data';

export default function Home() {
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'gym' | 'home' | 'calisthenics' | 'cardio'>('all');

  const stats = [
    { label: 'Active Members', value: '15,240+', icon: Users, desc: 'Enrolled athletes tracking milestones daily' },
    { label: 'Workouts Available', value: '350+ Routines', icon: Dumbbell, desc: 'Interactive weight & bodyweight challenges' },
    { label: 'Meal Plans', value: '180+ Customized', icon: Apple, desc: 'Clean high-protein nutritional frameworks' },
    { label: 'Success Stories', value: '220+ Verified', icon: Trophy, desc: 'Unfiltered before/after aesthetic reversals' }
  ];

  const categories = [
    { id: 'gym', label: 'Gym Hypertrophy', count: '140+ Exercises', desc: 'Symmetric mass building using barbell and machines heavy compound loads.', path: '/gym-workouts' },
    { id: 'home', label: 'Home Conditioning', count: '90+ Exercises', desc: 'Metabolic dumbbell and bodyweight circuits to burn visceral fat from any room.', path: '/home-workouts' },
    { id: 'calisthenics', label: 'Military Calisthenics', count: '85+ Movements', desc: 'Strict tempo gravity resistance training for bulletproof tendons and pure explosive force.', path: '/calisthenics' },
    { id: 'cardio', label: 'Intense Cardio & HIIT', count: '45+ Workouts', desc: 'High-energy lipid oxidation sprints, swimming regimes, and the iconic 12-3-30 protocol.', path: '/cardio' }
  ];

  const featuredWorkouts = [
    {
      title: 'V-Taper Chest & Back Defilade',
      category: 'Gym Workouts',
      duration: '45 Mins',
      difficulty: 'Advanced',
      xp: '250 XP',
      burn: '480 kcal',
      exercises: ['Bench Press (4 sets)', 'Weighted Pullups (3 sets)', 'Bent Over Barbell Rows (4 sets)', 'Machine Incline Press (3 sets)'],
      img: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=80'
    },
    {
      title: 'Tactical Calisthenics Core Forge',
      category: 'Calisthenics',
      duration: '35 Mins',
      difficulty: 'Intermediate',
      xp: '180 XP',
      burn: '390 kcal',
      exercises: ['Dead-hang Pullups (4 sets)', 'Military Pushups (5 sets)', 'Hanging Leg Raises (4 sets)', 'Tricep Dip Cadence (4 sets)'],
      img: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=600&auto=format&fit=crop&q=80'
    },
    {
      title: '12-3-30 Endurance Recomp',
      category: 'Cardio & HIIT',
      duration: '30 Mins',
      difficulty: 'Beginner',
      xp: '120 XP',
      burn: '350 kcal',
      exercises: ['Treadmill Incline 12% (30 mins)', 'Speed: 3.0 mph continuous', 'Hydration checkpoint (1.0L)', 'Post-workout somatic stretches'],
      img: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=600&auto=format&fit=crop&q=80'
    }
  ];

  const faqs = [
    {
      q: "What makes ALXFITNESSHUB different from normal fitness apps?",
      a: "ALXFITNESSHUB combines advanced physical science, customized medical-grade meal planning, traditional high-protein dietary guides, and local offline accountability support under Coach Alex Babatunde and our interactive AI Coach. We focus on real biological metrics rather than surface-level trends."
    },
    {
      q: "How does the AI Fitness Coach work?",
      a: "Our AI Coach leverages elite physical biomechanics data and high-protein nutrition databases. It analyzes your unique stature, height, target weight, current body fat index, and allergies to instantly generate training modifications, macro splits, and customized lifestyle suggestions."
    },
    {
      q: "Can I use this if I prefer working out entirely at home with standard equipment?",
      a: "Yes! We have a complete 'Home Conditioning' program that relies on dumbbells or simple bodyweight movements, delivering exact progression schemas that guarantee optimal calorie burn and metabolic stimulation without needing heavy gym machinery."
    },
    {
      q: "How are the nutritional guides structured?",
      a: "Our guides provide clear, actionable insights such as the scientific value of anti-inflammatory additives like garlic and turmeric, lists of processed high-fructose food groups to avoid, and easy high-protein recipes. We cater to diverse diets, with special guides matching traditional healthy whole foods."
    },
    {
      q: "What is your refund or subscription cancellation policy?",
      a: "You can cancel your subscription at any time directly through your physical dashboard account settings page with a single click. There are no hidden fees, long-term lock-in contracts, or exit penalties."
    }
  ];

  const trustLogos = [
    { name: 'Athletics Weekly', label: 'Endorsed' },
    { name: 'Men\'s Health', label: 'Featured' },
    { name: 'Nigeria Sports Association', label: 'Certified Partners' },
    { name: 'Elite Performance Org', label: 'Audited Systems' }
  ];

  const handleToggleFaq = (index: number) => {
    setActiveFaq(activeFaq === index ? null : index);
  };

  return (
    <div className="app-bg transition-colors duration-300">
      
      {/* FULL-SCREEN PREMIUM CINEMATIC HERO SECTION */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 pb-16 px-4 overflow-hidden [body.light_&]:bg-neutral-50 dark:bg-black">
        
        {/* looping background video */}
        <div className="absolute inset-0 w-full h-full object-cover overflow-hidden z-0 bg-black">
          <video
            autoPlay
            loop
            muted
            playsInline
            onCanPlayThrough={() => setVideoLoaded(true)}
            className={`w-full h-full object-cover transition-opacity duration-1000 ${
              videoLoaded ? 'opacity-40' : 'opacity-25'
            }`}
          >
            {/* Dark aesthetic high-contrast fitness video loop */}
            <source 
              src="https://player.vimeo.com/external/371433846.sd.mp4?s=236da2f3c054354784ff406a4a6e02cf1e6c311f&profile_id=139&oauth2_token_id=57447761" 
              type="video/mp4" 
            />
            {/* Fallback video loop */}
            <source 
              src="https://player.vimeo.com/external/403737525.sd.mp4?s=1d5ae138b32906b3bc6b93309a4734898deff59c&profile_id=139&oauth2_token_id=57447761" 
              type="video/mp4" 
            />
          </video>

          {/* Premium dark gradient overlay for maximum readability contrast */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/85 to-black/35 [.light_&]:from-neutral-950 [.light_&]:via-black/90 [.light_&]:to-black/40"></div>
          
          {/* Subtle tech grid patterns */}
          <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
          
          {/* Ambient background glow dots */}
          <div className="absolute top-1/4 left-10 w-96 h-96 rounded-full bg-amber-500/15 blur-[150px] animate-pulse"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-amber-500/10 blur-[150px]"></div>
        </div>

        {/* Content container */}
        <div className="relative max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center z-10 w-full pt-12">
          
          {/* Text panel */}
          <div className="lg:col-span-7 space-y-8 text-left animate-fade-in">
            
            {/* Trust Indicator Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-neutral-900/95 border border-amber-500/30 rounded-full w-fit backdrop-blur-md">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping"></span>
              <span className="text-[9.5px] font-black uppercase tracking-widest text-amber-500 font-mono">
                ⭐ ELITE ATHLETIC TRANSFORMATION Blueprints
              </span>
            </div>
            
            {/* Mandated Powerful Title */}
            <h1 className="font-display text-[44px] sm:text-[60px] md:text-[76px] leading-[0.95] font-black text-white uppercase tracking-tight">
              Transform Your Body.<br />
              <span className="text-amber-500 italic">Build Strength.</span><br />
              Track Your Progress.
            </h1>
            
            {/* Subtitle description */}
            <p className="text-neutral-300 text-sm sm:text-base max-w-xl font-light leading-relaxed">
              Achieve elite stature with military calisthenics protocols, premium gym programs, and custom whole-food nutrition grids. Directed by professional physical scientists to secure optimal body fat decline and peak hypertrophy.
            </p>

            {/* Mandated Buttons: Start Free & Explore Workouts */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <Link
                to="/auth/signup"
                className="px-8 py-4 bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-widest rounded-full transition-all duration-300 flex items-center justify-center gap-2 transform hover:-translate-y-0.5 active:translate-y-0 shadow-lg shadow-amber-500/10"
              >
                <span>Start Free</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </Link>
              <Link
                to="/workouts"
                className="px-8 py-4 border border-white/20 hover:border-amber-500/50 bg-white/5 hover:bg-white/10 text-white text-xs font-bold uppercase tracking-widest rounded-full transition-all duration-300 flex items-center justify-center backdrop-blur-sm transform hover:-translate-y-0.5 active:translate-y-0"
              >
                Explore Workouts
              </Link>
            </div>

            {/* Interactive Rating Badge / Trust Factor */}
            <div className="flex items-center space-x-3 pt-4 border-t border-white/10 max-w-md">
              <div className="flex space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-amber-500 text-amber-500" />
                ))}
              </div>
              <p className="text-xs text-neutral-400 font-mono">
                Rated <strong className="text-white">4.9/5 stars</strong> by 150k+ verified athletes worldwide
              </p>
            </div>

          </div>

          {/* Visual Showcase (Model & Floating badging) */}
          <div className="lg:col-span-5 relative flex justify-center py-6">
            <div className="relative w-80 h-[440px] sm:w-[340px] sm:h-[480px] border border-white/10 rounded-2xl bg-neutral-950 overflow-hidden shadow-2xl transition-all">
              <img
                src="https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=500&auto=format&fit=crop&q=80"
                alt="Elite Athlete Hypertrophy Workout Showcase"
                className="w-full h-full object-cover opacity-60"
              />
              {/* Dark vignette bottom gradients */}
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/20 to-transparent"></div>
              
              {/* Overlay card */}
              <div className="absolute bottom-6 left-6 right-6 bg-neutral-950/90 border border-white/10 p-4 rounded-xl backdrop-blur-md">
                <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono block">LIVE INTERACTIVE SESSION</span>
                <p className="font-display text-base font-black tracking-tight text-white uppercase mt-1">"V-TAPER GYM HYPERTROPHY"</p>
                <div className="flex items-center space-x-2 mt-2 pt-2 border-t border-white/5">
                  <Flame className="h-4.5 w-4.5 text-amber-500" />
                  <span className="text-[10px] text-neutral-400 font-medium">9.5 MET activity level</span>
                </div>
              </div>
            </div>

            {/* High-Integrity Floating Tag */}
            <div className="absolute top-12 -left-6 sm:-left-10 bg-white p-4 rounded-xl shadow-2xl border border-black/10 transform -rotate-3 select-none">
              <span className="text-[8.5px] font-black uppercase text-amber-600 tracking-widest font-mono block mb-1">PRO VENUE SCORE</span>
              <span className="text-base font-black text-black leading-none font-display tracking-tight uppercase">ANABOLIC GOLD RATED</span>
            </div>

            {/* Corner Bracket Accents to highlight elite framing */}
            <div className="absolute -top-3 -right-3 w-16 h-16 border-t-2 border-r-2 border-amber-500/40 rounded-tr-lg"></div>
            <div className="absolute -bottom-3 -left-3 w-16 h-16 border-b-2 border-l-2 border-amber-500/40 rounded-bl-lg"></div>
          </div>

        </div>

        {/* Scroll link marker */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1-2 flex flex-col items-center space-y-1 opacity-50 cursor-pointer pointer-events-none">
          <span className="text-[8px] tracking-widest uppercase text-white font-mono">SCROLL TO EXPERIENCE</span>
          <ChevronDown className="h-4 w-4 text-amber-500 animate-bounce" />
        </div>
      </section>

      {/* STATISTICS SECTION */}
      <section className="relative z-10 bg-neutral-950 border-y border-white/5 py-12 px-4 shadow-xl">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <div key={i} className="text-center space-y-2 p-4">
                  <div className="mx-auto w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-500 border border-amber-500/20">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-white tracking-tight">{stat.value}</div>
                  <div className="text-xs font-bold text-amber-500 uppercase tracking-widest font-mono">{stat.label}</div>
                  <p className="text-[10px] text-neutral-500 leading-tight pr-1">{stat.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* WORKOUT CATEGORIES SECTION */}
      <section className="py-24 px-4 bg-black relative">
        <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>
        <div className="relative max-w-7xl mx-auto text-center space-y-12">
          
          <div className="space-y-4">
            <span className="text-amber-500 font-extrabold text-xs uppercase tracking-widest font-mono block">SELECT TRAINING INTENSITY</span>
            <h2 className="font-display text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">WORKOUT CATEGORIES</h2>
            <div className="w-16 h-1 bg-amber-500 mx-auto rounded-full"></div>
            <p className="text-neutral-400 text-xs sm:text-sm max-w-xl mx-auto leading-relaxed italic">
              Empower muscle groups with structured physical challenges adjusted precisely to your experience levels.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
            {categories.map((cat, idx) => (
              <div 
                key={cat.id} 
                className="bg-neutral-950 border border-white/5 hover:border-amber-500/30 p-6 rounded-2xl shadow-xl transition-all duration-300 transform hover:-translate-y-1 group relative overflow-hidden"
              >
                <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-colors"></div>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] text-amber-500 font-bold font-mono uppercase bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    {cat.count}
                  </span>
                  <Award className="h-4.5 w-4.5 text-neutral-600 group-hover:text-amber-500 transition-colors" />
                </div>
                <h3 className="text-lg font-black text-white uppercase tracking-wide mb-2">{cat.label}</h3>
                <p className="text-xs text-neutral-400 leading-relaxed pr-2 min-h-[60px]">
                  {cat.desc}
                </p>
                <Link 
                  to={cat.path}
                  className="mt-6 font-bold text-[10px] text-amber-500 uppercase tracking-widest flex items-center gap-1 hover:underline group-hover:gap-2 transition-all"
                >
                  <span>Go to Track</span>
                  <ChevronRight className="h-3 w-3" />
                </Link>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* FEATURED WORKOUTS SECTION */}
      <section className="py-24 px-4 bg-neutral-950 border-t border-white/5">
        <div className="max-w-7xl mx-auto space-y-16">
          
          <div className="text-center space-y-4">
            <span className="text-amber-500 font-mono text-xs uppercase tracking-widest font-extrabold block">PROVEN LIFT BLUEPRINTS</span>
            <h2 className="font-display text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">FEATURED HUB WORKOUTS</h2>
            <div className="w-16 h-1 bg-amber-500 mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {featuredWorkouts.map((workout, idx) => (
              <div 
                key={idx} 
                className="bg-black border border-white/5 hover:border-amber-500/20 rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Card media container */}
                  <div className="h-48 relative overflow-hidden bg-neutral-900">
                    <img 
                      src={workout.img} 
                      alt={workout.title}
                      className="w-full h-full object-cover opacity-75 hover:scale-105 transition-transform duration-500" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
                    <span className="absolute top-4 left-4 bg-amber-500 text-black font-black text-[9px] uppercase px-2.5 py-1 rounded-sm">
                      {workout.category}
                    </span>
                  </div>

                  {/* Body elements */}
                  <div className="p-6 space-y-4">
                    <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400">
                      <span className="flex items-center gap-1"><Zap className="h-3 w-3 text-amber-500" /> {workout.duration}</span>
                      <span>{workout.difficulty}</span>
                      <span className="text-emerald-400 font-bold">{workout.xp}</span>
                    </div>

                    <h3 className="text-lg font-black text-white uppercase tracking-wide">{workout.title}</h3>
                    
                    {/* Exercises checklist sub-items */}
                    <div className="space-y-1.5 pt-2 border-t border-white/5">
                      <span className="text-[9px] font-mono uppercase text-neutral-500 font-bold block mb-1">EXERCISE BREAKDOWN:</span>
                      {workout.exercises.map((ex, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-neutral-400">
                          <Check className="h-3 w-3 text-amber-500 shrink-0" />
                          <span>{ex}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0 mt-4">
                  <Link 
                    to="/workouts" 
                    className="w-full inline-flex justify-center items-center bg-white/5 hover:bg-amber-500 hover:text-black py-3 rounded-xl border border-white/10 hover:border-amber-500 text-xs font-bold uppercase tracking-wider transition-all duration-300"
                  >
                    <span>Activate Workout Routine</span>
                  </Link>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* AI FITNESS COACH SECTION */}
      <section className="py-24 px-4 bg-gradient-to-br from-black via-neutral-950 to-amber-950/20 border-y border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-[130px]"></div>
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-full">
              <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
              <span className="text-[10px] text-emerald-400 font-bold font-mono uppercase tracking-widest">Active AI neural systems</span>
            </div>

            <h2 className="font-display text-3xl sm:text-5xl font-black text-white uppercase tracking-tight leading-tight">
              YOUR PERSONAL RECOMP POSITION<br className="hidden sm:inline" />
              <span className="text-amber-500 italic">24/7 AI FITNESS COACH</span>
            </h2>

            <p className="text-neutral-350 text-xs sm:text-sm leading-relaxed">
              Unlock Coach Alex Babatunde’s wisdom coupled with high-compute digital intelligence. Obtain immediate clarifications regarding muscle recovery coefficients, custom meals, caloric budgeting, and biometric trends.
            </p>

            <div className="space-y-3.5">
              {[
                { title: 'Interactive Conversational Response Engine', desc: 'Ask about bench pressing variations, traditional high protein foods, or training fatigue.' },
                { title: 'Mifflin-St Jeor Biometric Dashboard Integration', desc: 'Calculates active BMR and outputs exact complex macronutrient targets automatically.' },
                { title: 'Secure Server-Side Privacy Guardians', desc: 'Secure APIs guarantee all uploaded somatic parameter logs remain entirely private.' }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-[10.5px] mt-0.5 shrink-0">
                    ✓
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wide">{item.title}</h4>
                    <p className="text-xs text-neutral-450 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4">
              <Link 
                to="/ai-coach" 
                className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-amber-500 hover:text-amber-400"
              >
                <span>Consult Automated AI Coach</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <div className="lg:col-span-6 bg-neutral-950 border border-white/5 rounded-2xl p-6 shadow-2xl relative">
            <div className="border-b border-white/5 pb-4 mb-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-white/50 font-mono">Interactive AI Hub Sandbox</span>
              </div>
              <span className="text-[8px] uppercase tracking-wider text-amber-500 font-mono">v3.5-flash series</span>
            </div>

            {/* Simulating Chat interactive items */}
            <div className="space-y-4 text-xs">
              <div className="bg-black border border-white/5 p-3 rounded-xl text-left">
                <p className="text-[10px] font-mono text-neutral-500 uppercase font-black">Athlete Query:</p>
                <p className="text-neutral-200 mt-1">"I weigh 84kg, how much protein do I need to keep muscle during weight loss?"</p>
              </div>

              <div className="bg-amber-500/5 border border-amber-500/15 p-4 rounded-xl text-left relative">
                <Sparkles className="absolute top-4 right-4 h-4 w-4 text-amber-500 animate-spin-slow opacity-60" />
                <p className="text-[10px] font-mono text-amber-500 uppercase font-black">Digital Coach AI Response:</p>
                <p className="text-neutral-300 mt-1 leading-relaxed">
                  "Based on Coach Alex’s professional guidelines, lock your daily protein to <strong>2.2g per kg of target weight</strong>. For a target of 76kg, you must consume exactly <strong>167g of high-quality protein</strong> daily. Combine lean turkey/grilled croaker fish with amino acids splits to avoid muscular tissue decay during metabolic restrictions."
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/5 flex justify-center">
              <Link
                to="/ai-coach"
                className="text-xs bg-amber-500 hover:bg-amber-600 text-black px-6 py-3 rounded-full font-black uppercase tracking-wider transition-colors inline-block"
              >
                Launch Live Chat Channel
              </Link>
            </div>
          </div>

        </div>
      </section>

      {/* NUTRITION & MEAL PLANNING SECTION */}
      <section className="py-24 px-4 bg-black">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="p-8 bg-neutral-950 border border-white/5 rounded-2xl space-y-6 text-left relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 left-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl"></div>
            <div className="flex items-center space-x-2">
              <Apple className="h-5 w-5 text-amber-500" />
              <span className="text-xs text-amber-500 font-extrabold font-mono uppercase tracking-widest">NUTRITIONAL EDUCATION CORNER</span>
            </div>

            <h3 className="font-display text-2xl font-black text-white uppercase tracking-wide">HIGH PROTEIN & RAW FOOD CODES</h3>
            <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed pr-2">
              Review natural additives such as garlic and turmeric which regulate blood pressure and muscle oxygen distribution. Avoid processed industrial ingredients like saturated palm oils, refined high-fructose sugars, and excessive wheat flour.
            </p>

            <div className="space-y-3 pt-4 border-t border-white/5">
              <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-mono font-bold block">RECOMMENDED NIGERIAN & GLOBAL SOURCE CODES:</span>
              <div className="grid grid-cols-2 gap-3 text-xs">
                {['Moi Moi (Steamed beans)', 'Croaker or Salmon Fish', 'Chicken / Turkey Breast', 'Unsweetened Greek Yogurt', 'Boiled Yam / Plantain', 'Rolled Oats & Avocado'].map((food, i) => (
                  <div key={i} className="flex items-center gap-2 text-neutral-300">
                    <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
                    <span>{food}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2">
              <Link 
                to="/nutrition" 
                className="w-full inline-flex justify-center items-center py-3.5 bg-white/5 hover:bg-white/10 rounded-xl text-neutral-350 text-xs font-bold uppercase tracking-wider border border-white/10"
              >
                Explore Nutrition Hub
              </Link>
            </div>
          </div>

          <div className="space-y-6 text-left">
            <span className="text-amber-500 font-mono text-xs uppercase tracking-widest font-extrabold block">DIETARY ALGORITHMS</span>
            <h2 className="font-display text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">MACRONUTRIENT MEAL PLANNER</h2>
            <p className="text-neutral-350 text-xs sm:text-sm leading-relaxed">
              Say goodbye to complicated diets. Our interactive meal generation engine structures accurate high-protein meals utilizing traditional options and clean international foods adjusted to Mifflins caloric targets.
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-neutral-950 border border-white/5 rounded-xl">
                <h4 className="text-xl font-black text-white">40-30-30</h4>
                <p className="text-[10px] uppercase text-amber-500 font-mono leading-none tracking-widest font-bold mt-1">Aesthetic split</p>
                <p className="text-xs text-neutral-450 mt-2">Optimal balance for burning fat and preserving lean mass fibers.</p>
              </div>
              <div className="p-4 bg-neutral-950 border border-white/5 rounded-xl">
                <h4 className="text-xl font-black text-white">Traditional option</h4>
                <p className="text-[10px] uppercase text-amber-500 font-mono leading-none tracking-widest font-bold mt-1">Moi-Moi & Akara</p>
                <p className="text-xs text-neutral-450 mt-2">Clean grain proteins coupled with biological essential fats.</p>
              </div>
            </div>

            <div className="pt-2">
              <Link 
                to="/meal-plans" 
                className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-black px-6 py-3.5 rounded-full font-black text-xs uppercase tracking-widest transition-colors shadow-lg shadow-amber-500/10"
              >
                <span>Launch Meal Generator</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </Link>
            </div>
          </div>

        </div>
      </section>

      {/* PROGRESS TRACKING TEASER SECTION */}
      <section className="py-24 px-4 bg-gradient-to-tr from-neutral-950 via-black to-neutral-950/80 border-t border-white/5 relative overflow-hidden">
        {/* Floating gradient orb in background */}
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-amber-500/5 rounded-full blur-[120px] pointer-events-none"></div>
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Dashboard Analytics Mockup representing tracking metrics */}
          <div className="lg:col-span-6 relative order-last lg:order-first">
            <div className="bg-neutral-950 border border-white/10 rounded-2xl p-6 shadow-2xl relative space-y-6">
              {/* Fake dashboard header */}
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <h4 className="text-white font-bold text-sm uppercase tracking-wide">Athlete Performance Dashboard</h4>
                  <p className="text-[10px] text-neutral-500 font-mono uppercase tracking-widest mt-0.5">Somatic snapshots & metric logs</p>
                </div>
                <div className="bg-amber-500/10 border border-amber-500/30 text-amber-500 text-[10px] px-2.5 py-1 rounded font-mono font-bold uppercase">
                  92d Streak Live
                </div>
              </div>

              {/* Grid with parameters */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-black/50 border border-white/5 p-3 rounded-xl">
                  <span className="text-[9px] text-neutral-500 uppercase tracking-widest font-mono font-bold block">Current Mass</span>
                  <span className="text-lg font-black text-white block mt-1">79.2 kg</span>
                  <span className="text-[9px] text-emerald-400 font-mono font-bold block">▼ 4.8kg lost</span>
                </div>
                <div className="bg-black/50 border border-white/5 p-3 rounded-xl">
                  <span className="text-[9px] text-neutral-500 uppercase tracking-widest font-mono font-bold block">Tendon Index</span>
                  <span className="text-lg font-black text-white block mt-1">H-9.8</span>
                  <span className="text-[9px] text-amber-500 font-mono font-bold block">▲ Peak stability</span>
                </div>
                <div className="bg-black/50 border border-white/5 p-3 rounded-xl">
                  <span className="text-[9px] text-neutral-500 uppercase tracking-widest font-mono font-bold block">Fat Quotient</span>
                  <span className="text-lg font-black text-white block mt-1">11.4%</span>
                  <span className="text-[9px] text-emerald-400 font-mono font-bold block">▼ 3.2% lipid down</span>
                </div>
              </div>

              {/* Analytical Chart Mockup using clean SVG blocks in modern dark mode styling */}
              <div className="bg-black border border-white/5 rounded-xl p-4 space-y-4">
                <div className="flex justify-between items-center text-[10px] font-mono">
                  <span className="text-neutral-400 uppercase font-bold">12-Week Lipid & Hypertrophy Ratio Curve</span>
                  <span className="text-amber-500">Mifflin standard deviation</span>
                </div>
                {/* SVG curve */}
                <div className="h-32 w-full flex items-end justify-between pt-4 gap-1.5">
                  {[24, 38, 30, 48, 55, 45, 62, 70, 64, 82, 88, 95].map((val, i) => (
                    <div key={i} className="flex-grow flex flex-col items-center gap-1.5 h-full justify-end">
                      <div 
                        style={{ height: `${val}%` }}
                        className="w-full bg-gradient-to-t from-amber-500/40 to-amber-500 rounded-t-sm transition-all duration-500 hover:brightness-125"
                      ></div>
                      <span className="text-[8px] text-neutral-600 font-mono">W{i+1}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dynamic Achievements badge showcase */}
              <div className="flex gap-2 items-center justify-between pt-2">
                <span className="text-[9px] text-neutral-500 uppercase tracking-widest font-mono font-black">Unlocked Achievements:</span>
                <div className="flex gap-1.5">
                  {['🔥 90D', '💪 Symmetrical', '🥇 Iron Mind'].map((ach) => (
                    <span key={ach} className="bg-neutral-900 border border-white/5 text-[9px] text-neutral-300 font-bold px-2 py-1 rounded font-mono">
                      {ach}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Visual brackets decoration */}
            <div className="absolute -bottom-3 -right-3 w-16 h-16 border-b-2 border-r-2 border-amber-500/20 rounded-br-lg"></div>
          </div>

          {/* Text panel explaining tracker features */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <span className="text-amber-500 font-mono text-xs uppercase tracking-widest font-extrabold block">PRECISE KINETIC DIAGNOSTICS</span>
            <h2 className="font-bebas text-3xl sm:text-5xl font-black text-white uppercase tracking-tight leading-none">
              PROGRESS TRACKER &<br />
              <span className="text-amber-500 italic block mt-1">BIOMETRIC LOGS</span>
            </h2>
            <p className="text-neutral-350 text-xs sm:text-sm leading-relaxed">
              Achieving biological physical milestones requires continuous analytical confirmation, not guesswork. ALEXFITNESSHUB tracks somatic weight snapshots over time, monitors active training streaks, and unlocks status achievements to solidify behavioral habits.
            </p>
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-white uppercase tracking-wide">🏆 Achievement Badges</h4>
                <p className="text-[11px] text-neutral-500 leading-normal">Keep your dopamine levels synchronized with physical benchmarks.</p>
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-white uppercase tracking-wide">🔥 Daily Streaks Code</h4>
                <p className="text-[11px] text-neutral-500 leading-normal">Strict compliance monitoring for perfect habit-loop reinforcement.</p>
              </div>
            </div>
            <div className="pt-4">
              <Link 
                to="/dashboard" 
                className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-black px-6 py-3.5 rounded-full font-black text-xs uppercase tracking-widest transition-all shadow-lg shadow-amber-500/10"
              >
                <span>Launch Interactive Dashboard</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </Link>
            </div>
          </div>

        </div>
      </section>

      {/* TRANSFORMATION STORIES & TESTIMONIALS SECTION */}
      <section className="py-24 px-4 bg-neutral-950 border-t border-white/5">
        <div className="max-w-7xl mx-auto space-y-16 text-center">
          
          <div className="space-y-4">
            <span className="text-amber-500 font-mono text-xs uppercase tracking-widest font-extrabold block">BIOMETRIC EVIDENCE RECORD CHANNELS</span>
            <h2 className="font-display text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">TRANSFORMATION STORIES</h2>
            <p className="text-neutral-400 text-xs sm:text-sm max-w-xl mx-auto">
              Real athletes. Absolute somatic changes. We provide verified logs of weight reduction and muscle development.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
            {TESTIMONIALS.slice(0, 3).map((t) => (
              <div 
                key={t.id} 
                className="bg-black border border-white/5 rounded-2xl p-6 shadow-2xl flex flex-col justify-between relative overflow-hidden group hover:border-amber-500/20 transition-all duration-300"
              >
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <img 
                      src={t.image} 
                      alt={t.name}
                      className="w-14 h-14 object-cover rounded-xl border border-amber-500/20 shadow-md"
                    />
                    <div>
                      <h4 className="font-bold text-white text-sm uppercase tracking-wide">{t.name}</h4>
                      <p className="text-[10px] text-neutral-500 font-mono uppercase tracking-wider">{t.role}</p>
                    </div>
                  </div>

                  <div className="flex space-x-0.5">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />
                    ))}
                  </div>

                  <span className="text-xs text-amber-500 font-mono font-bold block uppercase tracking-wider">
                    🏆 Outcome: {t.result}
                  </span>

                  <p className="text-xs text-neutral-400 leading-relaxed pr-1 italic">
                    "{t.story}"
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/5 flex justify-between items-center text-[10px] text-neutral-500 font-mono">
                  <span>BEFORE: <strong className="text-rose-500">{t.beforeWeight}</strong></span>
                  <span>AFTER: <strong className="text-emerald-500">{t.afterWeight}</strong></span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* PRICING PLANS SECTION */}
      <section className="py-24 px-4 bg-black relative">
        <div className="max-w-7xl mx-auto space-y-16 text-center">
          
          <div className="space-y-4">
            <span className="text-amber-500 font-mono text-xs uppercase tracking-widest font-extrabold block">CHOOSE YOUR SUBSCRIPTION LEVEL</span>
            <h2 className="font-display text-3xl sm:text-5xl font-black text-white uppercase tracking-tight font-extrabold">PRICING PLANS</h2>
            <div className="w-16 h-1 bg-amber-500 mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left max-w-5xl mx-auto">
            
            {/* Free Tier */}
            <div className="bg-neutral-950 border border-white/5 rounded-2xl p-8 flex flex-col justify-between shadow-xl">
              <div className="space-y-6">
                <div>
                  <h3 className="text-md font-black uppercase text-neutral-500 font-mono tracking-wider">COMMUNITY FREE</h3>
                  <div className="flex items-baseline mt-2">
                    <span className="text-3xl font-black text-white">₦0</span>
                    <span className="text-neutral-500 text-xs uppercase font-mono ml-1">/ Forever</span>
                  </div>
                </div>
                <p className="text-xs text-neutral-450 pr-4">Access standard exercise breakdown checklists and simple calorie logger tools.</p>
                
                <ul className="space-y-3 text-xs text-neutral-350">
                  {['Standard Tracker log entry', 'Browse 15+ standard workouts', 'Access global raw foods index', 'Standard community email support'].map((item, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="text-neutral-500">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="pt-8">
                <Link 
                  to="/auth/signup" 
                  className="w-full inline-flex justify-center items-center py-3 rounded-full bg-white/5 hover:bg-white/10 text-white text-xs font-bold uppercase tracking-wider border border-white/10 transition-colors"
                >
                  Create Free Account
                </Link>
              </div>
            </div>

            {/* Pro tier */}
            <div className="bg-neutral-950 border-2 border-amber-500/80 rounded-2xl p-8 flex flex-col justify-between shadow-2xl relative">
              <span className="absolute -top-3.5 left-1/2 transform -translate-x-1/2 bg-amber-500 text-black text-[9px] font-black uppercase px-3 py-1 rounded-full font-mono tracking-widest shadow-md">
                MOST POPULAR ACTIVE
              </span>
              <div className="space-y-6">
                <div>
                  <h3 className="text-md font-black uppercase text-amber-500 font-mono tracking-wider">PRO TRANSFORMATION</h3>
                  <div className="flex items-baseline mt-2">
                    <span className="text-4xl font-extrabold text-white">₦15,000</span>
                    <span className="text-neutral-400 text-xs uppercase font-mono ml-1">/ Single pay</span>
                  </div>
                </div>
                <p className="text-xs text-neutral-350">Full analytical custom macros, metabolic profiles, and full exercises catalog unlock.</p>
                
                <ul className="space-y-3 text-xs text-neutral-200">
                  {['Everything in Community', 'Complete interactive workout tracks', 'Mifflins somatic BMR targets calculator', 'Analytical progress tracking charts', 'First tier support chats channel'].map((item, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="text-amber-500">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="pt-8">
                <Link 
                  to="/pricing" 
                  className="w-full inline-flex justify-center items-center py-3.5 rounded-full bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-wider transition-colors shadow-lg shadow-amber-500/10"
                >
                  Order Pro Transformation
                </Link>
              </div>
            </div>

            {/* Elite VIP Tier */}
            <div className="bg-neutral-950 border border-white/5 rounded-2xl p-8 flex flex-col justify-between shadow-xl">
              <div className="space-y-6">
                <div>
                  <h3 className="text-md font-black uppercase text-neutral-405 font-mono tracking-wider">ELITE COACH VIP</h3>
                  <div className="flex items-baseline mt-2">
                    <span className="text-3xl font-black text-white">₦40,000</span>
                    <span className="text-neutral-500 text-xs uppercase font-mono ml-1">/ Month</span>
                  </div>
                </div>
                <p className="text-xs text-neutral-450">Elite physical coach connection. AI Coach responses prioritized high-compute slots.</p>
                
                <ul className="space-y-3 text-xs text-neutral-350">
                  {['Everything in Pro Transformation', 'Deep neural coach consultation levels', 'Unrestricted support chat prioritize routing', 'Direct feedback invoice receipts', 'Personalized calorie model setups'].map((item, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="text-amber-500">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="pt-8">
                <Link 
                  to="/pricing" 
                  className="w-full inline-flex justify-center items-center py-3 rounded-full bg-white/5 hover:bg-white/10 text-white text-xs font-bold uppercase tracking-wider border border-white/10 transition-colors"
                >
                  Apply Coach VIP
                </Link>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* FREQUENTLY ASKED QUESTIONS (FAQ) SECTION */}
      <section className="py-24 px-4 bg-neutral-950 border-t border-white/5">
        <div className="max-w-4xl mx-auto space-y-16">
          
          <div className="text-center space-y-4">
            <span className="text-amber-500 font-mono text-xs uppercase tracking-widest font-extrabold block">CLEAR THE FOG OF HEALTH</span>
            <h2 className="font-display text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">FREQUENTLY ASKED QUESTIONS</h2>
            <div className="w-16 h-1 bg-amber-500 mx-auto rounded-full"></div>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => {
              const isOpen = activeFaq === index;
              return (
                <div 
                  key={index}
                  className="bg-black border border-white/5 rounded-2xl overflow-hidden transition-all duration-300"
                >
                  <button
                    onClick={() => handleToggleFaq(index)}
                    className="w-full p-6 text-left flex justify-between items-center text-white hover:text-amber-500 gap-4 transition-colors focus:outline-none cursor-pointer"
                  >
                    <span className="text-xs sm:text-sm font-bold uppercase tracking-wide flex items-center gap-2.5">
                      <HelpCircle className="h-4 w-4 text-neutral-500 shrink-0" />
                      {faq.q}
                    </span>
                    <span className="text-amber-500 text-lg font-black shrink-0 transition-transform duration-300 transform">
                      {isOpen ? '−' : '+'}
                    </span>
                  </button>
                  
                  {isOpen && (
                    <div className="px-6 pb-6 text-xs text-neutral-400 border-t border-white/5 pt-4 leading-relaxed italic animate-fade-in text-left">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* FINAL HIGH-IMPACT CALL TO ACTION SECTION */}
      <section className="relative py-28 px-4 bg-black overflow-hidden border-t border-white/5">
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
        {/* Absolute floating blurred gradients for luxury modern app feel */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-amber-500/10 blur-[130px] pointer-events-none"></div>
        <div className="relative max-w-4xl mx-auto text-center space-y-8 z-10">
          <div className="inline-flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/20 px-4 py-1.5 rounded-full select-none">
            <Flame className="h-4 w-4 text-amber-500 animate-pulse" />
            <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono uppercase">IMPERIAL ATHLETIC ALLIANCE</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-7xl md:text-8xl font-black text-white leading-none tracking-wide text-center uppercase">
            ARE YOU READY TO<br />
            <span className="text-amber-500 italic">AWAKEN THE STEEL?</span>
          </h2>
          <p className="text-neutral-400 text-xs sm:text-sm max-w-xl mx-auto leading-relaxed">
            Stop simulating, start executing. Secure your customized weight tracking plans, unguided whole food matrices, and real-time Gemini coaching insights today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <Link
              to="/auth/signup"
              className="px-10 py-5 bg-amber-500 hover:bg-amber-600 text-black text-xs font-black uppercase tracking-widest rounded-full transition-all duration-300 transform hover:-translate-y-1 hover:scale-102 hover:shadow-xl hover:shadow-amber-500/20 shadow-lg font-mono flex items-center gap-2"
            >
              <span>Secure Ultimate Access</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/pricing"
              className="px-10 py-5 border border-white/20 hover:border-amber-500 bg-white/5 hover:bg-white/10 text-white text-xs font-extrabold uppercase tracking-widest rounded-full transition-all duration-300 transform hover:-translate-y-1 backdrop-blur-sm"
            >
              Examine Membership Levels
            </Link>
          </div>
          <p className="text-[10px] text-neutral-650 uppercase tracking-widest font-mono pt-4">
            JOIN 15,240+ REGISTERED ATHLETES OPERATING IN METABOLIC EFFICIENCY
          </p>
        </div>
      </section>

    </div>
  );
}
