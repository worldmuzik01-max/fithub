import React, { useState, useEffect } from 'react';
import { Trophy, Users, Shield, TrendingUp, CheckCircle, RefreshCw, Lock, MessageSquare, Send, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

interface AdminStats {
  totalUsers: number;
  premiumUsers: number;
  totalIncome: number;
}

export default function Admin() {
  const { user: authUser, loading: authLoading } = useAuth();
  const [stats, setStats] = useState<AdminStats>({ totalUsers: 204218, premiumUsers: 48941, totalIncome: 1223525000 });
  const [isLoading, setIsLoading] = useState(false);
  const [memberList, setMemberList] = useState([
    { name: 'Emeka Nwosu', email: 'emeka@example.com', status: 'premium', plan: 'yearly', registered: '2026-05-24' },
    { name: 'Oluwaseun Adewale', email: 'seun@example.com', status: 'premium', plan: 'monthly', registered: '2026-05-28' },
    { name: 'Fatima Yaradua', email: 'fatima@example.com', status: 'free', plan: 'none', registered: '2026-05-30' },
    { name: 'Chukwuma Obi', email: 'obi@example.com', status: 'premium', plan: 'yearly', registered: '2026-05-31' },
    { name: 'Sarah Jenkins', email: 'sarah@example.com', status: 'free', plan: 'none', registered: '2026-05-31' }
  ]);

  // Support Chat states
  const [supportSessions, setSupportSessions] = useState<any[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [activeChats, setActiveChats] = useState<any[]>([]);
  const [adminReplyText, setAdminReplyText] = useState<string>('');
  const [sendingReply, setSendingReply] = useState<boolean>(false);

  const handleRefreshStats = async () => {
    setIsLoading(true);
    try {
      const data = await apiFetch<any>('/api/admin/stats');
      if (data && data.totalUsers) {
        setStats({
          totalUsers: data.totalUsers,
          premiumUsers: data.premiumUsers,
          totalIncome: data.totalIncome
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSessions = async () => {
    try {
      const data = await apiFetch<any[]>('/api/support/admin/sessions');
      if (data) {
        setSupportSessions(data);
      }
    } catch (err) {
      console.error("Error fetching support sessions:", err);
    }
  };

  const fetchActiveChats = async (sessionId: string, quiet = false) => {
    if (!sessionId) return;
    try {
      const data = await apiFetch<any[]>(`/api/support/chats?chatSessionId=${sessionId}&role=admin`);
      if (data) {
        setActiveChats(data);
      }
    } catch (err) {
      console.error("Error fetching active chats:", err);
    }
  };

  const handleSendAdminReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSessionId || !adminReplyText.trim()) return;
    setSendingReply(true);
    const textToSend = adminReplyText;
    setAdminReplyText('');
    try {
      await apiFetch<any>('/api/support/admin/reply', {
        method: 'POST',
        body: JSON.stringify({
          chatSessionId: selectedSessionId,
          message: textToSend
        })
      });
      fetchActiveChats(selectedSessionId, true);
      fetchSessions();
    } catch (err) {
      console.error("Error sending admin reply:", err);
    } finally {
      setSendingReply(false);
    }
  };

  useEffect(() => {
    handleRefreshStats();
    fetchSessions();

    const sessInterval = setInterval(() => {
      fetchSessions();
    }, 5000);

    return () => clearInterval(sessInterval);
  }, []);

  useEffect(() => {
    if (selectedSessionId) {
      fetchActiveChats(selectedSessionId);
      const chatInterval = setInterval(() => {
        fetchActiveChats(selectedSessionId, true);
      }, 3000);
      return () => {
        clearInterval(chatInterval);
      };
    } else {
      setActiveChats([]);
    }
  }, [selectedSessionId]);

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  const isAdmin = authUser?.email === 'muzikworld08@gmail.com' || authUser?.role === 'admin';
  if (!isAdmin) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
        <div className="bg-neutral-950 border border-rose-950/40 rounded-sm p-8 max-w-md w-full text-center space-y-6 shadow-2xl relative">
          <div className="w-16 h-16 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded-full flex items-center justify-center mx-auto">
             <Lock className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-bebas text-3xl font-extrabold tracking-wider text-rose-500">ACCESS RESTRICTED</h2>
            <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">Lead Coach Access Code Required</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans">
            Your current account session is not authorized to edit master financial stats or system preset schemas.
          </p>
          <div className="pt-2">
            <Link
              to="/"
              className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm block font-mono"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-1.5 bg-rose-500/10 border border-rose-500/20 px-3 py-1 rounded text-rose-500 text-xs font-bold uppercase mb-2">
            <Shield className="h-3.5 w-3.5" />
            <span>Coaching Lead Access Terminal</span>
          </div>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            ADMIN SYSTEM <span className="text-amber-500">DASHBOARD</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Monitor real-time system metrics, registered athlete indices, and cumulative West African Naira subscription volumes initiated through the Monnify gateway.
          </p>
        </div>

        {/* Master KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12 text-center">
          <div className="bg-neutral-950 border border-neutral-900 p-6 rounded relative overflow-hidden">
            <div className="absolute top-2 right-4 text-emerald-500"><Users className="h-8 w-8 opacity-10" /></div>
            <span className="text-[10px] text-neutral-550 uppercase font-bold block mb-1">TOTAL ATHLETE ACCOUNTS</span>
            <span className="font-bebas text-3xl sm:text-4xl font-black text-white">{stats.totalUsers.toLocaleString()}</span>
            <span className="text-[9px] text-neutral-500 uppercase block mt-1">Growth rate 1.4% weekly</span>
          </div>

          <div className="bg-neutral-950 border border-neutral-900 p-6 rounded relative overflow-hidden">
            <div className="absolute top-2 right-4 text-amber-500"><Trophy className="h-8 w-8 opacity-10" /></div>
            <span className="text-[10px] text-neutral-550 uppercase font-bold block mb-1">ELITE TIER SUBSCRIBERS</span>
            <span className="font-bebas text-3xl sm:text-4xl font-black text-amber-500">{stats.premiumUsers.toLocaleString()}</span>
            <span className="text-[9px] text-neutral-500 uppercase block mt-1">Converted via Monnify SDK</span>
          </div>

          <div className="bg-neutral-950 border border-neutral-900 p-6 rounded relative overflow-hidden">
            <div className="absolute top-2 right-4 text-emerald-500"><TrendingUp className="h-8 w-8 opacity-10" /></div>
            <span className="text-[10px] text-neutral-550 uppercase font-bold block mb-1">TOTAL SALES REVENUES</span>
            <span className="font-bebas text-3xl sm:text-4xl font-black text-white">₦{stats.totalIncome.toLocaleString()}</span>
            <span className="text-[9px] text-neutral-500 uppercase block mt-1">Audited gross revenue</span>
          </div>
        </div>

        {/* Actions panel */}
        <div className="mb-8 text-right">
          <button
            onClick={handleRefreshStats}
            disabled={isLoading}
            className="inline-flex items-center space-x-1.5 bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-[10px] text-white font-bold uppercase tracking-widest px-4 py-3 rounded"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>{isLoading ? 'Re-auditing database...' : 'Refresh Records'}</span>
          </button>
        </div>

        {/* Live Support Desk Panel */}
        <div className="bg-neutral-950 border border-amber-500/10 rounded-lg overflow-hidden text-left mb-12">
          <div className="p-5 border-b border-neutral-900 flex justify-between items-center bg-amber-500/5">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
              <h3 className="font-bebas text-xl font-bold tracking-wider text-white uppercase">LIVE COACHING SUPPORT CENTER</h3>
            </div>
            <span className="text-[9px] uppercase font-bold font-mono text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded">
              {supportSessions.length} Active Sessions
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 min-h-[350px] divide-y md:divide-y-0 md:divide-x divide-neutral-900">
            {/* Sidebar with Sessions */}
            <div className="md:col-span-1 max-h-[400px] overflow-y-auto divide-y divide-neutral-900 scrollbar-thin scrollbar-thumb-neutral-900 scrollbar-track-transparent">
              {supportSessions.length === 0 ? (
                <div className="p-8 text-center text-neutral-550 text-xs">
                  No active support messages received yet.
                </div>
              ) : (
                supportSessions.map((sess) => {
                  const isActive = selectedSessionId === sess.chatSessionId;
                  return (
                    <button
                      key={sess.chatSessionId}
                      onClick={() => setSelectedSessionId(sess.chatSessionId)}
                      className={`w-full p-4 text-left block text-xs transition-colors relative ${
                        isActive ? 'bg-amber-500/10' : 'hover:bg-neutral-900/40'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-black text-white uppercase tracking-wide truncate max-w-[70%]">
                          {sess.senderName || 'Anonymous Athlete'}
                        </span>
                        {sess.unreadCount > 0 && (
                          <span className="bg-amber-500 text-black px-1.5 py-0.5 rounded-full text-[9px] font-black animate-pulse">
                            {sess.unreadCount} NEW
                          </span>
                        )}
                      </div>
                      {sess.senderEmail && (
                        <div className="text-[10px] text-neutral-400 font-mono mb-1 truncate">
                          {sess.senderEmail}
                        </div>
                      )}
                      <div className="text-[11px] text-neutral-500 truncate italic">
                        "{sess.lastMessage || 'Empty message'}"
                      </div>
                      <div className="text-[9px] text-neutral-600 font-mono mt-1 text-right">
                        {new Date(sess.lastTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </button>
                  );
                })
              )}
            </div>

            {/* Chat Box */}
            <div className="md:col-span-2 flex flex-col max-h-[400px] h-full bg-black/50">
              {selectedSessionId ? (
                <>
                  {/* Messages list */}
                  <div className="flex-1 p-4 space-y-3 overflow-y-auto max-h-[320px] scrollbar-thin scrollbar-thumb-neutral-900 scrollbar-track-transparent">
                    {activeChats.map((chat) => {
                      const isAdminMsg = chat.senderRole === 'admin';
                      return (
                        <div key={chat.id} className={`flex flex-col ${isAdminMsg ? 'items-end' : 'items-start'}`}>
                          <div className="text-[9px] uppercase font-extrabold text-neutral-500 mb-1 font-mono">
                            {isAdminMsg ? 'You (Coach)' : chat.senderName} • {new Date(chat.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                          <div className={`p-3 rounded-md text-xs leading-relaxed max-w-[85%] break-words ${
                            isAdminMsg
                              ? 'bg-amber-500 text-black font-semibold rounded-tr-none'
                              : 'bg-neutral-900 border border-neutral-850 text-white rounded-tl-none'
                          }`}>
                            {chat.message}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Send Reply Input */}
                  <form onSubmit={handleSendAdminReply} className="p-3 border-t border-neutral-900 bg-neutral-950 flex gap-2">
                    <input
                      type="text"
                      className="flex-1 bg-black text-xs text-white border border-neutral-850 rounded p-2.5 outline-none focus:border-amber-500 transition-colors"
                      placeholder={`Reply to client...`}
                      value={adminReplyText}
                      onChange={(e) => setAdminReplyText(e.target.value)}
                      disabled={sendingReply}
                    />
                    <button
                      type="submit"
                      disabled={sendingReply || !adminReplyText.trim()}
                      className="bg-amber-500 hover:bg-amber-600 text-black font-bold uppercase tracking-wider text-[10px] px-4 rounded text-center flex items-center gap-1.5 transition-colors disabled:opacity-50"
                    >
                      {sendingReply ? (
                        <span className="w-3.5 h-3.5 border-2 border-black/30 border-t-black rounded-full animate-spin"></span>
                      ) : (
                        <Send className="w-3 h-3" />
                      )}
                      <span>REPLY</span>
                    </button>
                  </form>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-neutral-500 space-y-2">
                  <MessageSquare className="h-8 w-8 text-neutral-700 animate-pulse" />
                  <span className="text-xs uppercase font-mono tracking-wider">No conversation selected</span>
                  <p className="text-[11px] text-neutral-600 max-w-[280px]">
                    Select an athlete from the left panel to begin a support chat or review past communication threads.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Member list list-table */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-lg overflow-hidden text-left mb-12">
          <div className="p-5 border-b border-neutral-900 flex justify-between items-center bg-neutral-900/10">
            <h3 className="font-bebas text-xl font-bold tracking-wider text-white uppercase">MEMBER REGISTRATION AUDITS</h3>
            <span className="text-[9px] uppercase font-bold font-mono text-neutral-500">5 displayed | 100% real-time</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-neutral-900 bg-neutral-950/50 text-[10px] uppercase text-neutral-500 font-bold tracking-wider">
                  <th className="p-4">Name</th>
                  <th className="p-4">Email</th>
                  <th className="p-4">Registration Date</th>
                  <th className="p-4">Billing Status</th>
                  <th className="p-4">Active Plan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-900 text-neutral-300">
                {memberList.map((m, i) => (
                  <tr key={i} className="hover:bg-neutral-900/10 transition-colors">
                    <td className="p-4 font-bold uppercase text-white">{m.name}</td>
                    <td className="p-4 font-mono text-neutral-400">{m.email}</td>
                    <td className="p-4 text-neutral-500">{m.registered}</td>
                    <td className="p-4">
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        m.status === 'premium' ? 'bg-amber-500/20 text-amber-500' : 'bg-neutral-900 text-neutral-500'
                      }`}>
                        {m.status}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-white uppercase">{m.plan}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* System parameters section */}
        <div className="border border-neutral-900 bg-neutral-950 rounded-lg p-6 max-w-4xl mx-auto text-left">
          <h4 className="font-bebas text-lg font-bold text-amber-500 tracking-wider mb-3 uppercase">GLOBAL SYSTEM PRESETS</h4>
          <p className="text-neutral-550 text-xs mb-4 leading-relaxed font-light">
            Core settings regarding the ALEXFITNESSHUB physical training engine. The configurations here calibrate the Google Gemini AI response priorities.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-3 bg-black border border-neutral-900 rounded font-bold text-neutral-400 flex justify-between items-center">
              <span>CORE MODEL:</span>
              <span className="text-emerald-500 uppercase">gemini-3.5-flash</span>
            </div>
            <div className="p-3 bg-black border border-neutral-900 rounded font-bold text-neutral-400 flex justify-between items-center">
              <span>SANDBOX DEPLOYMENT:</span>
              <span className="text-emerald-500 uppercase">Express / tsx sandbox</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
