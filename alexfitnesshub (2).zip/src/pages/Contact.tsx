import React, { useState } from 'react';
import { Mail, Phone, MapPin, CheckCircle, Send, Sparkles } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', query: '' });
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.query) return;
    
    setIsSuccess(true);
    setFormData({ name: '', email: '', query: '' });
    setTimeout(() => setIsSuccess(false), 5000);
  };

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">SUPPORT STENCIL</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            GET IN <span className="text-amber-500">CONTACT</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Need customized plan queries or account setup support? Drop our head coaches a message and we'll reply under 4 hours.
          </p>
        </div>

        {/* Form and Contact Info Splits */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 max-w-5xl mx-auto">
          
          <div className="lg:col-span-4 p-8 bg-neutral-950 border border-neutral-900 rounded space-y-8 text-left">
            <div>
              <h3 className="font-bebas text-xl font-bold tracking-wider text-white uppercase mb-4">HEADQUARTERS</h3>
              <div className="space-y-4 text-xs text-neutral-400">
                <div className="flex space-x-3 items-center">
                  <MapPin className="h-5 w-5 text-amber-500" />
                  <span>Suite 45, owerri imo state, imo, Nigeria.</span>
                </div>
                <div className="flex space-x-3 items-center">
                  <Phone className="h-5 w-5 text-amber-500" />
                  <span>+234 7073307875</span>
                </div>
                <div className="flex space-x-3 items-center">
                  <Mail className="h-5 w-5 text-amber-500" />
                  <span>helloalexfitnessclub@gmail.com</span>
                </div>
              </div>
            </div>

            <div className="border-t border-neutral-900 pt-6">
              <h3 className="font-bebas text-xl font-bold tracking-wider text-white uppercase mb-2 text-amber-500">OFFICIAL CHANNELS</h3>
              <p className="text-xs text-neutral-500 leading-relaxed font-light">
                Our support desk is active 247.
              </p>
            </div>
          </div>

          <div className="lg:col-span-8 p-8 bg-neutral-950 border border-neutral-900 rounded text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-28 h-28 bg-amber-500/5 rounded-full blur-2xl"></div>
            
            <h3 className="font-bebas text-2xl font-bold tracking-wider text-white uppercase mb-6 flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-amber-500" />
              <span>DIRECT INQUIRY</span>
            </h3>

            {isSuccess ? (
              <div className="border border-emerald-500/30 bg-emerald-500/5 p-8 rounded text-center space-y-3">
                <CheckCircle className="h-8 w-8 text-emerald-500 mx-auto" />
                <h4 className="font-bold text-white uppercase text-sm">Inquiry Dispatched Successfully!</h4>
                <p className="text-xs text-neutral-405 leading-relaxed">
                  Thank you. Coach Alex or our tactical helper support lead will reach out to your inbox shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <label className="text-xs uppercase text-neutral-400 font-bold">Your Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Obi"
                      className="bg-black border border-neutral-900 rounded p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none hover:border-neutral-800"
                    />
                  </div>
                  <div className="flex flex-col space-y-1.5">
                    <label className="text-xs uppercase text-neutral-400 font-bold">Your Email Address</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. obi@example.com"
                      className="bg-black border border-neutral-900 rounded p-3 text-xs font-semibold text-white focus:border-amber-500 outline-none hover:border-neutral-800"
                    />
                  </div>
                </div>

                <div className="flex flex-col space-y-1.5">
                  <label className="text-xs uppercase text-neutral-400 font-bold">Inquiry Specifications</label>
                  <textarea
                    rows={4}
                    required
                    value={formData.query}
                    onChange={(e) => setFormData({ ...formData, query: e.target.value })}
                    placeholder="Provide details of your custom workout requirements or queries concerning Monnify subscriptions..."
                    className="bg-black border border-neutral-900 rounded p-3.5 text-xs font-semibold text-white focus:border-amber-500 outline-none hover:border-neutral-800"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded flex items-center justify-center space-x-2"
                  >
                    <Send className="h-4.5 w-4.5" />
                    <span>Send Message</span>
                  </button>
                </div>
              </form>
            )}

          </div>

        </div>

      </div>
    </div>
  );
}
