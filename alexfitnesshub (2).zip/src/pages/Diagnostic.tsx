import React, { useState, useEffect } from 'react';
import { doc, getDocFromServer } from 'firebase/firestore';
import { sendPasswordResetEmail, sendEmailVerification } from 'firebase/auth';
import { db, auth } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { translateFirebaseAuthError } from '../lib/authErrors';
import { ShieldCheck, ShieldAlert, Activity, RefreshCw, Globe, CheckCircle2, AlertTriangle, Cpu, Terminal } from 'lucide-react';

export default function Diagnostic() {
  const { user, loginWithGoogleRedirect, loginWithGoogle } = useAuth();
  
  // States
  const [dbStatus, setDbStatus] = useState<'testing' | 'online' | 'unauthorized_but_connected' | 'error'>('testing');
  const [dbError, setDbError] = useState<string | null>(null);
  const [apiStatus, setApiStatus] = useState<'testing' | 'online' | 'error'>('testing');
  const [apiMsg, setApiMsg] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Read config values dynamically
  const metaEnv = (import.meta as any).env || {};
  const configSource = {
    apiKey: metaEnv.VITE_FIREBASE_API_KEY ? 'VITE Env Variable' : 'Fallback JSON Config',
    projectId: metaEnv.VITE_FIREBASE_PROJECT_ID ? 'VITE Env Variable' : 'Fallback JSON Config',
    authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN ? 'VITE Env Variable' : 'Fallback JSON Config'
  };

  // Mask sensitive values
  const maskString = (str?: string) => {
    if (!str) return 'Not Defined';
    if (str.length <= 8) return '********';
    return `${str.substring(0, 6)}...${str.substring(str.length - 4)}`;
  };

  useEffect(() => {
    // 1. Diagnose Firestore connectivity
    const testFirestore = async () => {
      setDbStatus('testing');
      setDbError(null);
      try {
        // According to Firestore SKILL guidelines, verify connection via getFromServer
        const testDocRef = doc(db, '_connection_test_collection', 'trigger');
        await getDocFromServer(testDocRef);
        setDbStatus('online');
      } catch (err: any) {
        console.warn("[DIAGNOSTIC] Firestore read check caught error:", err);
        // Note: A "permission-denied" is actually an EXCELLENT sign because it proves 
        // the client successfully communicated with the live Firebase cluster and received a security evaluation!
        if (err.code === 'permission-denied') {
          setDbStatus('unauthorized_but_connected');
        } else {
          setDbStatus('error');
          setDbError(err.message || String(err));
        }
      }
    };

    // 2. Diagnose Backend Express connection
    const testBackend = async () => {
      setApiStatus('testing');
      setApiMsg(null);
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          const data = await res.json();
          setApiStatus('online');
          setApiMsg(JSON.stringify(data));
        } else {
          setApiStatus('error');
          setApiMsg(`Server returned status code: ${res.status}`);
        }
      } catch (err: any) {
        setApiStatus('error');
        setApiMsg(err.message || String(err));
      }
    };

    testFirestore();
    testBackend();
  }, [refreshTrigger]);

  // Handler for custom actions
  const triggerPasswordResetTest = async () => {
    if (!auth.currentUser?.email) {
      setActionError("Please sign up or sign in to trigger a live password recovery test.");
      return;
    }
    setActionLoading('pwd_reset');
    setActionSuccess(null);
    setActionError(null);
    try {
      await sendPasswordResetEmail(auth, auth.currentUser.email);
      setActionSuccess(`🔒 Premium recovery dispatch dispatched successfully to master email: ${auth.currentUser.email}`);
    } catch (err: any) {
      setActionError(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setActionLoading(null);
    }
  };

  const triggerVerificationTest = async () => {
    if (!auth.currentUser) {
      setActionError("An authenticated user session is required to test email verification dispatch.");
      return;
    }
    setActionLoading('verify_email');
    setActionSuccess(null);
    setActionError(null);
    try {
      const email = auth.currentUser.email || '';
      const actionCodeSettings = {
        url: `${window.location.origin}/verify-email?email=${encodeURIComponent(email)}`,
        handleCodeInApp: true,
      };
      await sendEmailVerification(auth.currentUser, actionCodeSettings);
      setActionSuccess(`📬 Security verification link dispatched successfully to ${auth.currentUser.email}`);
    } catch (err: any) {
      setActionError(translateFirebaseAuthError(err.code || 'unknown', err.message));
    } finally {
      setActionLoading(null);
    }
  };

  // Inspect deployment domain
  const currentHostname = window.location.hostname;
  const isLocalhost = currentHostname === 'localhost' || currentHostname === '127.0.0.1' || currentHostname.includes('192.168.');
  
  // Provide advice for deployment environment
  const authDomainValue = auth.app?.options?.authDomain || '';
  const domainResolutionCheck = authDomainValue.includes(currentHostname) || isLocalhost;

  return (
    <div className="bg-black text-white min-h-screen pt-28 pb-16 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Page Header */}
        <div className="border-b border-neutral-900 pb-5">
          <span className="text-[10px] text-amber-500 font-extrabold tracking-widest font-mono uppercase block mb-1">
            ALEXFIT MASTER CONSOLE
          </span>
          <h1 className="font-bebas text-4xl sm:text-5xl font-black text-white tracking-wider flex items-center gap-3">
            <Activity className="h-8 w-8 text-amber-500 animate-pulse" />
            FIREBASE & AUTH DIAGNOSTICS
          </h1>
          <p className="text-xs text-neutral-500 uppercase tracking-widest leading-relaxed">
            Real-time deployment audit engine, automated connectivity audits, and configuration tests.
          </p>
        </div>

        {/* Global Errors and Success feedback */}
        {actionSuccess && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 p-4 rounded-sm text-xs flex items-start gap-2.5 leading-5 shadow-lg">
            <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
            <span>{actionSuccess}</span>
          </div>
        )}
        {actionError && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-400 p-4 rounded-sm text-xs flex items-start gap-2.5 leading-5 shadow-lg">
            <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
            <span>{actionError}</span>
          </div>
        )}

        {/* Audit Status Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Firestore Connection Diagnostic */}
          <div className="bg-neutral-950 border border-neutral-900 p-6 rounded-sm relative overflow-hidden">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-mono text-xs uppercase text-neutral-400 tracking-wider font-bold">Firestore Connection</h3>
                <span className="text-[10px] text-neutral-500 font-mono">Live DB reachability</span>
              </div>
              {dbStatus === 'testing' && <RefreshCw className="h-5 w-5 text-amber-500 animate-spin" />}
              {dbStatus === 'online' && <span className="px-2.5 py-1 text-[9px] bg-emerald-500/15 text-emerald-400 font-bold uppercase rounded font-mono">ONLINE & READABLE</span>}
              {dbStatus === 'unauthorized_but_connected' && <span className="px-2.5 py-1 text-[9px] bg-amber-500/15 text-amber-400 font-bold uppercase rounded font-mono">REACHED & EVALUATED</span>}
              {dbStatus === 'error' && <span className="px-2.5 py-1 text-[9px] bg-rose-500/15 text-rose-400 font-bold uppercase rounded font-mono">CONNECTION FAIL</span>}
            </div>
            
            <p className="text-xs text-neutral-400 leading-relaxed font-light mb-4">
              {dbStatus === 'testing' && "Sending test frames to Google Cloud Firestore databases..."}
              {dbStatus === 'online' && "Database read successful! Client completed handshake and received valid values."}
              {dbStatus === 'unauthorized_but_connected' && "Handshake verified! Client connected successfully. Writes/Reads are blocked purely by secure security rules, proving live connection."}
              {dbStatus === 'error' && ` handshaking failed with the database. Error: ${dbError}`}
            </p>

            <div className="text-[11px] font-mono text-neutral-500 bg-black p-3 rounded border border-neutral-905">
              <span className="text-amber-500 font-bold text-[9px] tracking-widest uppercase block mb-1">AUDIT SUMMARY:</span>
              {(dbStatus === 'online' || dbStatus === 'unauthorized_but_connected') ? (
                <div className="text-emerald-400">✓ Firebase SDK correctly initialized. Project ID: {auth.app?.options?.projectId}</div>
              ) : (
                <div className="text-rose-400">✗ Connection could not be established. Check API key and internet availability.</div>
              )}
            </div>
          </div>

          {/* Hosting Domain Authorization */}
          <div className="bg-neutral-950 border border-neutral-900 p-6 rounded-sm relative overflow-hidden">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-mono text-xs uppercase text-neutral-400 tracking-wider font-bold">Authorized Domains</h3>
                <span className="text-[10px] text-neutral-500 font-mono">Firebase OAuth limits</span>
              </div>
              {domainResolutionCheck ? (
                <span className="px-2.5 py-1 text-[9px] bg-emerald-500/15 text-emerald-400 font-bold uppercase rounded font-mono">✓ DOMAIN VALID</span>
              ) : (
                <span className="px-2.5 py-1 text-[9px] bg-amber-500/15 text-amber-400 font-bold uppercase rounded font-mono">⚠️ DOMAIN OUT-OF-SYNC</span>
              )}
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed font-light mb-4">
              Current Active Domain: <strong className="text-white text-xs">{currentHostname}</strong>.
              {isLocalhost ? (
                " localhost is automatically authorized by Default inside Firebase Authentication."
              ) : domainResolutionCheck ? (
                " This domain appears properly integrated with your Firebase configuration authDomain address."
              ) : (
                " Warning: This deployed domain is not registered in Firebase. Sign-in popups or OAuth calls WILL fail."
              )}
            </p>

            {!domainResolutionCheck && (
              <div className="text-[11px] text-amber-400 bg-amber-500/5 p-3 rounded border border-amber-500/20 space-y-1">
                <div className="font-bold uppercase tracking-widest font-mono text-[9px]">🔧 RESOLUTION ACTION REQUIRED:</div>
                <div>1. Copy this domain: <strong>{currentHostname}</strong></div>
                <div>2. Open Google Firebase Console &gt; Authentication &gt; Settings &gt; Authorized Domains.</div>
                <div>3. Click "Add Domain" and paste the copied address there.</div>
              </div>
            )}
            {domainResolutionCheck && (
              <p className="text-[11px] text-emerald-400 leading-relaxed font-light">
                ✓ No domain authorization errors detected! Perfect alignment for popup-based authentication.
              </p>
            )}
          </div>

        </div>

        {/* Environment Variable Audit */}
        <div className="bg-neutral-950 border border-neutral-900 p-6 rounded-sm">
          <div className="flex items-center gap-2 mb-4">
            <Cpu className="h-5 w-5 text-amber-500" />
            <h3 className="font-mono text-xs uppercase text-neutral-400 tracking-wider font-bold">Vite & Production Environment Variables</h3>
          </div>
          
          <p className="text-xs text-neutral-400 leading-relaxed font-light mb-4">
            Below is the analysis of configuration values loaded from client environment processes. For secure production/Cloud Run/Render deployments, ensure they are specified in the administration dashboard as environment keys.
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-[11px] leading-6 border-collapse">
              <thead>
                <tr className="border-b border-neutral-900 text-neutral-500 uppercase text-[10px] tracking-widest">
                  <th className="pb-2">CONFIG FIELD</th>
                  <th className="pb-2">RESOLVED SOURCE</th>
                  <th className="pb-2">MASKED RESOLVED VALUE</th>
                  <th className="pb-2 text-right">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-905">
                <tr>
                  <td className="py-2 text-neutral-350 font-bold">VITE_FIREBASE_API_KEY</td>
                  <td>{configSource.apiKey}</td>
                  <td>{maskString(metaEnv.VITE_FIREBASE_API_KEY || auth.app?.options?.apiKey)}</td>
                  <td className="text-right text-emerald-400 font-bold">LOADED</td>
                </tr>
                <tr>
                  <td className="py-2 text-neutral-350 font-bold">VITE_FIREBASE_PROJECT_ID</td>
                  <td>{configSource.projectId}</td>
                  <td>{maskString(metaEnv.VITE_FIREBASE_PROJECT_ID || auth.app?.options?.projectId)}</td>
                  <td className="text-right text-emerald-400 font-bold">LOADED</td>
                </tr>
                <tr>
                  <td className="py-2 text-neutral-350 font-bold">VITE_FIREBASE_AUTH_DOMAIN</td>
                  <td>{configSource.authDomain}</td>
                  <td>{maskString(metaEnv.VITE_FIREBASE_AUTH_DOMAIN || auth.app?.options?.authDomain)}</td>
                  <td className="text-right text-emerald-400 font-bold">LOADED</td>
                </tr>
                <tr>
                  <td className="py-2 text-neutral-350 font-bold">VITE_FIREBASE_APP_ID</td>
                  <td>Dynamic Context</td>
                  <td>{maskString(metaEnv.VITE_FIREBASE_APP_ID || auth.app?.options?.appId)}</td>
                  <td className="text-right text-emerald-400 font-bold">LOADED</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Current Active Session & User Info */}
        <div className="bg-neutral-950 border border-neutral-900 p-6 rounded-sm">
          <div className="flex items-center gap-2 mb-4">
            <Terminal className="h-5 w-5 text-amber-500" />
            <h3 className="font-mono text-xs uppercase text-neutral-400 tracking-wider font-bold">Active Auth Sign-In Session</h3>
          </div>

          {user ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                <div className="bg-black p-3 border border-neutral-905 rounded leading-6">
                  <div className="text-neutral-500 uppercase font-bold text-[9px] tracking-widest">FIREBASE ID PROFILE:</div>
                  <div>ID / UID: <span className="text-white font-bold">{user.id}</span></div>
                  <div>Email: <span className="text-white font-bold">{user.email}</span></div>
                  <div>Display Name: <span className="text-white font-bold">{user.name}</span></div>
                </div>
                <div className="bg-black p-3 border border-neutral-905 rounded leading-6">
                  <div className="text-neutral-500 uppercase font-bold text-[9px] tracking-widest">PERMISSIONS & METRICS:</div>
                  <div>Subscription: <span className="text-amber-500 font-extrabold uppercase">{user.subscriptionStatus}</span></div>
                  <div>Email Verified: <span className={user.isVerified ? 'text-emerald-400 font-bold' : 'text-neutral-500'}>{user.isVerified ? 'YES' : 'NO'}</span></div>
                  <div>Auth Provider: <span className="text-white font-bold uppercase">{user.authProvider || 'Email/Password'}</span></div>
                </div>
              </div>

              {/* Functional Verification and Password Reset Triggers */}
              <div className="bg-black p-4 border border-neutral-905 rounded-sm flex flex-wrap gap-4">
                <button
                  type="button"
                  onClick={triggerVerificationTest}
                  disabled={actionLoading !== null}
                  className="bg-amber-500 hover:bg-amber-600 text-black text-xs font-bold uppercase tracking-wider px-4 py-2.5 rounded-sm font-mono cursor-pointer flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  {actionLoading === 'verify_email' ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : null}
                  <span>Test Email Verification Send</span>
                </button>
                <button
                  type="button"
                  onClick={triggerPasswordResetTest}
                  disabled={actionLoading !== null}
                  className="bg-neutral-900 border border-neutral-800 hover:bg-neutral-850 text-white text-xs font-bold uppercase tracking-wider px-4 py-2.5 rounded-sm font-mono cursor-pointer flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  {actionLoading === 'pwd_reset' ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : null}
                  <span>Test Password Reset Send</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center py-6 bg-black border border-neutral-905 rounded-sm">
              <span className="text-xs text-neutral-500 block mb-3 uppercase tracking-widest">No Active Authenticated User Session Found</span>
              <p className="max-w-md mx-auto text-xs text-neutral-400 leading-relaxed font-light mb-4">
                Sign in using your account credentials, Google Auth popup, or fallback Google Redirect to diagnose user-specific functions.
              </p>
              <div className="flex justify-center gap-3">
                <a href="/auth/login" className="bg-amber-500 text-black font-bold uppercase text-[10px] tracking-wider px-5 py-2.5 rounded font-mono hover:scale-105 transition-transform">
                  Go to Login Screen
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Backend Endpoint Diagnostics */}
        <div className="bg-neutral-950 border border-neutral-900 p-6 rounded-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-mono text-xs uppercase text-neutral-400 tracking-wider font-bold">Express Server API Sync</h3>
            {apiStatus === 'testing' && <RefreshCw className="h-4.5 w-4.5 text-amber-500 animate-spin" />}
            {apiStatus === 'online' && <span className="px-2 py-0.5 text-[9px] bg-emerald-500/20 text-emerald-400 font-bold rounded uppercase">API REACHED</span>}
            {apiStatus === 'error' && <span className="px-2 py-0.5 text-[9px] bg-rose-500/20 text-rose-400 font-bold rounded uppercase">API ERROR</span>}
          </div>
          
          <p className="text-xs text-neutral-400 leading-relaxed font-light mb-3">
            To hold database sessions, our server.ts exposes a sync middleware route. Diagnosing endpoint reachability:
          </p>

          <div className="bg-black text-[11px] font-mono p-3 rounded border border-neutral-905 text-white space-y-1">
            <div className="text-neutral-500 uppercase tracking-widest font-bold text-[9px]">Server API Health Log:</div>
            <div className={apiStatus === 'online' ? 'text-emerald-400' : 'text-rose-400 font-bold'}>
              {apiMsg || "Testing API connection..."}
            </div>
          </div>
        </div>

        {/* Interactive Google Sign In Flow Selectors for Deployed Restrictions */}
        <div className="bg-neutral-900/30 border border-neutral-900 p-6 rounded-sm text-center">
          <h3 className="font-mono text-xs uppercase text-neutral-450 tracking-widest font-bold mb-2">RESTRICTED TESTING BYPASSES</h3>
          <p className="text-xs text-neutral-400 leading-relaxed max-w-xl mx-auto font-light mb-4">
            If you are running inside a restricted frame or sandbox, click either button to test Google Sign In using different methods.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={loginWithGoogle}
              className="px-5 py-3 bg-[#0c0c0c] border border-neutral-800 hover:bg-neutral-850 text-white text-[10px] font-bold uppercase tracking-wider rounded font-mono transition-all cursor-pointer shadow"
            >
              🚀 Run Google POPUP Flow
            </button>
            <button
              onClick={loginWithGoogleRedirect}
              className="px-5 py-3 bg-amber-500 hover:bg-amber-600 text-black text-[10px] font-black uppercase tracking-wider rounded font-mono transition-all cursor-pointer shadow-md"
            >
              🔄 Run Google REDIRECT Flow (Full Fallback)
            </button>
          </div>
        </div>

        {/* Reset / Manual Reload control */}
        <div className="text-center">
          <button
            type="button"
            onClick={() => setRefreshTrigger(p => p + 1)}
            className="inline-flex items-center space-x-1.5 text-xs text-neutral-500 hover:text-white uppercase tracking-widest font-mono underline cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Force Re-Run All Diagnostics</span>
          </button>
        </div>

      </div>
    </div>
  );
}
