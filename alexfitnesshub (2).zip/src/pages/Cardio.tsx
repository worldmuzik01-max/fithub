import React from 'react';
import { Link } from 'react-router-dom';
import { Flame, Clock, HeartPulse, Activity, Trophy, Compass, ChevronRight, Lock, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Cardio() {
  const { user: authUser, loading: authLoading } = useAuth();
  const isPremium = authUser?.subscriptionStatus === 'premium';

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500 font-bold" />
      </div>
    );
  }

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
        {/* Cinematic Backdrop Pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-[120px]"></div>
        
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-lg w-full text-center space-y-6 shadow-2xl relative z-10">
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-syne text-3xl font-extrabold tracking-wide uppercase">STAMINA ENGINEERING LOCKED</h2>
            <p className="text-[10px] text-amber-500 font-mono tracking-widest mt-1.5 uppercase">ATHLETE AUTHENTICATION & PREMIUM SUBSCRIPTION REQUIRED</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans font-light">
            Gain full, unrestricted access to the scientific 12-3-30 Treadmill guide, high-intensity aerobic pacing, and metabolic Tabata/HIIT varieties.
          </p>
          <div className="pt-2 flex flex-col gap-3">
            <Link
              to="/pricing"
              className="w-full bg-amber-500 hover:bg-gold hover:scale-[1.02] text-black font-extrabold uppercase text-xs tracking-widest py-3.5 rounded-sm block transition-all font-mono"
            >
              Get Premium Access Now
            </Link>
            <Link
              to="/"
              className="w-full bg-neutral-900 border border-neutral-850 hover:bg-neutral-850 text-white font-bold uppercase text-xs tracking-widest py-3 rounded-sm block transition-all font-mono"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white pt-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-amber-500 uppercase text-xs font-bold tracking-widest mb-2 font-mono">STAMINA ENGINEERING</p>
          <h1 className="font-bebas text-5xl sm:text-7xl font-black text-white tracking-wide">
            CARDIO & <span className="text-amber-500">12-3-30 PROTOCOL</span>
          </h1>
          <p className="text-neutral-400 mt-4 leading-relaxed font-light">
            Elevate your oxygen kinetics and ramp up calorie burning. Explore our multi-discipline cardio tracks or study the scientific incline treadmill protocols.
          </p>
        </div>

        {/* 12-3-30 COMPREHENSIVE CARDIO INTERACTIVE GUIDE */}
        <div className="bg-neutral-950 border-2 border-amber-500/50 rounded-lg p-8 max-w-4xl mx-auto mb-16 relative shadow-2xl">
          <div className="absolute top-4 right-6 bg-amber-500 text-black font-bebas text-xs font-black uppercase px-2.5 py-1 rounded-sm">
            🔥 #1 FAT BURN ROUTINE
          </div>
          
          <div className="flex items-center space-x-2.5 mb-6">
            <HeartPulse className="h-6 w-6 text-amber-500" />
            <h2 className="font-bebas text-2xl sm:text-3xl font-bold tracking-wider text-white uppercase">THE SCIENTIFIC 12-3-30 TREADMILL GUIDE</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-8 items-center">
            <div className="md:col-span-7">
              <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed font-light">
                Popularized globally due to its extreme fat-loss and joint preservation qualities, the 12-3-30 is a steady-state cardiovascular protocol. By using high gravity vertical resistance (incline) instead of raw speed (running), it spikes heart rate into the optimal lipolysis (fat burn) zone while sparing knees and ankles from high friction impacts.
              </p>
            </div>
            <div className="md:col-span-5 bg-black/60 border border-white/5 p-2 rounded-xl flex justify-center items-center">
              <img 
                src="https://fitnessprogramer.com/wp-content/uploads/2021/04/Treadmill-Incline.gif" 
                alt="12-3-30 Incline Treadmill Technique"
                referrerPolicy="no-referrer"
                className="max-h-40 max-w-full object-contain rounded brightness-90 hover:brightness-100 transition-all duration-300" 
              />
            </div>
          </div>

          {/* Guidelines grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8 text-center">
            <div className="bg-black border border-neutral-900 p-6 rounded">
              <p className="text-neutral-500 uppercase font-bold text-[10px] tracking-wider mb-2">TREADMILL INCLINE</p>
              <p className="font-bebas text-4xl sm:text-5xl font-black text-amber-500 tracking-widest">12%</p>
              <p className="text-[10px] text-neutral-400 mt-2">Gravity resistance setup</p>
            </div>
            <div className="bg-black border border-neutral-900 p-6 rounded">
              <p className="text-neutral-500 uppercase font-bold text-[10px] tracking-wider mb-2">SPEED PACE</p>
              <p className="font-bebas text-4xl sm:text-5xl font-black text-amber-500 tracking-widest">3 mph</p>
              <p className="text-[10px] text-neutral-450 mt-2">Steady power hike pace</p>
            </div>
            <div className="bg-black border border-neutral-900 p-6 rounded">
              <p className="text-neutral-500 uppercase font-bold text-[10px] tracking-wider mb-2">DURATION TIME</p>
              <p className="font-bebas text-4xl sm:text-5xl font-black text-amber-500 tracking-widest">30 MINS</p>
              <p className="text-[10px] text-neutral-400 mt-2">Continuous non-stop effort</p>
            </div>
          </div>

          {/* Benefits bullets */}
          <div className="border-t border-neutral-900 pt-6">
            <h4 className="font-bebas text-lg font-bold text-white tracking-wider mb-4 uppercase">CLINICALLY PROVEN ADVANTAGES</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="flex space-x-2.5 items-start">
                <Flame className="h-4.5 w-4.5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-bold text-white uppercase text-xs">VISCERAL FAT LOSS</h5>
                  <p className="text-neutral-500 text-[11px] mt-1">Hikes metabolic heat rate to oxidize deep tummy fats safely.</p>
                </div>
              </div>
              <div className="flex space-x-2.5 items-start">
                <HeartPulse className="h-4.5 w-4.5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-bold text-white uppercase text-xs">MAX CARDIAC HEALTH</h5>
                  <p className="text-neutral-500 text-[11px] mt-1">Fortifies stroke volume metrics and reduces resting heart rates.</p>
                </div>
              </div>
              <div className="flex space-x-2.5 items-start">
                <Activity className="h-4.5 w-4.5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-bold text-white uppercase text-xs">SYSTEMIC ENDURANCE</h5>
                  <p className="text-neutral-500 text-[11px] mt-1">Increases mitochondrial capillary capacities across lower limbs.</p>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* GENERAL CARDIO ARCHITECTURE */}
        <h3 className="font-bebas text-3xl font-extrabold text-white text-center tracking-wider mb-8 uppercase">AEROBIC & HIIT VARIETIES</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {[
            { title: 'Aerobic Power Walking', goal: 'Zone 2 Metabolic Stabilizer', pace: '3.5 - 4.0 mph pace', duration: '45-60 mins', desc: 'Promotes complete recovery, lowers systemic cortisol levels, and oxidizes free-fatty acids.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/04/Treadmill.gif' },
            { title: 'Intense Tactical Running', goal: 'Aerobic Threshold Expansion', pace: 'Under 5:30 min/km pace', duration: '20-45 mins', desc: 'Sustained endurance drills to build elite tactical stamina and lung oxygen capacity.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/08/Running.gif' },
            { title: 'Road & Spin Cycling', goal: 'Power Quadriceps Stamina', pace: '85 - 100 RPM cadence', duration: '30-50 mins', desc: 'Excellent low-impact quad, hamstring, and glute threshold stamina development.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/02/Stationary-Bicycle.gif' },
            { title: 'Athletic Crawl Swimming', goal: 'Symmetrical Full-Body Pull', pace: 'Steady lap-to-lap control', duration: '30 mins', desc: 'No-gravity pressure. Engages rear delts, latissimus dorsi, core, and lungs simultaneously.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/10/Air-Swimming.gif' },
            { title: 'Double Under Jump Rope', goal: 'Cardiovascular Coordination', pace: 'High kinetic coordination', duration: '15-20 mins', desc: 'Sharp calve tendon loading and quick wrist reflexes, spiking thermic rates rapidly.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/06/Jump-Rope.gif' },
            { title: 'Tabata HIIT Conditioning', goal: 'High Metabolic Afterburn', pace: '20s max sprint / 10s stop', duration: '16 mins total', desc: 'Extreme EPOC (Excess Post-exercise Oxygen Consumption) burn, frying fats hours post-workout.', gif: 'https://fitnessprogramer.com/wp-content/uploads/2021/05/Burpee.gif' }
          ].map((item, i) => (
            <div key={i} className="bg-neutral-950 border border-neutral-900 p-5 rounded hover:border-amber-500/10 transition-all flex flex-col justify-between">
              <div>
                <h4 className="font-bebas text-xl font-bold tracking-wider text-amber-500 uppercase">{item.title}</h4>
                <p className="text-xs text-neutral-300 font-semibold mt-1 uppercase">{item.goal}</p>
                <p className="text-xs text-neutral-400 font-light mt-2 leading-relaxed mb-4">{item.desc}</p>
                
                {item.gif && (
                  <div className="w-full bg-black/60 border border-white/5 rounded-lg overflow-hidden flex items-center justify-center p-2 mb-4">
                    <img 
                      src={item.gif} 
                      alt={item.title} 
                      referrerPolicy="no-referrer"
                      className="max-h-36 max-w-full object-contain rounded brightness-90 hover:brightness-100 transition-all duration-300" 
                    />
                  </div>
                )}
              </div>
              <div className="border-t border-neutral-900 pt-3 mt-4 flex justify-between items-center text-[10px] text-neutral-500 font-mono">
                <span>VOL: {item.duration}</span>
                <span>PACE: {item.pace || 'Tabata'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Centralized database prompt */}
        <div className="bg-neutral-950/80 border border-neutral-900 rounded-lg p-8 max-w-5xl mx-auto mt-12 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl"></div>
          <span className="text-amber-500 uppercase text-[10px] font-black tracking-widest font-mono">Centralized Athletic Database</span>
          <h3 className="font-bebas text-2xl sm:text-3xl font-extrabold text-white uppercase italic mt-1">Want to browse thousands of cardio exercises?</h3>
          <p className="text-xs text-neutral-400 max-w-xl mx-auto mt-2 leading-relaxed">
            Gain full access to our massive exercise database. Customize sets, reps, and tempos across Aerobic pacing, HIIT, swimming and metabolic systems.
          </p>
          <div className="mt-5">
            <Link
              to="/workouts"
              className="inline-flex items-center gap-2 bg-amber-500 text-black font-extrabold text-xs uppercase tracking-widest py-3 px-6 rounded-sm hover:brightness-110 shadow-lg shadow-amber-500/10 transition-all font-mono"
            >
              <span>Explore Massive Exercise Library 📖</span>
              <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
