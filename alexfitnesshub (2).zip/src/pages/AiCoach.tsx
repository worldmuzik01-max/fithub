import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, User, ChevronRight, Activity, Smile, Dumbbell, Lock, RefreshCw, Crown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';

interface ChatMessage {
  id: string;
  sender: 'user' | 'coach';
  text: string;
  date: string;
}

export default function AiCoach() {
  const { user: authUser, loading: authLoading } = useAuth();
  
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'coach',
      text: "Welcome to ALEXFITNESSHUB Premium Center. I am your Lead AI Coach. I specialize in fat-loss deficits, military stamina, bulk progression, and custom diet allocations. Choose one of our 9 quick-launch target blueprints below, or ask me directly any question concerning your training or calorie budget!",
      date: new Date().toLocaleTimeString()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const endOfChatRef = useRef<HTMLDivElement>(null);

  const quickGoals = [
    'Build Chest',
    'Build Back',
    'Build Legs',
    'Build Arms',
    'Build Shoulders',
    'Lose Belly Fat',
    'Gain Weight',
    'Athletic Conditioning',
    'Military Fitness'
  ];

  useEffect(() => {
    endOfChatRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  if (authLoading) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  if (!authUser) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full text-center space-y-6 shadow-2xl relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl"></div>
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full flex items-center justify-center mx-auto">
            <Lock className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-bebas text-3xl font-extrabold tracking-wider">AI COACH LOCKED</h2>
            <p className="text-xs text-neutral-500 uppercase tracking-widest mt-1">Authentic Session Verification Required</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans">
            Real-time biometric synthesis and Gemini-powered smart nutrition allocations are reserved for premium athletes with logged-in credentials.
          </p>
          <div className="pt-2">
            <Link
              to="/auth/login"
              className="w-full bg-amber-500 hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm block font-mono"
            >
              Sign In to Unlock
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const isPremium = authUser.subscriptionStatus === 'premium' || authUser.email === 'muzikworld08@gmail.com' || (authUser as any).role === 'admin';

  if (!isPremium) {
    return (
      <div className="bg-black text-white pt-32 pb-16 min-h-screen flex items-center justify-center px-4">
        <div className="bg-neutral-950 border border-neutral-900 rounded-sm p-8 max-w-md w-full text-center space-y-6 shadow-2xl relative">
          <div className="absolute top-0 right-0 w-24 h-24 bg-gold/5 rounded-full blur-2xl"></div>
          <div className="w-16 h-16 bg-gold/10 border border-gold/20 text-gold rounded-full flex items-center justify-center mx-auto animate-pulse">
            <Crown className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-bebas text-3xl font-extrabold tracking-wider">ELITE AI COACH LOCKED</h2>
            <p className="text-xs text-amber-500 uppercase tracking-widest mt-1">Premium subscription required</p>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed font-sans">
            Personal biomechanical breakdown, tailored workout structures, and direct real-time Google Gemini diet consultations are exclusive benefits for ALEXFITNESSHUB Premium members.
          </p>
          <div className="pt-2 flex flex-col space-y-3">
            <Link
              to="/pricing"
              className="w-full bg-gold hover:brightness-110 text-black font-extrabold uppercase text-xs tracking-widest py-3 rounded-sm block font-mono"
            >
              Get Premium Access
            </Link>
            <Link
              to="/dashboard"
              className="w-full border border-white/10 hover:bg-white/5 text-white font-bold uppercase text-[10px] tracking-wider py-2.5 rounded-sm block"
            >
              Back to Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleSendMessage = async (customMessage?: string) => {
    const textSend = customMessage || inputText;
    if (!textSend.trim()) return;

    if (!customMessage) {
      setInputText('');
    }

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: textSend,
      date: new Date().toLocaleTimeString()
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsTyping(true);

    if (!authUser) {
      setIsTyping(false);
      return;
    }

    try {
      const data = await apiFetch<any>('/api/coach/ask', {
        method: 'POST',
        body: JSON.stringify({
          userId: authUser.id,
          message: textSend,
          goalSearch: customMessage ? textSend : undefined,
          user: authUser
        })
      });
      
      const coachMsg: ChatMessage = {
        id: `c-${Date.now()}`,
        sender: 'coach',
        text: data.answer || "Success. Plan loaded.",
        date: new Date().toLocaleTimeString()
      };

      setMessages((prev) => [...prev, coachMsg]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [...prev, {
        id: `err-${Date.now()}`,
        sender: 'coach',
        text: "Error talking to coach. Verify connection.",
        date: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="bg-black text-white pt-24 min-h-screen flex flex-col">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full flex-grow flex flex-col">
        
        {/* Header summary */}
        <div className="text-center max-w-2xl mx-auto mb-8 shrink-0">
          <div className="inline-flex items-center space-x-1.5 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded text-amber-500 text-xs font-bold uppercase mb-2">
            <Sparkles className="h-3.5 w-3.5 animate-pulse" />
            <span>Google Gemini-3.5-Flash Core Active</span>
          </div>
          <h1 className="font-bebas text-4xl sm:text-6xl font-black tracking-wide text-white">
            AI FITNESS <span className="text-amber-500">COACH CENTER</span>
          </h1>
        </div>

        {/* 9 Quick selectors */}
        <div className="mb-8 shrink-0">
          <p className="text-neutral-500 uppercase font-bold text-[10px] tracking-widest text-center mb-3">SELECT TARGET BLUEPRINT PROTOCOL</p>
          <div className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto">
            {quickGoals.map((g) => (
              <button
                key={g}
                disabled={isTyping}
                onClick={() => handleSendMessage(g)}
                className="bg-neutral-950 border border-neutral-900 text-[11px] text-neutral-300 hover:text-black hover:bg-amber-500 hover:border-amber-500 px-3 py-2 rounded uppercase font-semibold cursor-pointer tracking-wider transition-all disabled:opacity-50"
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        {/* Chat window container */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-lg flex flex-col flex-grow max-w-4xl w-full mx-auto shadow-2xl relative min-h-[420px] max-h-[600px] overflow-hidden">
          
          {/* Chat scrolling feed */}
          <div className="flex-grow overflow-y-auto p-6 space-y-6">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex space-x-3 max-w-3xl items-start ${m.sender === 'user' ? 'justify-end flex-row-reverse space-x-reverse' : 'justify-start'}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${m.sender === 'user' ? 'bg-amber-500 text-black border-amber-400' : 'bg-neutral-900 text-amber-500 border-neutral-850'}`}>
                  {m.sender === 'user' ? <User className="h-4.5 w-4.5" /> : <Dumbbell className="h-4 w-4" />}
                </div>
                
                <div className={`p-4 rounded-lg text-xs sm:text-sm leading-relaxed max-w-[85%] text-left whitespace-pre-wrap font-sans ${m.sender === 'user' ? 'bg-amber-500 text-black font-semibold' : 'bg-neutral-900 border border-neutral-850 text-neutral-200'}`}>
                  {m.text}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex space-x-3 justify-start items-center">
                <div className="w-8 h-8 rounded-full bg-neutral-900 border border-neutral-850 text-amber-500 flex items-center justify-center">
                  <Dumbbell className="h-4 w-4 animate-spin" />
                </div>
                <span className="text-xs text-neutral-500 uppercase tracking-widest font-mono animate-pulse">Alex AI is typing your protocol...</span>
              </div>
            )}
            <div ref={endOfChatRef} />
          </div>

          {/* Form Message input bar */}
          <div className="border-t border-neutral-900 p-4 bg-black/50 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex space-x-3 items-center"
            >
              <input
                type="text"
                value={inputText}
                disabled={isTyping}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Ask Alex: 'What should consist in my chest day ratio?', 'Recommend protein targets for 80kg male'"
                className="flex-grow bg-neutral-950 border border-neutral-900 rounded-md p-3.5 text-xs sm:text-sm focus:border-amber-500 outline-none hover:border-neutral-800 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={isTyping || !inputText.trim()}
                className="bg-amber-500 hover:bg-amber-600 text-black p-3 rounded-md transition-colors disabled:opacity-40"
              >
                <Send className="h-4.5 w-4.5" />
              </button>
            </form>
          </div>

        </div>

      </div>
    </div>
  );
}
