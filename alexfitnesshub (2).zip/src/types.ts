export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  subscriptionStatus: 'free' | 'premium';
  isVerified: boolean;
  avatarUrl?: string;
  fitnessGoals?: string[];
  currentWeight?: number;
  targetWeight?: number;
  height?: number;
  age?: number;
  gender?: string;
  activityLevel?: string;
  authProvider?: string;
  createdAt?: string;
}

export type SubscriptionPlan = 'free' | 'monthly' | 'yearly';

export interface Subscription {
  id: string;
  userId: string;
  planType: 'monthly' | 'yearly';
  amount: number;
  status: 'active' | 'expired' | 'pending';
  startDate: string;
  endDate: string;
}

export interface Payment {
  id: string;
  userId: string;
  amount: number;
  reference: string;
  status: 'success' | 'failed' | 'pending';
  date: string;
  planType: 'monthly' | 'yearly';
}

export interface Exercise {
  id: string;
  name: string;
  category: string; // 'chest' | 'back' | 'legs' | 'shoulders' | 'arms' | 'core' | 'cardio'
  instructions?: string;
}

export interface WorkoutHistoryEntry {
  id: string;
  userId: string;
  date: string;
  name: string; // e.g., 'Upper Body Focus'
  duration: number; // minutes
  caloriesBurned: number;
  exercises: {
    name: string;
    sets: number;
    reps: number;
    weight?: number; // kg
  }[];
}

export interface MealHistoryEntry {
  id: string;
  userId: string;
  date: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  foodItems: {
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }[];
}

export interface ProgressEntry {
  id: string;
  userId: string;
  date: string;
  weight: number;
  photoUrl?: string;
  waterIntakeLiters: number;
  chest?: number; // cm
  waist?: number;
  hips?: number;
  biceps?: number;
  thighs?: number;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: 'training' | 'nutrition' | 'mindset' | 'military';
  author: string;
  date: string;
  image: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  resultType: 'fat-loss' | 'muscle-gain' | 'military' | 'health-reversal';
  result: string;
  story: string;
  beforeWeight: string;
  afterWeight: string;
  image: string;
  rating: number;
}
