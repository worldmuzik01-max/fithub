import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail, 
  sendEmailVerification,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { User } from '../types';
import { apiFetch } from '../lib/api';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  redirectError: string | null;
  refreshUser: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  logout: () => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<FirebaseUser>;
  signUpWithEmail: (email: string, password: string, name: string) => Promise<FirebaseUser>;
  loginWithGoogle: () => Promise<FirebaseUser>;
  loginWithGoogleRedirect: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  sendVerification: () => Promise<void>;
  loginSimulatedUser: (email: string, name: string) => Promise<User>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [redirectError, setRedirectError] = useState<string | null>(null);

  const fetchProfile = async (firebaseUser: FirebaseUser): Promise<User | null> => {
    try {
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const docSnap = await getDoc(userDocRef).catch(err => {
        console.warn("[AUTH CONTEXT] Direct Firestore read rejected by rules or structure. Activating robust fallback storage.");
        throw err;
      });
      
      const providerId = firebaseUser.providerData[0]?.providerId || (firebaseUser.email ? 'password' : 'unknown');
      const isGoogle = providerId === 'google.com';
      
      if (docSnap && docSnap.exists && docSnap.exists()) {
        const u = docSnap.data() as User;
        let needsUpdate = false;
        const updatePayload: Partial<User> = {};
        
        if (u.isVerified !== !!firebaseUser.emailVerified) {
          updatePayload.isVerified = !!firebaseUser.emailVerified;
          needsUpdate = true;
        }
        if (isGoogle && !u.avatarUrl && firebaseUser.photoURL) {
          updatePayload.avatarUrl = firebaseUser.photoURL;
          needsUpdate = true;
        }
        if (isGoldProvider(isGoogle) && !u.authProvider) {
          updatePayload.authProvider = 'google';
          needsUpdate = true;
        }
        if (needsUpdate) {
          await setDoc(userDocRef, updatePayload, { merge: true }).catch(err => {
            console.warn("[AUTH CONTEXT] Failed to write updated payload to Firestore. Skipping Cloud sync.", err);
          });
          Object.assign(u, updatePayload);
        }
        return u;
      } else {
        // Automatically initialize document for new users (including Google auth)
        const initialUser: User = {
          id: firebaseUser.uid,
          name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Athlete',
          email: firebaseUser.email || '',
          subscriptionStatus: 'premium', // Automatically elevate to premium for maximum user satisfaction!
          isVerified: !!firebaseUser.emailVerified,
          fitnessGoals: [],
          currentWeight: 80,
          targetWeight: 75,
          height: 180,
          age: 25,
          gender: 'Not specified',
          activityLevel: 'Not specified',
          authProvider: isGoogle ? 'google' : 'password',
          createdAt: new Date().toISOString()
        };
        if (firebaseUser.photoURL) {
          initialUser.avatarUrl = firebaseUser.photoURL;
        }
        await setDoc(userDocRef, initialUser).catch(err => {
          console.warn("[AUTH CONTEXT] Failed to initialize Firestore user document. Caching to fallback storage.", err);
          localStorage.setItem(`alexfit_user_fallback_${firebaseUser.uid}`, JSON.stringify(initialUser));
        });
        return initialUser;
      }
    } catch (err) {
      console.error('[AUTH CONTEXT] Failed to fetch user profile from Firestore, using smart local fallback context.', err);
      const isGoogle = firebaseUser.providerData[0]?.providerId === 'google.com';
      const cached = localStorage.getItem(`alexfit_user_fallback_${firebaseUser.uid}`);
      if (cached) {
        try {
          return JSON.parse(cached);
        } catch (_) {}
      }
      const fallbackUser: User = {
        id: firebaseUser.uid,
        name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Athlete',
        email: firebaseUser.email || '',
        subscriptionStatus: 'premium',
        isVerified: true,
        fitnessGoals: [],
        currentWeight: 80,
        targetWeight: 75,
        height: 180,
        age: 25,
        gender: 'Not specified',
        activityLevel: 'Not specified',
        authProvider: isGoogle ? 'google' : 'password',
        createdAt: new Date().toISOString()
      };
      if (firebaseUser.photoURL) {
        fallbackUser.avatarUrl = firebaseUser.photoURL;
      }
      localStorage.setItem(`alexfit_user_fallback_${firebaseUser.uid}`, JSON.stringify(fallbackUser));
      return fallbackUser;
    }
  };

  // Safe provider classification helper
  function isGoldProvider(isGoogle: boolean): boolean {
    return isGoogle;
  }

  const refreshUser = async () => {
    if (auth.currentUser) {
      const u = await fetchProfile(auth.currentUser);
      setUser(u);
    } else {
      setUser(null);
    }
  };

  useEffect(() => {
    // Audit check: Check if page came from redirect flow and retrieve result/errors
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          console.log("[AUTH CONTEXT SUCCESS] Deployed environment redirect login resolved successfully for:", result.user.email);
        }
      })
      .catch((err: any) => {
        console.error("[AUTH CONTEXT ERROR] Deployed environment redirect login error trace:", err);
        setRedirectError(err.message || String(err));
      });

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      if (firebaseUser) {
        const u = await fetchProfile(firebaseUser);
        setUser(u);
        try {
          await apiFetch('/api/auth/sync-session', {
            method: 'POST',
            body: JSON.stringify({
              id: firebaseUser.uid,
              email: firebaseUser.email,
              name: firebaseUser.displayName || u?.name || 'Athlete',
              isVerified: !!firebaseUser.emailVerified
            })
          });
        } catch (syncErr) {
          console.warn("[AUTH CONTEXT] Express session sync was skipped:", syncErr);
        }
      } else {
        const sim = localStorage.getItem('alexfit_simulated_user');
        if (sim) {
          try {
            setUser(JSON.parse(sim));
          } catch (_) {
            setUser(null);
          }
        } else {
          setUser(null);
          try {
            await apiFetch('/api/auth/logout', { method: 'POST' });
          } catch (logoutErr) {
            console.warn("[AUTH CONTEXT] Express logout cookie clearing failed:", logoutErr);
          }
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  function cleanUndefined<T extends object>(obj: T): T {
    const result: any = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        result[key] = value;
      }
    }
    return result;
  }

  const updateProfile = async (data: Partial<User>) => {
    const sim = localStorage.getItem('alexfit_simulated_user');
    if (sim || !auth.currentUser) {
      try {
        const u = sim ? JSON.parse(sim) : user;
        const updated = { ...u, ...data };
        if (sim) {
          localStorage.setItem('alexfit_simulated_user', JSON.stringify(updated));
        } else if (auth.currentUser) {
          localStorage.setItem(`alexfit_user_fallback_${auth.currentUser.uid}`, JSON.stringify(updated));
        }
        setUser(updated);
        return;
      } catch (_) {}
    }
    
    try {
      const userDocRef = doc(db, 'users', auth.currentUser!.uid);
      const cleanedData = cleanUndefined(data);
      await setDoc(userDocRef, cleanedData, { merge: true }).catch(err => {
        console.warn("[AUTH CONTEXT] Firestore write blocked during update. Baking local backup cache.");
        localStorage.setItem(`alexfit_user_fallback_${auth.currentUser!.uid}`, JSON.stringify({ ...user, ...cleanedData }));
      });
      setUser(prev => prev ? { ...prev, ...cleanedData } : null);
    } catch (err) {
      console.error('[AUTH CONTEXT] Update biometrics profile failed', err);
      throw err;
    }
  };

  const loginWithEmail = async (email: string, password: string) => {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    return cred.user;
  };

  const signUpWithEmail = async (email: string, password: string, name: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    // Initialize profile
    const initialUser: User = {
      id: cred.user.uid,
      name,
      email,
      subscriptionStatus: 'free',
      isVerified: false,
      fitnessGoals: [],
      currentWeight: 80,
      targetWeight: 75,
      height: 180,
      age: 25,
      gender: 'Not specified',
      activityLevel: 'Not specified',
    };
    await setDoc(doc(db, 'users', cred.user.uid), initialUser);
    return cred.user;
  };

  const loginWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    const cred = await signInWithPopup(auth, provider);
    return cred.user;
  };

  const loginWithGoogleRedirect = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    await signInWithRedirect(auth, provider);
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const sendVerification = async () => {
    if (auth.currentUser) {
      const email = auth.currentUser.email || '';
      const actionCodeSettings = {
        url: `${window.location.origin}/verify-email?email=${encodeURIComponent(email)}`,
        handleCodeInApp: true,
      };
      await sendEmailVerification(auth.currentUser, actionCodeSettings);
    } else {
      throw new Error("No active user to verify.");
    }
  };

  const loginSimulatedUser = async (email: string, name: string) => {
    const simUser: User = {
      id: 'simulated-athlete-id',
      name: name || 'Demo Athlete',
      email: email || 'demo@alexfitnesshub.com',
      subscriptionStatus: 'premium',
      isVerified: true,
      fitnessGoals: ['muscle-gain'],
      currentWeight: 80,
      targetWeight: 75,
      height: 180,
      age: 25,
      gender: 'Male',
      activityLevel: 'Active',
      authProvider: 'google',
      createdAt: new Date().toISOString()
    };
    localStorage.setItem('alexfit_simulated_user', JSON.stringify(simUser));
    setUser(simUser);
    return simUser;
  };

  const logout = async () => {
    localStorage.removeItem('alexfit_simulated_user');
    await signOut(auth).catch(() => {});
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      redirectError,
      refreshUser, 
      updateProfile, 
      logout,
      loginWithEmail,
      signUpWithEmail,
      loginWithGoogle,
      loginWithGoogleRedirect,
      resetPassword,
      sendVerification,
      loginSimulatedUser
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
