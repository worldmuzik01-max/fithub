import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import SupportChatWidget from './components/SupportChatWidget';
import { AuthProvider } from './context/AuthContext';

// Pages import
import Home from './pages/Home';
import About from './pages/About';
import Pricing from './pages/Pricing';
import Workouts from './pages/Workouts';
import GymWorkouts from './pages/GymWorkouts';
import HomeWorkouts from './pages/HomeWorkouts';
import Calisthenics from './pages/Calisthenics';
import Cardio from './pages/Cardio';
import Nutrition from './pages/Nutrition';
import MealPlans from './pages/MealPlans';
import AiCoach from './pages/AiCoach';
import Transformations from './pages/Transformations';
import Blog from './pages/Blog';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Logout from './pages/Logout';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Admin from './pages/Admin';
import VerifyEmail from './pages/VerifyEmail';
import Diagnostic from './pages/Diagnostic';

export default function App() {
  React.useEffect(() => {
    const savedTheme = localStorage.getItem('alexfit_theme');
    if (savedTheme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, []);

  return (
    <AuthProvider>
      <Router>
        <div className="flex flex-col min-h-screen app-bg font-sans antialiased selection:bg-amber-500 selection:text-black">
          
          {/* Global Navigation Header */}
          <Header />

          {/* Dynamic Route Viewports */}
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/workouts" element={<Workouts />} />
              <Route path="/gym-workouts" element={<GymWorkouts />} />
              <Route path="/home-workouts" element={<HomeWorkouts />} />
              <Route path="/calisthenics" element={<Calisthenics />} />
              <Route path="/cardio" element={<Cardio />} />
              <Route path="/nutrition" element={<Nutrition />} />
              <Route path="/meal-plans" element={<MealPlans />} />
              <Route path="/ai-coach" element={<AiCoach />} />
              <Route path="/transformations" element={<Transformations />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/auth/login" element={<Login />} />
              <Route path="/auth/signup" element={<Signup />} />
              <Route path="/auth/logout" element={<Logout />} />
              <Route path="/onboarding" element={<Onboarding />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/verify-email" element={<VerifyEmail />} />
              <Route path="/auth/diagnostic" element={<Diagnostic />} />
              {/* Direct Verification Target Page to allow seamless in-app triggers */}
              <Route path="/verify-payment" element={<Dashboard />} />
            </Routes>
          </main>

          {/* Global Site Footer */}
          <Footer />

          {/* Persistent Live Coaching Support Chat */}
          <SupportChatWidget />

        </div>
      </Router>
    </AuthProvider>
  );
}
