import nodemailer from 'nodemailer';
import crypto from 'crypto';

// Types and Interfaces
export interface EmailPayload {
  to: string;
  subject: string;
  html: string;
  text: string;
  type: 'verify' | 'welcome' | 'reset' | 'subscription' | 'receipt';
}

// Global Simulated Queue for Sandbox tray
// Declared as global as server.ts needs to expose it over GET /api/auth/simulated-emails
const globalSimulatedInboxes: any[] = [];
export { globalSimulatedInboxes };

// Professional brand constants matching AlexFitnessHub
const BRAND_GOLD = '#D97706';
const BRAND_BLACK = '#09090B';

/**
 * Renders the HTML templates for system dispatches with extreme polish.
 */
export function renderEmailTemplate(type: 'verify' | 'welcome' | 'reset' | 'subscription' | 'receipt', data: any): string {
  const header = `
    <div style="background-color: ${BRAND_BLACK}; padding: 30px; text-align: center; border-radius: 4px 4px 0 0; border-bottom: 3px solid ${BRAND_GOLD};">
      <h1 style="color: #FFFFFF; font-family: 'Helvetica Neue', Arial, sans-serif; letter-spacing: 2px; margin: 0; font-size: 26px; font-weight: 900; text-transform: uppercase; font-style: italic;">ALEX<span style="color: ${BRAND_GOLD};">FITNESSHUB</span></h1>
      <p style="color: #666666; font-size: 10px; text-transform: uppercase; letter-spacing: 3px; margin: 5px 0 0 0; font-family: monospace;">Secured Transformation Channel</p>
    </div>
  `;
  
  const footer = `
    <div style="background-color: #111111; padding: 25px; text-align: center; border-radius: 0 0 4px 4px; border-top: 1px solid #222222; margin-top: 30px;">
      <p style="color: #888888; font-size: 11px; margin: 0; font-family: sans-serif;">This is a premium automated security message from Coach Alex's Systems.</p>
      <p style="color: #555555; font-size: 10px; margin: 8px 0 0 0; font-family: monospace;">12 Military Barracks Rd, Lagos, Nigeria. Monnify & Resend Certified Secure Node</p>
      <p style="color: #444444; font-size: 9px; margin: 12px 0 0 0; font-family: sans-serif; line-height: 1.4;">
        Security Notice: If you did not register this credential, please safely ignore this alert. This connection session is dual-signed using cryptographically hashed SHA-256 signatures.
      </p>
    </div>
  `;

  if (type === 'verify') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Verify Email</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_BLACK}; text-align: center;">🔑 VERIFY YOUR EMAIL ADDRESS</h2>
              <p>Welcome, <b>${data.name || 'Champion'}</b>!</p>
              <p>Your anabolic physical registration records are pending. To finalize your credentials and unlock the master fitness logbooks, meal matrices, and AI coaching sessions, confirm your email state with the button below:</p>
              
              <div style="text-align: center; margin: 35px 0;">
                <a href="${data.verifyUrl}" style="background-color: ${BRAND_GOLD}; color: #000000; padding: 14px 30px; font-weight: 800; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 13px; display: inline-block; box-shadow: 0 4px 10px rgba(217, 119, 6, 0.25);">Verify Account Email</a>
              </div>
              
              <p style="font-size: 12px; color: #666666; margin-top: 20px;">If the button above does not render or fails to respond, copy and paste this fallback verification URL directly into your secure browser:</p>
              <div style="background-color: #F4F4F5; padding: 12px; border-left: 4px solid ${BRAND_GOLD}; font-family: monospace; font-size: 11px; word-break: break-all; color: #333333; margin-top: 10px;">
                <a href="${data.verifyUrl}" style="color: ${BRAND_GOLD}; text-decoration: none; font-weight: bold;">${data.verifyUrl}</a>
              </div>
              
              <p style="font-size: 11px; color: #999999; margin-top: 25px;">Please act promptly. This cryptographically secure registration token remains valid for exactly 24 hours. Once activated, your basic session can immediately sign in.</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'welcome') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to AlexFitnessHub</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_GOLD}; text-align: center;">🔥 PROFILE SYSTEM INSTATED</h2>
              <p>Welcome to Coach Alex's Elite Fitness Community, <b>${data.name || 'Champion'}</b>!</p>
              <p>Your registration is complete. Your credentials have been cryptographic-verified. Your personalized dashboard logs are fully operational!</p>
              
              <div style="background-color: #F8F8F9; border: 1px solid #ECEAEA; padding: 20px; margin: 25px 0; border-radius: 3px;">
                <h4 style="margin: 0 0 10px 0; text-transform: uppercase; font-size: 12px; letter-spacing: 1px; color: ${BRAND_BLACK};">YOUR PROFILE ATTRIBUTES:</h4>
                <p style="margin: 4px 0; font-size: 11px; font-family: monospace;"><b>Security Tag ID:</b> ${data.userId || 'N/A'}</p>
                <p style="margin: 4px 0; font-size: 11px; font-family: monospace;"><b>Athlete Email:</b> ${data.email}</p>
                <p style="margin: 4px 0; font-size: 11px; font-family: monospace;"><b>Verification:</b> Verified Dual-Signature Active</p>
                <p style="margin: 4px 0; font-size: 11px; font-family: monospace;"><b>Tier Access:</b> Basic Athlete (Ad-Free Active Logs)</p>
              </div>

              <p>Launch your account immediately to trace your biometric ratios, design compound-lifting workout structures, analyze calorie deficits, and interact with our automated Gemini AI coach.</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${data.loginUrl || '/auth/login'}" style="background-color: #000000; color: #FFFFFF; padding: 13px 25px; font-weight: bold; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 12px;">Launch Dashboard</a>
              </div>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'reset') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Reset Password</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: #BE123C; text-align: center;">🔒 PASSWORD RESET DISPATCHED</h2>
              <p>Hello, <b>${data.name || 'Champion'}</b>,</p>
              <p>A request has been lodged to reset the primary security code for your AlexFitnessHub account. If you did not make this request, you can safely ignore this email.</p>
              
              <p>To safely choose a new secure password, launch our verified reset channel by clicking below:</p>
              <div style="text-align: center; margin: 35px 0;">
                <a href="${data.resetUrl}" style="background-color: ${BRAND_GOLD}; color: #000000; padding: 14px 30px; font-weight: 800; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 13px; display: inline-block;">Update Security Code</a>
              </div>
              
              <p style="font-size: 11px; color: #999999; margin-top: 25px;">Security Notice: This password reset sequence remains responsive for exactly 30 minutes from creation before self-destructing.</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'subscription') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Subscription Activated</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_GOLD}; text-align: center;">🎖️ PREMIUM ATHLETE ACCESS GRANTED</h2>
              <p>Dear <b>${data.name}</b>,</p>
              <p><b>WELCOME TO THE ELITE PROTOCOLS!</b> Your Monnify payment processing has been finalized and verified. Your profile is formally upgraded to <b>ALEXFITNESSHUB PREMIUM SUBSCRIPTION TIER</b>.</p>
              
              <table style="width: 100%; border-collapse: collapse; margin: 25px 0; font-size: 13px;">
                <tr style="background-color: #F8F8F9;">
                  <th style="padding: 10px; border: 1px solid #EAEAEA; text-align: left; font-weight: bold; color: ${BRAND_BLACK};">Program Parameter</th>
                  <th style="padding: 10px; border: 1px solid #EAEAEA; text-align: left; font-weight: bold; color: ${BRAND_BLACK};">Status Detail</th>
                </tr>
                <tr>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-family: monospace;"><b>Unlocked Plan:</b></td>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; color: ${BRAND_GOLD}; font-weight: bold;">${data.planName}</td>
                </tr>
                <tr>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-family: monospace;"><b>Master Level:</b></td>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; color: #10B981; font-weight: bold;">ALL PLATFORM AREAS OPEN</td>
                </tr>
                <tr>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; font-family: monospace;"><b>AI Agent Access:</b></td>
                  <td style="padding: 10px; border: 1px solid #EAEAEA; color: #10B981; font-weight: bold;">UNLIMITED CHANNELS ACTIVE</td>
                </tr>
              </table>
              
              <p>Your upgraded profile immediately unlocks our master workout systems, celebrity physical benchmarks, and the automated AI diagnostics system.</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="/dashboard" style="background-color: #000000; color: #FFFFFF; padding: 13px 25px; font-weight: bold; text-decoration: none; border-radius: 2px; letter-spacing: 1.5px; text-transform: uppercase; font-size: 12px; display: inline-block;">Return To Premium Dashboard</a>
              </div>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  if (type === 'receipt') {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Billed Receipt</title>
        </head>
        <body style="background-color: #030303; padding: 20px; font-family: sans-serif; -webkit-font-smoothing: antialiased;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 4px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15);">
            ${header}
            <div style="padding: 40px 30px; background-color: #FFFFFF; color: #111111; font-family: sans-serif; line-height: 1.6;">
              <h2 style="margin-top: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; color: ${BRAND_BLACK}; text-align: center;">🧾 OFFICIAL TRANSACTION RECEIPT</h2>
              <p>Dear <b>${data.name}</b>,</p>
              <p>Thank you for backing Coach Alex's Systems. Your payment hash has been securely checked through the Monnify clearing network.</p>
              
              <div style="background-color: #FAFAFA; padding: 25px; border: 1px solid #EEEEEE; font-family: monospace; font-size: 12px; color: #333333; margin: 25px 0;">
                <div style="text-align: center; font-weight: bold; font-size: 14px; margin-bottom: 20px; text-decoration: underline; color: #111111;">ALEXFITNESSHUB NIGERIA LTD</div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                  <span><b>RECEIPT CODE:</b></span> <span style="text-align: right;">${data.transId}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                  <span><b>PROCESSED DATE:</b></span> <span style="text-align: right;">${data.date}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                  <span><b>REGISTERED PAYER:</b></span> <span style="text-align: right;">${data.email}</span>
                </div>
                <hr style="border: none; border-top: 1px dashed #CCCCCC; margin: 15px 0;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; font-weight: bold;">
                  <span>BASE TIER PRICE:</span> <span style="text-align: right;">${data.normalPrice}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; font-weight: bold; color: ${BRAND_GOLD};">
                  <span>DISCOUNT APPLIED:</span> <span style="text-align: right;">${data.savings}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 15px; font-weight: 1000; color: #000000; border-top: 2px solid ${BRAND_GOLD}; padding-top: 10px; margin-top: 10px;">
                  <span>TOTAL PAID AMOUNT:</span> <span style="text-align: right;">${data.amount} NGN</span>
                </div>
              </div>

              <p style="font-size: 11px; color: #888888; text-align: center; margin-top: 20px;">Transactions are fully certified on security standard firewalls. For billing and invoice questions, reply directly to this mail support.</p>
            </div>
            ${footer}
          </div>
        </body>
      </html>
    `;
  }

  return `<p>Secure email format generated.</p>`;
}

/**
 * Securely dispatches email through Resend API, SMTP Nodemailer, or falls back to Simulation Logs
 */
export async function sendEmail({ to, subject, html, text, type }: EmailPayload): Promise<boolean> {
  // Always write to simulation log list for immediate in-app sandbox testing feedback
  const logObj = {
    id: `email-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    to: to.toLowerCase(),
    subject,
    html,
    text,
    createdAt: new Date().toISOString(),
    type
  };
  globalSimulatedInboxes.unshift(logObj);

  // Keep queue size readable
  if (globalSimulatedInboxes.length > 50) {
    globalSimulatedInboxes.pop();
  }

  // 1. Check direct RESEND integration
  const resendApiKey = process.env.RESEND_API_KEY;
  if (resendApiKey && resendApiKey !== '' && resendApiKey !== 'MY_RESEND_API_KEY') {
    try {
      console.log(`[EMAIL COURIER] Dispatching through Resend API Client... Recipient: ${to}`);
      const fromEmail = process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev';
      
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: `AlexFitnessHub <${fromEmail}>`,
          to: [to],
          subject: subject,
          html: html,
          text: text
        })
      });

      if (res.ok) {
        const responseData = await res.json();
        console.log(`[EMAIL COURIER] Resend dispatch success. ID:`, responseData.id);
        return true;
      } else {
        const errorData = await res.text();
        console.error(`[EMAIL COURIER] Resend API error response:`, errorData);
      }
    } catch (err) {
      console.error(`[EMAIL COURIER] Exception on Resend API secure channel dispatch:`, err);
    }
  }

  // 2. Check traditional SMTP Nodemailer fallback
  const smtpHost = process.env.EMAIL_SERVER_HOST;
  const smtpPort = process.env.EMAIL_SERVER_PORT;
  const smtpUser = process.env.EMAIL_SERVER_USER;
  const smtpPass = process.env.EMAIL_SERVER_PASSWORD;

  if (smtpHost && smtpPort && smtpUser && smtpPass) {
    try {
      console.log(`[EMAIL COURIER] Dispatching through Nodemailer SMTP Fallback Client...`);
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: parseInt(smtpPort),
        secure: parseInt(smtpPort) === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass
        },
        tls: {
          rejectUnauthorized: false
        }
      });

      const fromAddress = process.env.EMAIL_FROM || '"AlexFitnessHub" <no-reply@alexfit.com>';
      await transporter.sendMail({
        from: fromAddress,
        to,
        subject,
        text,
        html
      });

      console.log(`[EMAIL COURIER] SMTP Nodemailer dispatched success to ${to}.`);
      return true;
    } catch (err) {
      console.error(`[EMAIL COURIER] Exception on Nodemailer SMTP channel dispatch:`, err);
    }
  }

  // 3. Fallback safely to Simulator mode
  console.log(`[EMAIL COURIER] System operating in Sandbox Local Simulation Mode. Email stored to logs. (Add RESEND_API_KEY to secrets to use Resend API directly!)`);
  return true;
}
