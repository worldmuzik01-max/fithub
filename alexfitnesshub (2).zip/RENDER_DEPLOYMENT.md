# 🚀 Render Deployment Process: ALEXFITNESSHUB

Deploy your full-stack **ALEXFITNESSHUB** application to [Render](https://render.com) using our automated Blueprints layout.

---

## 📋 Prerequisites
Before you start, make sure you have:
1.  A Google account with access to your **[Firebase Console](https://console.firebase.google.com/)**.
2.  A [GitHub](https://github.com) account.
3.  A free or premium [Render](https://render.com) account.

---

## ⚡ Step-by-Step Deployment Guide

### 1. Push Your Code to Github
1.  Initialize git if you haven't already:
    ```bash
    git init
    git add .
    git commit -m "feat: Add full-stack build files and Render Blueprints config"
    ```
2.  Create a new, private or public repository on GitHub called `alexfitnesshub`.
3.  Add the remote destination and push your main branch:
    ```bash
    git remote add origin https://github.com/YOUR_GITHUB_USERNAME/alexfitnesshub.git
    git branch -M main
    git push -u origin main
    ```

---

### 2. Connect Your Repo to Render
Render will automatically detect the `render.yaml` file at the root of the project to bootstrap your complete stack.

1.  Log in to [Render](https://dashboard.render.com).
2.  Click **New** (top right) > **Blueprint**.
3.  Connect your GitHub account and select your `alexfitnesshub` repository.
4.  Render will parse the `render.yaml` file and prompt you to name your service group (e.g., `alexfit-stack`).
5.  All required environment variable fields will be rendered automatically. Fill them out as instructed below:

---

### 3. Fill in Environment Variables

Provide the following keys when prompted by Render:

| Key | Description | Example / Best Value |
| :--- | :--- | :--- |
| **NODE_ENV** | Set host context | `production` |
| **PORT** | Dynamic routing port | `3000` |
| **GEMINI_API_KEY** | Your Google Gemini developer key | `AIzaSy...` (Get from AI Studio Settings) |
| **VITE_FIREBASE_API_KEY** | Firebase app API key | `AIzaSyBCEDeHlRU4Hmzg...` |
| **VITE_FIREBASE_AUTH_DOMAIN** | Firebase Auth domain | `alex-6ee81.firebaseapp.com` |
| **VITE_FIREBASE_PROJECT_ID** | Firebase Project ID | `alex-6ee81` |
| **VITE_FIREBASE_STORAGE_BUCKET** | Firebase storage bucket | `alex-6ee81.firebasestorage.app` |
| **VITE_FIREBASE_MESSAGING_SENDER_ID** | Messaging service identifier | `934491984930` |
| **VITE_FIREBASE_APP_ID** | Core web app ID | `1:934491984930:web:d641806f0f70e527afa67b` |
| **VITE_FIREBASE_MEASUREMENT_ID** | Measurement index configuration | `G-V73ZQ93K40` |
| **APP_URL** | **(IMPORTANT)** The Render app live URL | Place your temporary Render URL here (e.g., `https://alexfitnesshub.onrender.com`). You can return to update this once Render outputs your final active domain! |
| **RESEND_API_KEY** | (Optional) Mail outbound provider API key | Register at [Resend.com](https://resend.com) to enable production-level verification emails. |
| **RESEND_FROM_EMAIL** | (Optional) Verified sender domain | `onboarding@resend.dev` or your verified domain. |

*Note: Monnify config variables are pre-declared as placeholders and can be left blank if not configuring real-time local payments.*

6.  Click **Apply** to start building and deploying the servers!

---

### 4. Authorize Your Deployed URL in Firebase (CRITICAL)
If you neglect this step, Google Authentication popped up inside the web application will fail with an **Unauthorized Domain** error in production!

1.  Copy your live Render domain (e.g. `https://alexfitnesshub.onrender.com`).
2.  Go to the **[Google Firebase Console](https://console.firebase.google.com/)** and select your project `alex-6ee81`.
3.  In the left sidebar, navigate to **Authentication** > **Settings** (tab).
4.  Scroll down to **Authorized Domains**.
5.  Click **Add Domain** and paste your Render URL.
6.  Click **Save**. Your deployed instance is now perfectly authenticated to run authorization handshakes!

---

## 🛠️ Post-Build Verification Diagnostic

To verify everything compiles and resolves flawlessly, navigate to `/auth/diagnostic` in your deployed browser instance.

The custom-built diagnostics console will run real-time checks on:
*   **Firestore Database connection**: verifies that client handshakes are correctly received.
*   **Render Domain Status**: verifies that the hostname aligns perfectly with Firebase OAuth constraints.
*   **API Service Communication**: verifies that static requests successfully synchronize credentials on the Express server structure in production.
*   **Google Redirect Session Fallback**: allows seamless login verification bypassing restricted frame sandbox issues.
